Yo. 

I didn't want to release this yet, but life happens.
I cannot work on mods as much as I would like to, and even when I can, it's much slower than I used to be.
It's come to a point that I'm considering abandoning modding as a whole, at least for now.
There are many factors to this, but who cares, you're here to have fun.

As far as this mod (RPG) goes, there is a ton I plan to add or improve with updates. Some of it is already partially done.
Some examples: Item drops, abilities, crafting, decorations, factories, survivor minigame.
A few of these things can be found in the code, feel free to mess with them but please don't ask me for help.
There is a commented out line that runs "debug controls." Uncomment it and take a look inside the method for some of these features.

Not sure when or if I'll get back to working like normal, so I'm releasing in a state that can only be described as half-baked.
I'm sorry.
I made some promises that I can't keep and hope no one is really upset by it.
Surely people will still find RPG enjoyable, a lot of effort has been spent to improve compared to past versions.
