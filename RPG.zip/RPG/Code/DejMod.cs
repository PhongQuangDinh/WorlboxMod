using HarmonyLib;
using System;
using NCMS;
using NCMS.Utils;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Reflection;
using ReflectionUtility;

namespace RPG {
    // need to optimize a bit: use dicts and stop using reflection
    public static class DejMod
    {
        public static Harmony harmony = new Harmony("dej.mymod.wb.prof&techmod");
        public static HashSet<ActorBase> mageUnits = new HashSet<ActorBase>();
        public static HashSet<ActorBase> fluffyUnits = new HashSet<ActorBase>();
        public static HashSet<ActorBase> iceMonkeyUnits = new HashSet<ActorBase>();
        public static HashSet<ActorBase> soldierUnits = new HashSet<ActorBase>();
        public static HashSet<ActorBase> cuteDogUnits = new HashSet<ActorBase>();
        public static HashSet<ActorBase> redNinjaUnits = new HashSet<ActorBase>();
        public static HashSet<ActorBase> blackNinjaUnits = new HashSet<ActorBase>();

        public static HashSet<ActorBase> mystUnit1 = new HashSet<ActorBase>();
        public static HashSet<ActorBase> mystUnit2 = new HashSet<ActorBase>();
        public static HashSet<ActorBase> mystUnit3 = new HashSet<ActorBase>();
        public static HashSet<ActorBase> mystUnit4 = new HashSet<ActorBase>();
        public static HashSet<ActorBase> mystUnit5 = new HashSet<ActorBase>();

        public static HashSet<ActorBase> possessedUnits = new HashSet<ActorBase>();

        public static HashSet<ActorBase> clericUnits = new HashSet<ActorBase>();
        public static HashSet<ActorBase> bardUnits = new HashSet<ActorBase>();

        // used as a randomizer for all the lists
        public static List<HashSet<ActorBase>> actorTextureLists { get { 
                List<HashSet<ActorBase>> returnList = new List<HashSet<ActorBase>>();
                returnList.Add(mageUnits);
                returnList.Add(fluffyUnits);
                returnList.Add(iceMonkeyUnits);
                returnList.Add(soldierUnits);
                returnList.Add(cuteDogUnits);
                returnList.Add(redNinjaUnits);
                returnList.Add(blackNinjaUnits);

                returnList.Add(mystUnit1);
                returnList.Add(mystUnit2);
                returnList.Add(mystUnit3);
                returnList.Add(mystUnit4);
                returnList.Add(mystUnit5);

                returnList.Add(possessedUnits);

                returnList.Add(clericUnits);
                returnList.Add(bardUnits);

                return returnList;
            } 
        }

        public static void RandomizeTexture(this ActorBase target)
		{
			for(int i = 0; i < actorTextureLists.Count; i++) {
				if(actorTextureLists[i].Contains(target)) {
                    actorTextureLists[i].Remove(target);
                }
			}
            HashSet<ActorBase> listToAddTo = DejMod.actorTextureLists.GetRandom();
            listToAddTo.Add(target);
            target.setHeadSprite(null);
            //target.loadTexture();
        }

        public static void init()
        {
            patchMethod(
                AccessTools.Method(typeof(ActorBase), "getUnitTexture"),
                AccessTools.Method(typeof(DejMod), "getUnitTexture_Prefix"),
                true);

            patchMethod(
                AccessTools.Method(typeof(ActorBase), "findHeadSprite"),
                AccessTools.Method(typeof(DejMod), "findHeadSprite_Prefix"),
                true);

            patchMethod(
                AccessTools.Method(typeof(ActorBase), "updateAnimation"),
                AccessTools.Method(typeof(DejMod), "updateAnimation_Prefix"),
                true);
        }

        public static bool getUnitTexture_Prefix(ActorBase __instance, ref string __result)
        {
            if (mageUnits.Contains(__instance))
            {
                //Debug.Log("Using prefix mageUnits");
                __result = "races/orc/mage1";
                return false;
            }
            if (fluffyUnits.Contains(__instance))
            {
                //Debug.Log("Using prefix fluffyUnits");
                __result = "races/orc/fluffy";
                return false;
            }
            if (iceMonkeyUnits.Contains(__instance))
            {
                //Debug.Log("Using prefix iceMonkeyUnits");
                __result = "races/orc/iceMonkey";
                return false;
            }
            if (soldierUnits.Contains(__instance))
            {
                //Debug.Log("Using prefix soldierUnits");
                __result = "races/orc/soldier";
                return false;
            }
            if (cuteDogUnits.Contains(__instance))
            {
                //Debug.Log("Using prefix cuteDogUnits");
                __result = "races/orc/cuteDog";
                return false;
            }
            if (redNinjaUnits.Contains(__instance))
            {
                //Debug.Log("Using prefix redNinjaUnits");
                __result = "races/orc/redNinja";
                return false;
            }
            if(blackNinjaUnits.Contains(__instance)) {
                //Debug.Log("Using prefix ninjaUnits");
                __result = "races/orc/ninja";
                return false;
            }

            if(mystUnit1.Contains(__instance)) {
                __result = "races/orc/mystUnit1";
                return false;
            }
            if(mystUnit2.Contains(__instance)) {
                __result = "races/orc/mystUnit2";
                return false;
            }
            if(mystUnit3.Contains(__instance)) {
                __result = "races/orc/mystUnit3";
                return false;
            }
            if(mystUnit4.Contains(__instance)) {
                __result = "races/orc/mystUnit4";
                return false;
            }
            if(mystUnit5.Contains(__instance)) {
                __result = "races/orc/mystUnit5";
                return false;
            }
            if(possessedUnits.Contains(__instance)) {
                __result = "races/orc/possessed";
                return false;
            }

            if(clericUnits.Contains(__instance)){
                __result = "races/orc/cleric";
                return false;
            }
            if(bardUnits.Contains(__instance)){
                __result = "races/orc/bard";
                return false;
            }

            return true;
        }

        public static bool findHeadSprite_Prefix(ActorBase __instance)
        {
            //__instance.CallMethod("setHeadSprite", ActorAnimationLoader.getHead("actors/races/orc/mageHead"));
            // __instance.CallMethod("setHeadSprite", null);
            // return false;
            if (!bardUnits.Contains(__instance) && !clericUnits.Contains(__instance) && !mageUnits.Contains(__instance) && !fluffyUnits.Contains(__instance) && !iceMonkeyUnits.Contains(__instance) && !soldierUnits.Contains(__instance) && !cuteDogUnits.Contains(__instance) && !redNinjaUnits.Contains(__instance))
            {
                return true;
            }
            return false;
        }

        public static bool updateAnimation_Prefix(ActorBase __instance)
        {
            if (iceMonkeyUnits.Contains(__instance) || soldierUnits.Contains(__instance))
            {
                var pAnimData = (AnimationDataUnit)Reflection.GetField(__instance.GetType(), __instance, "actorAnimationData");
                var sprites = (Dictionary<string, Sprite>)Reflection.GetField(typeof(AnimationDataUnit), pAnimData, "sprites");
                string idleText = "";
                /* original
                if (__instance.nextStepPosition.y > __instance.currentPosition.y)
                {
                    ActorAnimation anim = (ActorAnimation)Reflection.CallStaticMethod(typeof(ActorAnimationLoader), "createAnim", 1, sprites, "up_walk_0,up_walk_1,up_walk_2,up_walk_3", 0.3f);
                    Reflection.SetField(pAnimData, "walking", anim);
                    if (string.IsNullOrEmpty(idleText))
                    {
                        idleText = "up_walk_0";
                    }
                    

                }else if (__instance.nextStepPosition.y < __instance.currentPosition.y)
                {
                    ActorAnimation anim = (ActorAnimation)Reflection.CallStaticMethod(typeof(ActorAnimationLoader), "createAnim", 1, sprites, "down_walk_0,down_walk_1,down_walk_2,down_walk_3", 0.3f);
                    Reflection.SetField(pAnimData, "walking", anim);
                    if (string.IsNullOrEmpty(idleText))
                    {
                        idleText = "down_walk_0";
                    }
                    

                } else if (__instance.nextStepPosition.y == __instance.currentPosition.y)
                {
                    ActorAnimation anim = (ActorAnimation)Reflection.CallStaticMethod(typeof(ActorAnimationLoader), "createAnim", 1, sprites, __instance.stats.animation_walk, 0.3f);
                    Reflection.SetField(pAnimData, "walking", anim);
                    if (string.IsNullOrEmpty(idleText))
                    {
                        idleText = "walk_0";
                    }
                    
                }
                */

                // modified, only using left/right for now, up/down bugs out from manual control
                ActorAnimation anim = ActorAnimationLoader.createAnim(1, sprites, __instance.stats.animation_walk, 0.3f);
                pAnimData.walking = anim;
                if(string.IsNullOrEmpty(idleText)) {
                    idleText = "walk_0";
                }

                ActorAnimation idleAnim = ActorAnimationLoader.createAnim(2, sprites, idleText, 0.1f);
                pAnimData.idle = idleAnim;
                idleText = "";
            }
            return true;
        }

        public static void patchMethod(MethodInfo original, MethodInfo patch, bool isPrefix)
        {
            if(isPrefix)
            {
                harmony.Patch(original, prefix: new HarmonyMethod(patch));
            }else
            {
                harmony.Patch(original, postfix: new HarmonyMethod(patch));
            }
            
        }
    }
}