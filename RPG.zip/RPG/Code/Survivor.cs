﻿using NCMS.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RPG;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace RPG {
	public class Survivor { // inspired by Vampire Survivors

		//
		public static WorldTile GetTileFromAngle(WorldTile pStartingTile, float pAngle, float pDistance)
		{
			WorldTile returnTile = null;
			var x = pDistance * Mathf.Cos(pAngle * Mathf.Deg2Rad);
			var y = pDistance * Mathf.Sin(pAngle * Mathf.Deg2Rad);
			var newPosition = pStartingTile.posV3;
			newPosition.x += x;
			newPosition.y += y;
			WorldTile tileFound = MapBox.instance.GetTile((int)newPosition.x, (int)newPosition.y);
			if(tileFound != null) {
				returnTile = tileFound;
				//MapBox.instance.flashEffects.flashPixel(tileFound);
			}
			else {
				Debug.Log("Tile from angle not found");
			}

			return returnTile;
		}

		// SpriteGroupSystemStatusEffect.showEffectsFor
		// basically hooking into statuseffect.updateZFlip
		// strange way of going about this, but whatever works
		public static bool showEffectsFor_Prefix(BaseSimObject pSimObject, SpriteGroupSystemStatusEffect __instance)
		{
			foreach(StatusEffectData statusEffectData in pSimObject.activeStatus_dict.Values) {
				Debug.Log("statusEffectData ID: " + statusEffectData.asset.id);
				StatusEffect status = statusEffectData.asset;

				if(!string.IsNullOrEmpty(statusEffectData.asset.texture)) {

					
					// try keeping most status behind unit somehow
					//__instance.transform.position = new Vector3(__instance.transform.position.x, __instance.transform.position.y, __instance.simObject.transform.position.z + 1f);


					/*
					if(angle > -5 && angle < 30) {
						__instance.transform.rotation = Quaternion.Euler(new Vector3(0, y, angle - 90f));
					}
					*/

					// default method
					GroupSpriteObject next = __instance.getNext();
						Sprite sprite = statusEffectData.asset.spriteList[statusEffectData.anim_frame];
						next.setSprite(sprite);
						statusEffectData.flipX = statusEffectData.flipX;
						next.setScale(pSimObject.currentScale);
						__instance.t_pos.x = pSimObject.curTransformPosition.x;
						__instance.t_pos.y = pSimObject.curTransformPosition.y;
						__instance.t_pos.z = 0f;
						__instance.checkRotation(next, pSimObject);
						__instance.t_pos.z = pSimObject.curTransformPosition.z + __instance.z_pos;
						next.setPosOnly(ref __instance.t_pos);
					}

				if(status.id == "gun" || status.id == "gun2") {
					// try rotating whole status object/sprite around
					Vector3 mousePos = MapBox.instance.getMousePos();
					mousePos.z = Camera.main.transform.position.z - __instance.transform.position.z; //5.23f;

					Vector3 objectPos = Camera.main.WorldToScreenPoint(__instance.transform.position);
					mousePos.x = mousePos.x - objectPos.x;
					mousePos.y = mousePos.y - objectPos.y;

					float angle = Mathf.Atan2(mousePos.y, mousePos.x) * Mathf.Rad2Deg;
					float dAngle = angle; // original angle to use for tile targeting, in case original angle var changes
					Debug.Log(dAngle);
					float y; // invert things if its on "flipped" side; alternative: keep gun on right side, check if actor is flipped, prevent gun rotation 
					float angleAdjust = -90; // for some reason its 90 degrees off lol
					if((angle < 180 && angle > 90) || (angle > -180 && angle < -90)) {
						y = -180;
						angle = Mathf.Atan2(mousePos.y, -mousePos.x) * Mathf.Rad2Deg;
					}
					else {
						y = 0;
					}

					//
					bool limitFreedom = false; // visually looks better, gameplay feels worse
					if(limitFreedom) {
						// only rotate the gun when its within acceptable ranges
						if((dAngle > -5f && dAngle < 30f) || (dAngle < -175f && dAngle > -180f) || (dAngle < 180f && dAngle > 160f)) {
							__instance.transform.rotation = Quaternion.Euler(new Vector3(0, y, angle + angleAdjust));
							WorldTile tileAtDistance = GetTileFromAngle(pSimObject.currentTile, dAngle, 6f);

							if(tileAtDistance != null && Input.GetMouseButtonDown(0)) {
								fireBullet(pSimObject, tileAtDistance);
							}
						}
					}
					else {
						__instance.transform.rotation = Quaternion.Euler(new Vector3(0, y, angle + angleAdjust));
						WorldTile tileAtDistance = GetTileFromAngle(pSimObject.currentTile, dAngle, 6f);

						if(tileAtDistance != null && Input.GetMouseButton(0)) {
							// fire constantly, downside is 1 static variable for lastFire, multiple guns not supported?
							if(lastFireTime == 0f || lastFireTime < Time.realtimeSinceStartup + fireDelay) {
								fireBullet(pSimObject, tileAtDistance);
								lastFireTime = Time.realtimeSinceStartup;

							}
						}
					}

				}
			}
			return false;
		}
		public static float lastFireTime = 0f;
		public static float fireDelay = 1f;// scale with gun upgrade

		// fire bullet method for using with gun ability
		public static bool fireBullet(BaseSimObject pAttacker, WorldTile pTargetTile)
		{
			int targetAmount = 1;
			int gunUpgradeLevel = upgradeLevel("manual_gun");
			int gunRange = 1 + gunUpgradeLevel; // scale them with pTarget level
			WorldTile tileToCheckTargetsFrom = pTargetTile;
			WorldTile mouseTile = MapBox.instance.getMouseTilePos();
			if(mouseTile != null) {
				tileToCheckTargetsFrom = mouseTile;
			}
			List<Actor> targetsList = RPG_Main.validTargets(true, tileToCheckTargetsFrom, gunRange).ToList();
			for(int i = 0; i < targetAmount; i++) {
				Actor targetActor = null;
				if(targetsList.Count > 1) {
					targetActor = targetsList.GetRandom();
					targetsList.Remove(targetActor);
				}
				else {
					targetsList = RPG_Main.validTargets(true, tileToCheckTargetsFrom, gunRange).ToList();
					if(targetsList.Count < 1) {
						//break;
					}
					else {
						targetActor = targetsList.GetRandom();
					}
				}
				if(targetActor != null && targetActor != pAttacker && targetActor.data.alive) {
					float pZ = 0f;
					if(pAttacker.isInAir()) {
						pZ = pAttacker.getZ();
					}
					//might want to change bullet pStart to be inside gun sprite, but dunno how yet
					Projectile bullet = MapBox.instance.stackEffects.startProjectile(pAttacker.currentPosition, targetActor.currentPosition, "shotgun_bullet", pZ);
					bullet.byWho = pAttacker;
					bullet.setStats(pAttacker.curStats); // might be too much dmg?
					bullet.targetObject = targetActor;
				}
				if(targetActor == null) {
					float pZ = 0f;
					if(pAttacker.isInAir()) {
						pZ = pAttacker.getZ();
					}
					Projectile bullet = MapBox.instance.stackEffects.startProjectile(pAttacker.currentPosition, pTargetTile.posV3, "shotgun_bullet", pZ);
					bullet.byWho = pAttacker;
					bullet.setStats(pAttacker.curStats); // might be too much dmg?
					}
				}
			return true;
		}


		public static void addTraitToLocalizedLibrary(string id, string description)
		{
			string language = LocalizedTextManager.instance.language;
			Dictionary<string, string> localizedText = LocalizedTextManager.instance.localizedText;
			if(language == "en") {
				localizedText.Add("trait_" + id, id);
				localizedText.Add("trait_" + id + "_info", description);
			}
		}
		public void addAssets(){
			if(hasAddedTraits == false && AssetManager.traits != null) {
				AddSurvivorTraitAssets();
			}

			if(hasAddedResources == false && AssetManager.resources != null) {
				AddResourceAssets();
			}
		}
		public bool hasAddedTraits = false;
		public void AddSurvivorTraitAssets()
		{
			ActorTraitLibrary traitLibrary = AssetManager.traits;

			ActorTrait autoGunTrait = new ActorTrait();
			autoGunTrait.id = "auto_gun";
			autoGunTrait.path_icon = "temp"; // need better icon
			autoGunTrait.action_special_effect += autoGunEffect;
			AssetManager.traits.add(autoGunTrait);
			addTraitToLocalizedLibrary(autoGunTrait.id, "Shoots bullets");

			ActorTrait autoLightningTrait = new ActorTrait();
			autoLightningTrait.id = "auto_lightning";
			autoLightningTrait.path_icon = "ui/Icons/dirt"; // need better icon
			autoLightningTrait.action_special_effect += autoLightningEffect;
			AssetManager.traits.add(autoLightningTrait);
			addTraitToLocalizedLibrary(autoLightningTrait.id, "Zaps enemies");

			Debug.Log("Added traits");
			hasAddedTraits = true;
		}

		public void AddResourceAssets(){
			ResourceLibrary resourceLibrary = AssetManager.resources;
			ResourceAsset dirt = new ResourceAsset
			{
			id = "dirt",
			type = ResType.Food, // lol
			path_icon = "dirt",
			path_unit_item = "bag_food",
			};
			resourceLibrary.add(dirt);

			ResourceAsset sand = new ResourceAsset
			{
			id = "sand",
			type = ResType.Food,
			path_icon = "sand",
			path_unit_item = "bag_food",
			};
			resourceLibrary.add(sand);

			ResourceAsset glass = new ResourceAsset
			{
			id = "glass",
			type = ResType.Food,
			path_icon = "glass",
			path_unit_item = "bag_food",
			};
			resourceLibrary.add(glass);

			ResourceAsset milk = new ResourceAsset{
				id = "milk",
				type = ResType.Food,
				path_icon = "milk",
				path_unit_item = "bag_food",
			};
			resourceLibrary.add(milk);

			ResourceAsset eggs = new ResourceAsset{
				id = "eggs",
				type = ResType.Food,
				path_icon = "egg",
				path_unit_item = "bag_food",
			};
			resourceLibrary.add(eggs);

			ResourceAsset cake = new ResourceAsset{
				id = "cake",
				type = ResType.Food,
				path_icon = "cake",
				path_unit_item = "bag_food",
			};
			resourceLibrary.add(cake);
			

			// not a real "custom" resource, but maxim only half-added it


			hasAddedResources = true;
		}

		public bool hasAddedResources;

		// trait effect, goes every 1 sec by default actor.specialtimer
		public static bool autoGunEffect(BaseSimObject pTarget, WorldTile pTile = null)
		{
			int upgradeLevelBullet = upgradeLevel("auto_gun");
			int bulletCount = 1 + upgradeLevelBullet; // scale # with ability level

			List<Actor> targetsList = RPG_Main.validTargets(true).ToList();
			for(int i = 0; i < bulletCount; i++) {
				Actor targetActor;
				if(targetsList.Count > 1) {
					targetActor = targetsList.GetRandom();
					targetsList.Remove(targetActor);
				}
				else {
					targetsList = RPG_Main.validTargets(true).ToList();
					if(targetsList.Count < 1) {
						break;
					}
					else {
						targetActor = targetsList.GetRandom();
					}
				}
				if(targetActor != null && targetActor != RPG_Main.controlledActor && targetActor.data.alive) {
					float pZ = 0f;
					if(pTarget.isInAir()) {
						pZ = pTarget.getZ();
					}
					/*
					Vector2 newPoint = new Vector2();
					Vector2 vector = targetActor.currentPosition;
					newPoint.x = vector.x;
					newPoint.y = vector.y + 0.1f;
					newPoint.x += Toolbox.randomFloat(-(pTarget.curStats.size + 1f), pTarget.curStats.size + 1f);
					newPoint.y += Toolbox.randomFloat(-pTarget.curStats.size, pTarget.curStats.size);
					Vector3 newPoint2 = Toolbox.getNewPoint(pTarget.currentPosition.x, pTarget.currentPosition.y, vector.x, vector.y, pTarget.curStats.size, true);
					*/
					Projectile bullet = MapBox.instance.stackEffects.startProjectile(pTarget.currentPosition, targetActor.currentPosition, "shotgun_bullet", pZ);
					bullet.byWho = pTarget;
					bullet.setStats(pTarget.curStats);
					bullet.targetObject = targetActor;
				}
			}
			return true;
		}

		public static bool autoLightningEffect(BaseSimObject pTarget, WorldTile pTile = null)
		{
			int upgradeLevelZap = upgradeLevel("auto_lightning");

			int zapCount = 1 + upgradeLevelZap;
			int zapDamage = 1 + (upgradeLevelZap / 2); // 10 upgrades = 6dmgx10targ, 
			int zapsDone = 0;

			List<Actor> targetsList = RPG_Main.validTargets(true).ToList();
		
			for(int i = 0; i < zapCount; i++) {
				Actor targetActor;
				if(targetsList.Count > 1) { // check if we have targets
					targetActor = targetsList.GetRandom();
					targetsList.Remove(targetActor); 
				}
				else {
					targetsList = RPG_Main.validTargets(true).ToList();
					if(targetsList.Count < 1) {
						break; // if we have any now, if not, break out of this entirely
					}
					else {
						targetActor = targetsList.GetRandom();
					}
				}
				if(targetActor.data.alive) {
					BaseEffectController baseEffectController = MapBox.instance.stackEffects.get("lightning");
					BaseEffect baseEffect = ((baseEffectController != null) ? baseEffectController.spawnAt(targetActor.currentTile, 0.15f) : null);
					zapsDone++;
					//MapAction.damageWorld(pTile, pRad, AssetManager.terraform.get("lightning")); // damage individuals instead
					if(targetActor != null && targetActor.data.alive) {
						targetActor.getHit(zapDamage);
					}
					baseEffect.sprRenderer.flipX = Toolbox.randomBool();
				}
			}
			if(zapsDone > 0) {
				Sfx.play("lightning", true, -1f, -1f); // only 1 lightning sound for whole spell
			}
			return true;
		}

		public static bool tryToAttack_Prefix(BaseSimObject pTarget, Actor __instance, ref bool __result)
		{
			if(Survivor.timeSinceStart != 0) { // assumes all creatures are only attacking player at this point
				if(RPG_Main.controlledActor != null && RPG_Main.controlledActor != __instance) {
					if(isInAttackRangeToControlled(__instance)) {
						__result = true;
						Debug.Log("set to true");
						return false;
					}
				}
				else {
					__result = false;
					Debug.Log("set to false");
					return false;
				}

			}
			else {
				Debug.LogError("tryToAttack_Postfix failed to override, running normal");
				return true;
			}
			Debug.Log("trytoAttack somehow made it further than it should!");
			return true;
		}

		public void UpdateMonsterMovement() // make everyone attack player
		{
			if(RPG_Main.controlledActor != null) {
				List<Actor> actorList = RPG_Main.validTargets().ToList();
				
				usedTiles = new List<WorldTile>();
				for(int i = 0; i < actorList.Count; i++) {
					Actor targetActor = actorList[i];
					if(targetActor.haveStatus("sleep")) {
					}
					else {
						targetActor.tryToAttack(RPG_Main.controlledActor); // creatures try to attack
						RPG_Main.aiMoveAndWait(targetActor, RPG_Main.controlledActor.currentTile); // and then move closer
					}
				}
			}
		}

		public static List<WorldTile> usedTiles = new List<WorldTile>();	

		//spent too much time on this and lots of little issues, re-evaluate later
		public static bool isInAttackRangeToControlled(Actor attacker)
		{
			if(RPG_Main.controlledActor != null && attacker != RPG_Main.controlledActor) {
				return Toolbox.DistVec3(attacker.currentPosition, RPG_Main.controlledActor.currentPosition) < 4f; //attacker.curStats.range ;
			}
			else {
				return false;
			}
		}

		//disable delay between hits
		public static bool startShake_Prefix(float pTimer, float pVol, bool pHorizontal, bool pVertical, Actor __instance)
		{
			if(__instance == RPG_Main.controlledActor && timeSinceStart != 0) {
				__instance.shakeHorizontal = pHorizontal;
				__instance.shakeVertical = pVertical;
				__instance.shakeTimer.startTimer(0f);
				__instance.shakeVolume = pVol;
				return false;
			}
			else {
				return true;
			}
			
		}

		// vamp survivor has 500 creatures max
		public static int maxCreatureCountFromDifficulty => 10 + (timeSinceStart / 2); // 10 sec = 15max, 120sec = 70max, 600sec = 310max etc
		public static int creaturesToSpawnEachUpdate => 1 + (maxCreatureCountFromDifficulty / 10); // 10sec = 2, 120sec = 13, 600sec = 61
		public static int creaturesToSpawnOverride = 0;

		public int creaturesToActuallySpawn()
		{
			if(creaturesToSpawnOverride != 0) {
				return creaturesToSpawnOverride;
			}
			else {
				return creaturesToSpawnEachUpdate;
			}
		}

		public List<string> monstersToSpawn = new List<string>() { "unit_orc" }; // only orc needed if reskins are applied
																				 // possibly only change texture IF orc, allow other animals too
		public static int bossesToSpawn = 0;
		public static int lastBossAmount = 0;
		public void UpdateMonsterSpawn()
		{
			int minutes = (timeSinceStart / 60);
			if(minutes % 3 == 0) {
				if((minutes / 3) > lastBossAmount){
					bossesToSpawn = (minutes / 3);
					//Debug.Log("+3 minutes detected, bosses spawning: " + bossesToSpawn.ToString());
					lastBossAmount = bossesToSpawn;
				}

			}
			if(MapBox.instance.units.Count < maxCreatureCountFromDifficulty) {
				for(int i = 0; i < creaturesToActuallySpawn(); i++) {
					if(MapBox.instance.units.Count < maxCreatureCountFromDifficulty) {
						string monsterID = monstersToSpawn.GetRandom();
						WorldTile spawnTile = MapBox.instance.tilesList.GetRandom();
						// keep monster spawns a certain distance away
						if(Toolbox.DistTile(spawnTile, RPG_Main.lastTile) > 20f) {
							Actor newMonster = MapBox.instance.createNewUnit(monsterID, spawnTile, null, 5f, null);
							ActorTrait customTrait = new ActorTrait(); // create trait that applies "balanced" stats
							customTrait.id = "customT" + monsterID;
							customTrait.baseStats = IntendedStats(AssetManager.unitStats.get(monsterID).baseStats); // newMonster.curStats
							if(bossesToSpawn > 0) {
								customTrait.id = "customT" + monsterID + "Boss";
								customTrait.baseStats.speed = 20f;
								customTrait.baseStats.damage = 20;
								//customTrait.baseStats.size = 1.25f;
								customTrait.baseStats.scale = 0.75f;
								bossesToSpawn--;
							}
							AssetManager.traits.add(customTrait); // constant update and replace
							newMonster.data.traits = new List<string>();
							newMonster.s_special_effect_traits.Clear(); // reset any potential traits // changed 14.0
							newMonster.addTrait(customTrait.id);
							if(monsterID == "unit_orc") {
								newMonster.RandomizeTexture(); // only orcs take these textures
							}
						}
					}
				}
				creaturesToSpawnOverride = 0; // after potential override, reset
			}
		}

		//public List<string> monsterTraits = new List<string>();
		
		public static int timeStarted = 0; // set to realtimeblah whenever mode/round starts
		public static int timeSinceStart => (int)Time.realtimeSinceStartup - timeStarted;

		public int startingHealth = 1;
		public static int difficultyScaling = 10; // higher = easier
		public int difficultyHealth => timeSinceStart / difficultyScaling; // 5 = 10 seconds = +2hp, 120seconds = +24, 600sec = +120 etc

		public BaseStats IntendedStats(BaseStats original)
		{
			int intendedHealth = difficultyHealth;
			BaseStats returnBaseStats = new BaseStats();

			returnBaseStats.health = intendedHealth - original.health;
			return returnBaseStats;
		}

		public bool hasStarted;
		public static bool hasStartedStatic;

		public void StartRound()
		{
			GUIConstruction.ResetForSurvivor();
			timeStarted = (int)Time.realtimeSinceStartup;
			lastMovementUpdate = timeStarted;
			lastSpawnUpdate = timeStarted;

			//UpdateStatsFromDifficulty();
			hasStarted = true;
			hasStartedStatic = true;
			// purge
			foreach(Actor nonControlled in RPG_Main.validTargets()) {
				nonControlled.killHimself();
			}
			// need to detect round start and reset/stop blah blah
		}
		public float lastMovementUpdate = 0f; //move/attack merged
		public float lastSpawnUpdate = 0f;
		
		public void Update()
		{
			float timeNow = Time.realtimeSinceStartup;
			//

			if(lastMovementUpdate + 0.75f < timeNow) { //update movement over time
				UpdateMonsterMovement();
				lastMovementUpdate = timeNow;
			}

			if(lastSpawnUpdate + 5f < timeNow) { //spawn monsters over time
				//UpdateStatsFromDifficulty();
				UpdateMonsterSpawn();
				lastSpawnUpdate = timeNow;
			}

			/*
			if(TWrecks_Main.controlledActor.data.alive == false) {
				Debug.Log("detected death, resetting");
				hasStarted = false;
				timeStarted = 0;
				equippedUpgrades = new Dictionary<string, int>();
			}
			*/
		}

		public static int levelsPerUpgrade = 1;

		private static float XStep = 65f; // 65 for 3, 34 for 5
		public static List<string> upgradeList = new List<string>() { "auto_lightning", "boat", "auto_gun" };
		public static Dictionary<string, int> equippedUpgrades = new Dictionary<string, int>();
		public static List<string> equippedUpgradeList => equippedUpgrades.Keys.ToList(); // or just actor.traits i guess

		public static int upgradeLevel(string upgradeName)
		{
			int returnInt = 0;
			if(equippedUpgrades.ContainsKey(upgradeName) == false) {
				Debug.Log("checking level and skill isnt in dict!");
			}
			else {
				returnInt = equippedUpgrades[upgradeName];
			}
			return returnInt;
		}

		bool hasAddedWindowUpgrade;
		public void OpenUpgradeWindow()
		{
			Config.paused = true;
			#region upgradeWindow
			Debug.Log("opening upgrade window");
			if(hasAddedWindowUpgrade == true) {
				Windows.ShowWindow("survivor_upgrades"); // show window if it exists
			}
			else { // create window from scratch
				var upgradeWindow = NCMS.Utils.Windows.CreateNewWindow("survivor_upgrades", "");
				
				/*
				PowerButton upgradeButton = PowerButtons.CreateButton("upgrade_" + upgradableTrait.id, traitSprite, upgradableTrait.id, "", Vector2.zero, ButtonType.Click, null, delegate {
					if(equippedUpgrades.ContainsKey(upgradableTrait.id) == false) {
						Debug.Log("should add upgrade to player");
						equippedUpgrades.Add(upgradableTrait.id, 1);
					}
					else {
						Debug.Log("should level up upgrade");
						int currentLevel = equippedUpgrades[upgradableTrait.id];
						equippedUpgrades[upgradableTrait.id] = currentLevel + levelsPerUpgrade;
					}
					Config.paused = false;
					//update trait with new level	
				});
				*/
				#region var description

				string hlColor = "#65BD00FF";

				var description = "hi";
				#endregion
				//
				upgradeWindow.transform.Find("Background").Find("Scroll View").gameObject.SetActive(true);

				//ActorTrait upgradableTrait = AssetManager.traits.get(upgradeList.GetRandom());
				//Sprite traitSprite = (Sprite)Resources.Load("ui/Icons/" + upgradableTrait.path_icon, typeof(Sprite));

				Transform Background = upgradeWindow.transform.Find("Background"); // change upgradeWindow to the right window var name

				Image backGroundImage = Background.GetComponent<Image>();
				Sprite newsprite = (Sprite)Resources.Load("ui/buttonLong", typeof(Sprite)); // load new window background (simple button)
				backGroundImage.sprite = newsprite;

				Background.transform.localScale = new Vector3(0.75f, 0.75f);

				var closeObject = Background.Find("CloseBackgound").gameObject; // missing R in name lmao
				closeObject.transform.localPosition = new Vector3(84.702f, 42.0593f);

				var gradientImageObject = Background.Find("Scrollgradient").gameObject;
				Image gradientImage = gradientImageObject.GetComponent<Image>();
				gradientImage.enabled = false; // disable shadow for usual window

				var scrollRectObject = Background.Find("Scroll View").gameObject;
				scrollRectObject.transform.localPosition = new Vector3(5, -104, 0);
				scrollRectObject.transform.localScale = new Vector3(1.25f, 1.25f);
				ScrollRect scrollRect = scrollRectObject.GetComponent<ScrollRect>();
				scrollRect.vertical = false; // disable vertical drag of normal window content



				var name = upgradeWindow.transform.Find("Background").Find("Name").gameObject;
				var nameText = name.GetComponent<Text>();
				nameText.gameObject.SetActive(false);

				var Content = Background.Find("Scroll View").Find("Viewport").Find("Content");
				for(int i = 0; i < Content.transform.childCount; i++) {
					GameObject.Destroy(Content.transform.GetChild(i).gameObject);
				}

				var traitButton = NCMS.Utils.GameObjects.FindEvenInactive("TraitButton").GetComponent<TraitButton>();

				var rect = Content.GetComponent<RectTransform>();
				rect.pivot = new Vector2(0, 1);
				rect.sizeDelta = new Vector2(0, Mathf.Abs(GetPosByIndex(upgradeList.Count).y) + 100);

				var backgroundRect = Background.GetComponent<RectTransform>();
				//rect.pivot = new Vector2(0, 1);
				rect.sizeDelta = new Vector2(216, 265); // new Vector2(216, 265) original

				for(int i = 0; i < upgradeList.Count; i++) {
					//var hl = AddHighLight(i, Content, UNIT.haveTrait(traitsArray[i].id));

					loadTraitButton(upgradeList[i], i, upgradeList.Count, traitButton, Content.transform, upgradeTraitButton);
				}
				#endregion
				hasAddedWindowUpgrade = true;
				Windows.ShowWindow("survivor_upgrades");
			}
		}

		// copy upgrade window and do stats

		private static float startXPos = 60f; // do something based on upgrade list/used ones
		private static int countInRow => upgradeList.Count;
		private static float startYPos = -22.5f;
		private static float YStep = -28.5f;
		private static Vector2 GetPosByIndex(int index)
		{
			float x = (index % countInRow) * XStep + startXPos;
			float y = (Mathf.RoundToInt(index / countInRow) * YStep) + startYPos;

			return new Vector2(x, y);
		}

		private static void loadTraitButton(string pID, int pIndex, int pTotal, TraitButton traitButtonPref, Transform parent, Action<TraitButton> callback)
		{
			TraitButton traitButton = GameObject.Instantiate<TraitButton>(traitButtonPref, parent);
			traitButton.load(pID);

			traitButton.transform.localPosition = GetPosByIndex(pIndex); // set button in right spot

			var button = traitButton.gameObject.GetComponent<Button>();
			button.onClick.AddListener(() => callback(traitButton));
		}

		private static void upgradeTraitButton(TraitButton buttonPressed)
		{
			var trait = (ActorTrait)buttonPressed.trait_asset;
			
			if(RPG_Main.controlledActor != null) {
				if(RPG_Main.controlledActor.haveTrait(trait.id)) {
					int currentLevel = equippedUpgrades[trait.id];
					equippedUpgrades[trait.id] = currentLevel + levelsPerUpgrade;
				}
				else {
					RPG_Main.controlledActor.addTrait(trait.id);
					equippedUpgrades.Add(trait.id, 1);
				}
			}
		}

	}
}
