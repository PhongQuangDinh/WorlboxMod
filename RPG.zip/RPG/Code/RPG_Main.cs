using System.Diagnostics;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using NCMS;
using NCMS.Utils;
using HarmonyLib;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UIElements;
using static UnityEngine.GraphicsBuffer;
using ai;
using RPG;
using UnityEngine.EventSystems;

namespace RPG
{


    
    [ModEntry]
    public class RPG_Main : MonoBehaviour
    {

        public const string pluginGuid = "cody.worldbox.rpg";
        public const string pluginName = "RPG";
        public const string pluginVersion = "0.0.0.4";
        
        public static UnitClipboard_Main clipboard = new UnitClipboard_Main();
        public void Awake()
        {
            HarmonyPatchSetup();
            SettingSetup();
            BankSetup();
            //if(ModExists("Plenty o Biomes")){ }
        }

        //after splitting sheets into individual sprites, finish the rest
        public void MakeBuildingsOutOfDirectory()
        {
            string newBuildingDir = Directory.GetCurrentDirectory() + "\\Mods//RPG//GameResources//Test//";
            string actualBuildingDir = Directory.GetCurrentDirectory() + "\\Mods//RPG//GameResources//buildings//";
            string[] files = Directory.GetFiles(Directory.GetCurrentDirectory() + "\\Mods//RPG//GameResources//Test//"); //+ "\\Mods//RPG//GameResources//Test//";
            var info = new DirectoryInfo(newBuildingDir);
            FileInfo[] fileInfo = info.GetFiles();
            foreach (FileInfo file in fileInfo)
            {
                if (Directory.Exists(actualBuildingDir + file.Name) == false)
                {
                    string newDirName = actualBuildingDir + file.Name.Replace(".png", "");
                    Directory.CreateDirectory(newDirName);
                    File.Copy(file.FullName, newDirName + "//main_0.png", true);
                    File.Copy(file.FullName, newDirName + "//mini_0.png", true);
                    File.Copy(file.FullName, newDirName + "//ruin_0.png", true);
                    File.Copy(file.FullName, newDirName + "//shadow_0.png", true);
                }
            }
        }

        //was going to auto detect and load compatibility stuff
        //turned out to be even easier than expected, still might be useful later
        public bool ModExists(string modName)
        {
            string path = Directory.GetCurrentDirectory() + "\\Mods//"; // for ncms only
            if (Directory.Exists(path))
            {
                FileInfo[] fileArray3 = new DirectoryInfo(path).GetFiles();
                for (int i = 0; i < fileArray3.Length; i++)
                {
                    if (fileArray3[i].Extension.Contains("mod"))
                        if (fileArray3[i].Name.Contains(modName))
                        {
                            return true;
                        }
                }
            }
            return false;
        }

        // keep track of buildings we've taken resources from and what should be left
        public static Dictionary<Building, int> buildingsWithResourcesLeft = new Dictionary<Building, int>();

        bool hasAddedBuildings;
        bool hasAddedEffects;
        bool hasAddedProjectiles; // try custom projectiles now 
        bool isBoat;
        bool isInHomeWorld;

        // those are mine
        bool isGeneral;
        Actor lastControlActor;
        public void LoadRandomWorld()
        {
            clipboard.CopyUnit(controlledActor);
            controlledActor.killHimself();
            controlledActor = null;
            if (isInHomeWorld)
            {
                SaveManager.setCurrentSlot(50); // home slot
                MapBox.instance.saveManager.clickSaveSlot();
            }
            MapBox.instance.generateNewMap();
            SmoothLoader.add(delegate
            {
                WorldTile TargetTile = MapBox.instance.tilesList.GetRandom();
                while (TargetTile.Type.liquid || (TargetTile.building != null && TargetTile.building.stats.id.Contains("Portal"))) // prevent overriding existing portals
                {
                    TargetTile = MapBox.instance.tilesList.GetRandom();
                }
                MapBox.instance.addBuilding("homePortal", TargetTile, null, false, false, BuildPlacingType.New);

                WorldTile TargetTile2 = MapBox.instance.tilesList.GetRandom();
                while (TargetTile2.Type.liquid || (TargetTile2.building != null && TargetTile2.building.stats.id.Contains("Portal"))) // prevent overriding existing portals
                {
                    TargetTile2 = MapBox.instance.tilesList.GetRandom();
                }
                {
                    TargetTile2 = MapBox.instance.tilesList.GetRandom();
                }
                MapBox.instance.addBuilding("randomPortal", TargetTile2, null, false, false, BuildPlacingType.New);

                WorldTile TargetTile3 = MapBox.instance.tilesList.GetRandom();
                while (TargetTile3.Type.liquid)
                {
                    TargetTile3 = MapBox.instance.tilesList.GetRandom();
                }
                controlledActor = clipboard.PasteUnit(TargetTile3, clipboard.selectedUnitToPaste);
                isInHomeWorld = false;
            }, "add_portals", false, 0.001f);
            // delay save? something
            // add portal building -> save on exit world
            //settings.hasCreatedHome = true;
        }
        public void LoadHomeWorld()
        {
            clipboard.CopyUnit(controlledActor);
            controlledActor = null;
            if (settings.hasCreatedHome == false)
            {
                UnityEngine.Debug.Log("Creating first home world");
                MapBox.instance.generateNewMap();
                SmoothLoader.add(delegate
                {
                    WorldTile TargetTile = MapBox.instance.tilesList.GetRandom();
                    while (TargetTile.Type.liquid)
                    {
                        TargetTile = MapBox.instance.tilesList.GetRandom();
                    }
                    controlledActor = clipboard.PasteUnit(TargetTile, clipboard.selectedUnitToPaste);
                    WorldTile TargetTile2 = MapBox.instance.tilesList.GetRandom();
                    while (TargetTile2.Type.liquid)
                    {
                        TargetTile2 = MapBox.instance.tilesList.GetRandom();
                    }
                    MapBox.instance.addBuilding("randomPortal", TargetTile2, null, false, false, BuildPlacingType.New);
                    SaveManager.setCurrentSlot(50); // home slot
                    MapBox.instance.saveManager.clickSaveSlot();
                    settings.hasCreatedHome = true;
                    saveSettings();
                    isInHomeWorld = true;
                }, "add_portals", false, 0.001f);
            }
            else
            {
                UnityEngine.Debug.Log("Already created home world");
                string slotSavePath = SaveManager.getSlotSavePath(50);
                MapBox.instance.saveManager.loadWorld(slotSavePath, false);
                SmoothLoader.add(delegate
               {
                   WorldTile TargetTile2 = MapBox.instance.tilesList.GetRandom();
                   while (TargetTile2.Type.liquid)
                   {
                       TargetTile2 = MapBox.instance.tilesList.GetRandom();
                   }
                   controlledActor = clipboard.PasteUnit(TargetTile2, clipboard.selectedUnitToPaste);
                   isInHomeWorld = true;
               }, "add_portals", false, 0.001f);
            }
        }

        public void SaveTestW()
        {
            SaveManager.setCurrentSlot(50); // slot for home world
            MapBox.instance.saveManager.clickSaveSlot();
            if (settings.hasCreatedHome == false)
            {
                settings.hasCreatedHome = true;
                saveSettings();
            }

        }

        Color tempColor;


        void ControllerCheck()
        {

        }

        public static void WorldMessage(string messageText, string iconPath = "iconTornado")
        {
            WorldLogMessage message = new WorldLogMessage(messageText, null, null, null);
            message.icon = iconPath;
            message.add();
        }

        public List<CrabArm> customArms = new List<CrabArm>();
        public void updateCrabArms()
        {
            foreach (CrabArm arm in customArms)
            {
                if (arm.giantzilla == null || (arm.giantzilla.actor != null && arm.giantzilla.actor.data.alive == false))
                {
                    arm.gameObject.SetActive(false);

                }
                if (Input.GetMouseButton(0))
                {
                    //UnityEngine.Random.ColorHSV(0f, 1f, 1f, 1f, 0.5f, 1f); // rgb laser
                }
            }
        }

        public void DebugControls()
        {
            updateCrabArms();
            if (Input.GetKeyDown(KeyCode.F1))
            {
                //MapBox.instance.canvas.gameObject.SetActive(true); // show power bar again
                MakeBuildingsOutOfDirectory();
            }
            if (controlledActor != null && controlledActor.city != null && lastTile != null && lastTile.zone != null && lastTile.zone.city != controlledActor.city)
            {
                controlledActor.city.addZone(lastTile.zone);
                //lastTile.zone.setCity(controlledActor.city);
            }
            if (Input.GetKeyDown(KeyCode.F2))
            {
                if (!hasAddedItemsFromAssetManager)
                {
                    AddCraftables();
                }
                OpenCraftableWindow();
                //LoadHomeWorld();
            }
            if (Input.GetKeyDown(KeyCode.F3))
            {
                tempColor = GUI.backgroundColor;
                GUI.backgroundColor = Color.black;
            }
            if (Input.GetKeyDown(KeyCode.F4))
            {
                WorldLogMessage worldLogMessage = new WorldLogMessage("test", null, null, null);
                worldLogMessage.icon = "iconTornado";
                worldLogMessage.location = MapBox.instance.getMouseTilePos().posV3;
                worldLogMessage.special1 = "t1";
                worldLogMessage.special2 = "t2";
                worldLogMessage.special3 = "t3";
                worldLogMessage.add();
                /*
                if (pCity != null)
                {
                    worldLogMessage.special2 = pCity.data.cityName;
                    worldLogMessage.city = pCity;
                }
                worldLogMessage.unit = pUnit;
                */
            }
            if (Input.GetKeyDown(KeyCode.F5))
            {
                WorldMessage("crab", "cake");
                if (controlledActor != null)
                {
                    foreach (Actor actor in MapBox.instance.units)
                    {
                        if (actor.stats.id == "crabzilla")
                        {
                            hasStartedCrabMode = true;
                            ChangeLaserTerraform();
                            Giantzilla crab = actor.GetComponent<Giantzilla>();

                            CrabArm crabArm1 = crab.arm1;
                            CrabArm duplicate1 = UnityEngine.Object.Instantiate(crabArm1);
                            duplicate1.transform.position = controlledActor.transform.position + new Vector3(1f, 0, 0);
                            duplicate1.transform.parent = controlledActor.transform;
                            duplicate1.transform.localScale = new Vector3(0.3f, 0.3f, 0.3f);
                            duplicate1.transform.localPosition = new Vector3(3, 5, 0);
                            duplicate1.laser.color = Color.red;
                            customArms.Add(duplicate1);

                            CrabArm duplicate3 = UnityEngine.Object.Instantiate(crabArm1);
                            duplicate3.transform.position = controlledActor.transform.position + new Vector3(1f, 0, 0);
                            duplicate3.transform.parent = controlledActor.transform;
                            duplicate3.transform.localScale = new Vector3(0.3f, 0.3f, 0.3f);
                            duplicate3.transform.localPosition = new Vector3(7, 0, 0);
                            duplicate3.laser.color = Color.red;
                            customArms.Add(duplicate3);


                            CrabArm crabArm2 = crab.arm2;
                            CrabArm duplicate2 = UnityEngine.Object.Instantiate(crabArm2);
                            duplicate2.transform.position = controlledActor.transform.position + new Vector3(-1f, 0, 0);
                            duplicate2.transform.parent = controlledActor.transform;
                            duplicate2.transform.localScale = new Vector3(0.3f, 0.3f, 0.3f);
                            duplicate2.transform.localPosition = new Vector3(-3, 5, 0);
                            duplicate2.laser.color = Color.red;
                            customArms.Add(duplicate2);

                            CrabArm duplicate4 = UnityEngine.Object.Instantiate(crabArm2);
                            duplicate4.transform.position = controlledActor.transform.position + new Vector3(1f, 0, 0);
                            duplicate4.transform.parent = controlledActor.transform;
                            duplicate4.transform.localScale = new Vector3(0.3f, 0.3f, 0.3f);
                            duplicate4.transform.localPosition = new Vector3(-7, 0, 0);
                            duplicate4.laser.color = Color.red;
                            customArms.Add(duplicate4);


                            crab.arm1.gameObject.SetActive(false);
                            crab.arm2.gameObject.SetActive(false);
                            crab.mouthSprite.GetComponent<SpriteRenderer>().enabled = false;
                            crab.transform.Find("Shadow").gameObject.SetActive(false);
                            crab.transform.Find("Main Body").gameObject.SetActive(false);
                            foreach (GiantLeg leg in crab.list_legs)
                            {
                                leg.gameObject.SetActive(false);
                            }
                            foreach (LegJoint legJoint in crab.list_joints)
                            {
                                legJoint.gameObject.SetActive(false);
                            }
                            //crab.mainBody.enabled = false;
                            //crab.mouthSprite.active = false;
                        }
                    }
                    //CrabArm crabArm = NCMS.Utils.GameObjects.FindEvenInactive("Giantzilla").GetComponent<CrabArm>();

                }
            }

            if (Input.GetKeyDown(KeyCode.F6))
            {
                if (controlledActor != null)
                {
                    controlledInventory.resources["CrabCoin"] += 1;
                    WorldMessage("coin added", "coin");
                    foreach (Building building in controlledActor.currentTile.zone.buildings)
                    {
                        //apBox.instance.stackEffects.
                    }
                }

            }
            if (Input.GetKeyDown(KeyCode.J))
            {
                TriggerShake();
                //Survivor.creaturesToSpawnOverride = 100;
            }
            if (Input.GetKeyDown(KeyCode.Alpha7))
            {
                if (controlledActor != null)
                {
                    controlledActor.addStatusEffect("absorb");
                }
            }
            if (Input.GetKeyDown(KeyCode.Alpha6))
            {
                if (controlledActor != null)
                {
                    controlledActor.addStatusEffect("sleep");
                }
            }
            if (Input.GetKeyDown(KeyCode.Alpha5))
            {
                if (controlledActor != null)
                {
                    controlledActor.addStatusEffect("reflect");
                }
            }
            if (Input.GetKeyDown(KeyCode.Alpha4))
            {
                if (controlledActor != null)
                {
                    controlledActor.addStatusEffect("crystal");
                }
            }

            if (Input.GetKeyDown(KeyCode.Alpha3))
            {
                if (controlledActor != null)
                {
                    DejMod.clericUnits.Add(controlledActor);
                    controlledActor.setHeadSprite(null);
                    if (currentlySelectedFormation != null)
                    {
                        Actor newUnit = MapBox.instance.createNewUnit("chicken", controlledActor.currentTile, null, 0f, null);
                        AddActorToSquad(currentlySelectedFormation, newUnit);
                        DejMod.bardUnits.Add(newUnit);
                        newUnit.setHeadSprite(null);
                        Actor newUnit2 = MapBox.instance.createNewUnit("chicken", controlledActor.currentTile, null, 0f, null);
                        AddActorToSquad(currentlySelectedFormation, newUnit2);
                        DejMod.clericUnits.Add(newUnit2);
                        newUnit2.setHeadSprite(null);
                    }
                    //controlledActor.addStatusEffect("wings");
                }
            }

            if (Input.GetKeyDown(KeyCode.Alpha2))
            {
                if (controlledActor != null)
                {
                    for (int i = 0; i < DejMod.actorTextureLists.Count; i++)
                    {
                        if (DejMod.actorTextureLists[i].Contains(controlledActor))
                        {
                            DejMod.actorTextureLists[i].Remove(controlledActor);
                        }
                    }
                    DejMod.bardUnits.Add(controlledActor);
                    controlledActor.setHeadSprite(null);
                }
            }
            if (Input.GetKeyDown(KeyCode.Alpha1))
            {
                if (controlledActor != null)
                {
                    for (int i = 0; i < DejMod.actorTextureLists.Count; i++)
                    {
                        if (DejMod.actorTextureLists[i].Contains(controlledActor))
                        {
                            DejMod.actorTextureLists[i].Remove(controlledActor);
                        }
                    }
                    DejMod.clericUnits.Add(controlledActor);
                    controlledActor.setHeadSprite(null);
                    //controlledActor.RandomizeTexture();
                }
            }

            if (Input.GetKeyDown(KeyCode.Alpha8))
            {
                survivorController.StartRound();
            }
            if (Input.GetKeyDown(KeyCode.Alpha9))
            {
                survivorController.OpenUpgradeWindow();
            }

            if (Input.GetKeyDown(KeyCode.Alpha0))
            {
                //DejMod.soldierUnits.Add(controlledActor);
                //controlledActor.setHeadSprite(null);
                OpenBankWindow();
            }
        }

        public void TriggerShake()
        {
            initialPosition = transform1.localPosition;
            shakeDuration = 2.0f;
        }

        // Transform of the GameObject you want to shake
        private Transform transform1 => Camera.main.transform;

        // Desired duration of the shake effect
        private float shakeDuration = 0f;

        // A measure of magnitude for the shake. Tweak based on your preference
        private float shakeMagnitude = 0.7f;

        // A measure of how quickly the shake effect should evaporate
        private float dampingSpeed = 1.0f;

        // The initial position of the GameObject
        Vector3 initialPosition;


        public bool hasAddedCursors;
        public static Dictionary<string, Texture2D> cursors = new Dictionary<string, Texture2D>();
        public void AddCursorTextures()
        {
            if (hasAddedCursors == false)
            {
                //Texture2D[] cursors = Reflection.GetField(mousecur.GetType(), __instance, "data") as ActorStatus;
                foreach (Sprite cursorSprite in Resources.LoadAll<Sprite>("cursors/"))
                {
                    UnityEngine.Debug.Log("cursor added: " + cursorSprite.name);
                    cursors.Add(cursorSprite.name, cursorSprite.texture);
                }
                UnityEngine.Debug.Log("end cursor count: " + cursors.Count().ToString());
                hasAddedCursors = true;
            }
        }

        [Obsolete] // stops warning about gameObject.active
        public void Update() // I added a bit of things
        {
            UpdateControls();
            guiConstruction.ControlsUpdate();
            UpdateSquadBehaviour();
            //assets shouldnt be done constantly?
            survivorController.addAssets(); // resources, traits, etc
            if (survivorController.hasStarted == true)
            {
                survivorController.Update();
            }
            //DebugControls();

            AddBuildingAssets();
            AddEffectAssets();
            AddCursorTextures();

            if (survivorController.hasStarted == false && controlledActor != null && Input.GetKeyDown(KeyCode.B))
            {
                GUIConstruction.OpenConstructionWindow();
                // show construction menu/construction window 
                //GUIConstruction.showHideConstruction = !GUIConstruction.showHideConstruction;
            }

            // need a better check later
            if (controlledActor == null && MapBox.instance != null && MapBox.instance.canvas.gameObject.active == false)
            {
                //MapBox.instance.canvas.gameObject.SetActive(true); // show power bar again
            }

            if (shakeDuration > 0)
            {
                transform.localPosition = transform1.localPosition + UnityEngine.Random.insideUnitSphere * shakeMagnitude;

                shakeDuration -= Time.deltaTime * dampingSpeed;
            }
            else
            {
                shakeDuration = 0f;
                //transform.localPosition = initialPosition;
            }
            /*
            if(Input.GetMouseButtonDown(0))
            {
                if(MapBox.instance.getMouseTilePos() != null && MapBox.instance.getMouseTilePos().units.Count > 0)
                {
                    isDraggingUnit = true;
                    draggingActor = MapBox.instance.getMouseTilePos().units[0];
                }
            }
            float z = Input.GetAxis("Mouse Y");
            if (z < 0)
            {
                z = -z;
            }
            if (isDraggingUnit)
            {
                var v3 = Input.mousePosition;
                v3.z = Camera.main.farClipPlane;
                v3 = Camera.main.ScreenToWorldPoint(v3);

                float x = Input.GetAxis("Mouse X");
                if (x < 0) x = -x; // flip x if negative
                Actor actor = draggingActor;
                if (!(actor == null) && actor.data.alive)
                {
                    //Vector2 vector = new Vector2(Input.GetAxis("Mouse X") * 4f, Input.GetAxis("Mouse Y") * 4f);
                    Vector3 posV = v3;//actor.currentPosition; idk why i did this before, using mouse pos now
                    //posV.x += vector.x;
                    //posV.y += vector.y + z;
                    actor.zPosition.y = z; // prevents the addForce from applying at the end, could patch addForce instead
                    actor.currentPosition = new Vector3(posV.x, posV.y - actor.zPosition.y);
                    actor.transform.localPosition = posV;
                }

            }
            if (Input.GetMouseButtonUp(0))
            {
                UnityEngine.Debug.Log("MouseX Vel:" + Input.GetAxis("Mouse X").ToString() + "; " + "MouseY Vel:" + Input.GetAxis("Mouse Y").ToString());
                isDraggingUnit = false;
                draggingActor.addForce(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y"), 0.5f + z);
                draggingActor = null;
            }
            */

            // to fix the damn bug
            if (controlledActor == null)
            {
                isGeneral = false;
                isBoat = false;
            }
            // avoid being called to board ship, still in development
            if (controlledActor != null && isGeneral && !isBoat)
            {
                
            }
            // my stuff different from Cody's ideas and this is for unit standing on ships
            if (controlledActor != null && isGeneral && isBoat)
            {
                lastControlActor.currentPosition = controlledActor.currentPosition;
                lastControlActor.currentTile = controlledActor.currentTile;
                for (int i = 0; i < controlledActor.city.army.countUnits(); i++)
                {
                    controlledActor.city.army.units.getSimpleList()[i].currentPosition = controlledActor.currentPosition;
                    controlledActor.city.army.units.getSimpleList()[i].currentTile = controlledActor.currentTile;
                }
            }
            else if (controlledActor != null && isBoat)
            {
                lastControlActor.currentPosition = controlledActor.currentPosition;
                lastControlActor.currentTile = controlledActor.currentTile;
            }
            // this is for the case when the crew and leader both crash their ship onto an island
            if (isGeneral && isBoat && !lastTile.Type.liquid)
            {
                for (int i = 0; i < controlledActor.city.army.countUnits(); i++)
                {
                    controlledActor.city.army.units.getSimpleList()[i].cancelAllBeh();
                }
                controlledActor = lastControlActor;
                isBoat = false;
            }
            else if (isBoat && !lastTile.Type.liquid) // normal person crash ship on land
            {
                controlledActor = lastControlActor;
                isBoat = false;
            }
        }

        public bool isDraggingUnit;
        public Actor draggingActor;

        public static bool absorbEffect(BaseSimObject pTarget, WorldTile pTile = null)
        {
            List<Actor> targets = validTargets(true, null, 4f).ToList();
            for (int i = 0; i < targets.Count; i++)
            {
                Actor target = targets[i];
                target.getHit(1f, true, AttackType.Other, RPG_Main.controlledActor, false);
                RPG_Main.controlledActor.restoreHealth(1);
            }
            return true;
        }

        public static bool reflectEffect(BaseSimObject pTarget, WorldTile pTile = null)
        {
            BaseSimObject attackedBy = pTarget.a.attackedBy;
            if (attackedBy != null)
            {
                attackedBy.getHit(attackedBy.curStats.damage, false, AttackType.Other, pTarget, false);
            }
            return true;
        }

        public static bool giveSleepEffect(BaseSimObject pTarget, WorldTile pTile = null)
        {
            List<Actor> targets = validTargets(true, null, 5f).ToList();
            for (int i = 0; i < targets.Count; i++)
            {
                Actor target = targets[i];
                target.addStatusEffect("sleep");
            }
            return true;
        }

        public void ChangeLaserTerraform()
        {
            TerraformOptions laser = AssetManager.terraform.get("crab_laser");
            laser.shake_intensity = 0f;
        }

        private void AddEffectAssets()
        {
            if (!hasAddedEffects && MapBox.instance != null)
            {
                if (AssetManager.instance != null && AssetManager.status != null && AssetManager.status.list.Count > 1)
                {
                    StatusEffect absorb = new StatusEffect();
                    absorb.id = "absorb";
                    absorb.texture = "absorb";
                    absorb.animated = true;
                    absorb.animation_speed = 0.05f;
                    absorb.duration = 10f;
                    absorb.action += absorbEffect;
                    absorb.actionInterval = 1f;

                    AssetManager.status.add(absorb);

                    StatusEffect reflect = new StatusEffect();
                    reflect.id = "reflect"; // might work better as a transform effect?
                    reflect.texture = "reflect";
                    reflect.animated = true;
                    reflect.animation_speed = 0.05f;
                    reflect.duration = 2.25f;
                    reflect.actionOnHit += reflectEffect;
                    AssetManager.status.add(reflect);

                    StatusEffect sleep = new StatusEffect();
                    sleep.id = "sleep";
                    sleep.texture = "sleep";
                    sleep.animated = true;
                    sleep.animation_speed = 0.05f;
                    sleep.duration = 5f;
                    AssetManager.status.add(sleep);

                    StatusEffect giveSleep = new StatusEffect();
                    giveSleep.id = "giveSleep";
                    giveSleep.duration = 5f;
                    giveSleep.action = giveSleepEffect;
                    giveSleep.actionInterval = 1f;
                    AssetManager.status.add(giveSleep);

                    StatusEffect simCrystal = new StatusEffect();
                    simCrystal.id = "crystal";
                    simCrystal.texture = "crystal";
                    simCrystal.animated = true;
                    simCrystal.animation_speed = 0.1f;
                    simCrystal.duration = 10f;
                    AssetManager.status.add(simCrystal);

                    StatusEffect wings = new StatusEffect();
                    wings.id = "wings";
                    wings.texture = "wings";
                    wings.animated = true;
                    wings.animation_speed = 0.1f;
                    wings.duration = 60f;
                    AssetManager.status.add(wings);

                    StatusEffect gun = new StatusEffect();
                    gun.id = "gun";
                    gun.texture = "gun";
                    gun.animated = false;
                    //gun.animation_speed = 0.1f;
                    gun.duration = 60f;
                    AssetManager.status.add(gun);

                    StatusEffect gun2 = new StatusEffect();
                    gun2.id = "gun2";
                    gun2.texture = "gun2";
                    gun2.animated = false;
                    //gun.animation_speed = 0.1f;
                    gun2.duration = 60f;
                    AssetManager.status.add(gun2);

                    hasAddedEffects = true;
                }

            }
        }

        public void AddDecorationBuildings()
        {
        }

        public void addResource(BuildingAsset building, string pID, int pAmount, bool pNewList = false)
        {
            if (building.resources_given == null || pNewList)
            {
                building.resources_given = new List<ResourceContainer>();
            }
            building.resources_given.Add(new ResourceContainer
            {
                id = pID,
                amount = pAmount
            });
        }


        public static Dictionary<string, float> buildingScaleOverride = new Dictionary<string, float>();

        public static bool applyScale_Prefix(Building tB)
        {
            if (buildingScaleOverride.ContainsKey(tB.stats.id))
            {
                float scaleAmount = buildingScaleOverride[tB.stats.id];
                tB.currentScale = new Vector3(scaleAmount, scaleAmount);
                tB.transform.localScale = tB.currentScale;
                return false;
            }
            else
            {
                tB.m_transform.localScale = tB.currentScale;
            }
            return true;

        }


        private void AddBuildingAssets()
        {
            if (!hasAddedBuildings && MapBox.instance != null)
            {
                if (AssetManager.instance != null && AssetManager.buildings != null && AssetManager.buildings.list.Count > 1)
                {
                    buildingScaleOverride.Add("bridge1", 0.1f);
                    TopTileType newfloor1 = new TopTileType
                    {
                        drawPixel = true,
                        id = "woodfloor1",
                        color = Toolbox.makeColor("#7EAF46", -1f),
                        heightMin = 108,
                        grass = false,
                        ground = true,
                        growToNearbyTiles = false,
                        grassStrength = 5,
                        can_be_farm = false,
                        canBuildOn = true,
                        canBeSetOnFire = true,
                        burnable = true,
                        strength = 0,
                        fireChance = 0.05f,
                        remove_on_freeze = true,
                        remove_on_heat = true,
                        canGrowBiomeGrass = false,
                    };
                    newfloor1.setDrawLayer(TileZIndexes.grass_low, null);
                    newfloor1.setBiome(null);

                    TopTileType newfloor2 = new TopTileType
                    {
                        drawPixel = true,
                        id = "woodfloor2",
                        color = Toolbox.makeColor("#7EAF46", -1f),
                        heightMin = 108,
                        grass = false,
                        ground = true,
                        growToNearbyTiles = false,
                        grassStrength = 5,
                        can_be_farm = false,
                        canBuildOn = true,
                        canBeSetOnFire = true,
                        burnable = true,
                        strength = 0,
                        fireChance = 0.05f,
                        remove_on_freeze = true,
                        remove_on_heat = true,
                        canGrowBiomeGrass = false,
                    };
                    newfloor2.setDrawLayer(TileZIndexes.grass_low, null);
                    newfloor2.setBiome(null);


                    TopTileType newfloor3 = new TopTileType
                    {
                        drawPixel = true,
                        id = "woodfloor3",
                        color = Toolbox.makeColor("#7EAF46", -1f),
                        heightMin = 108,
                        grass = false,
                        ground = true,
                        growToNearbyTiles = false,
                        grassStrength = 5,
                        can_be_farm = false,
                        canBuildOn = true,
                        canBeSetOnFire = true,
                        burnable = true,
                        strength = 0,
                        fireChance = 0.05f,
                        remove_on_freeze = true,
                        remove_on_heat = true,
                        canGrowBiomeGrass = false,
                    };
                    newfloor3.setDrawLayer(TileZIndexes.grass_low, null);
                    newfloor3.setBiome(null);

                    AssetManager.topTiles.add(newfloor1);
                    AssetManager.topTiles.loadSpritesForTile(newfloor1);
                    AssetManager.topTiles.add(newfloor2);
                    AssetManager.topTiles.loadSpritesForTile(newfloor2);
                    AssetManager.topTiles.add(newfloor3);
                    AssetManager.topTiles.loadSpritesForTile(newfloor3);



                    BuildingAsset t2 = new BuildingAsset();
                    t2.id = "wall1";
                    t2.fundament = new BuildingFundament(0, 0, 0, 0);
                    t2.shadow = false;
                    t2.kingdom = "nature";
                    AssetManager.buildings.add(t2);
                    AssetManager.buildings.loadSprites(t2);

                    BuildingAsset bankbooth = new BuildingAsset();
                    bankbooth.id = "bankbooth"; // for persistent storage, like an op enderchest
                    bankbooth.fundament = new BuildingFundament(0, 0, 0, 0); // resize later
                    bankbooth.shadow = true;
                    bankbooth.kingdom = "nature"; // ?
                    bankbooth.cost = new ConstructionCost(pWood: 10, pStone: 0, pCommonMetals: 0, pGold: 0);
                    // add bonus/extra resources
                    GUIConstruction.extraResourceCosts.Add("bankbooth", new Dictionary<string, int> { { "dirt", 1 }, { "sand", 1 } }); // test
                    AssetManager.buildings.add(bankbooth);
                    AssetManager.buildings.loadSprites(bankbooth);

                    BuildingAsset oreSpawner = new BuildingAsset();
                    oreSpawner.id = "oreSpawner"; // generate ores when interacting
                    oreSpawner.fundament = new BuildingFundament(0, 0, 0, 0); // resize later
                    oreSpawner.shadow = true;
                    oreSpawner.kingdom = "nature"; // ?
                    oreSpawner.cost = new ConstructionCost(pWood: 0, pStone: 10, pCommonMetals: 0, pGold: 0);
                    // add bonus/extra resources
                    //GUIConstruction.extraResourceCosts.Add("orespawner", new Dictionary<string, int> { { "dirt", 1 }, { "sand", 1 } }); // test
                    AssetManager.buildings.add(oreSpawner);
                    AssetManager.buildings.loadSprites(oreSpawner);

                    BuildingAsset treeSpawner = new BuildingAsset();
                    treeSpawner.id = "treeSpawner"; // generate trees when interacting
                    treeSpawner.fundament = new BuildingFundament(0, 0, 0, 0); // resize later
                    treeSpawner.shadow = true;
                    treeSpawner.kingdom = "nature"; // ?
                    treeSpawner.cost = new ConstructionCost(pWood: 10, pStone: 0, pCommonMetals: 0, pGold: 0);
                    AssetManager.buildings.add(treeSpawner);
                    AssetManager.buildings.loadSprites(treeSpawner);


                    BuildingAsset homePortal = new BuildingAsset();
                    homePortal.id = "homePortal";
                    homePortal.fundament = new BuildingFundament(0, 0, 1, 0);
                    homePortal.shadow = true;
                    homePortal.kingdom = "nature";
                    homePortal.cost = new ConstructionCost(pWood: 5, pStone: 10, pCommonMetals: 0, pGold: 0);
                    AssetManager.buildings.add(homePortal);
                    AssetManager.buildings.loadSprites(homePortal);


                    BuildingAsset randomPortal = new BuildingAsset();
                    randomPortal.id = "randomPortal"; // need to prevent from showing in construction
                    randomPortal.fundament = new BuildingFundament(0, 0, 1, 0);
                    randomPortal.shadow = true;
                    randomPortal.kingdom = "nature";
                    AssetManager.buildings.add(randomPortal);
                    AssetManager.buildings.loadSprites(randomPortal);

                    BuildingAsset road = new BuildingAsset();
                    road.id = "road"; // need to prevent from showing in construction // jk used a fake building in the menu
                    road.fundament = new BuildingFundament(0, 0, 0, 0);
                    road.shadow = true;
                    road.kingdom = "nature";
                    AssetManager.buildings.add(road);
                    AssetManager.buildings.loadSprites(road);



                    BuildingAsset woodfloor1 = new BuildingAsset();
                    woodfloor1.id = "woodfloor1"; // need to prevent from showing in construction // jk used a fake building in the menu
                    woodfloor1.fundament = new BuildingFundament(0, 0, 0, 0);
                    woodfloor1.shadow = true;
                    woodfloor1.kingdom = "nature";
                    AssetManager.buildings.add(woodfloor1);
                    AssetManager.buildings.loadSprites(woodfloor1);
                    BuildingAsset woodfloor2 = new BuildingAsset();
                    woodfloor2.id = "woodfloor2"; // need to prevent from showing in construction // jk used a fake building in the menu
                    woodfloor2.fundament = new BuildingFundament(0, 0, 0, 0);
                    woodfloor2.shadow = true;
                    woodfloor2.kingdom = "nature";
                    AssetManager.buildings.add(woodfloor2);
                    AssetManager.buildings.loadSprites(woodfloor2);
                    BuildingAsset woodfloor3 = new BuildingAsset();
                    woodfloor3.id = "woodfloor1"; // need to prevent from showing in construction // jk used a fake building in the menu
                    woodfloor3.fundament = new BuildingFundament(0, 0, 0, 0);
                    woodfloor3.shadow = true;
                    woodfloor3.kingdom = "nature";
                    AssetManager.buildings.add(woodfloor3);
                    AssetManager.buildings.loadSprites(woodfloor3);

                    BuildingAsset field = new BuildingAsset();
                    field.id = "field"; // need to prevent from showing in construction // jk used a fake building in the menu
                    field.fundament = new BuildingFundament(0, 0, 0, 0);
                    field.shadow = true;
                    field.kingdom = "nature";
                    AssetManager.buildings.add(field);
                    AssetManager.buildings.loadSprites(field);

                    //use existing list to prevent overriding intentionally set up buildings from above
                    List<BuildingAsset> buildingsExisting = AssetManager.buildings.list;
                    HashSet<string> buildingIDs = new HashSet<string>();
                    foreach (BuildingAsset buildingE in buildingsExisting)
                    {
                        buildingIDs.Add(buildingE.id);
                    }
                    //add all extra buildings automatically
                    //fast and lazy
                    string actualBuildingDir = Directory.GetCurrentDirectory() + "\\Mods//RPG//GameResources//buildings//";
                    var info = new DirectoryInfo(actualBuildingDir);
                    DirectoryInfo[] buildings = info.GetDirectories();
                    foreach (DirectoryInfo building in buildings)
                    {
                        if (buildingIDs.Contains(building.Name) == false)
                        {
                            BuildingAsset newBuilding = new BuildingAsset();
                            newBuilding.id = building.Name;
                            newBuilding.fundament = new BuildingFundament(0, 0, 0, 0);
                            newBuilding.shadow = true;
                            newBuilding.kingdom = "nature";
                            AssetManager.buildings.add(newBuilding);
                            AssetManager.buildings.loadSprites(newBuilding);
                        }
                    }

                    //AssetManager.buildings.init();
                    //AssetManager.buildings.loadSprites(sign);
                    hasAddedBuildings = true;
                }

            }
        }

        public Actor closestActorToTile(WorldTile targetTile, float radius)
        {
            Actor closestActor = null;
            float smallestDistance = float.MaxValue; // set to max so we just go down forever
            HashSet<Actor> actorsToCheck = validTargets(attackRange: radius);
            foreach (Actor actor in actorsToCheck)
            {
                Actor checkedActor = actor;
                float distanceFromCenter = Toolbox.DistTile(targetTile, checkedActor.currentTile);
                if (distanceFromCenter < smallestDistance)
                {
                    closestActor = checkedActor;
                    smallestDistance = distanceFromCenter;
                }
            }
            return closestActor;
        }

        public bool showActorInteract;
        public Rect actorInteractWindowRect;

        public static bool showHideMainWindow;
        public static Rect mainWindowRect = new Rect(0f, 1f, 1f, 1f);

        public static bool showHideLeadersWindow;
        public static Rect leadersWindowRect = new Rect(0f, 1f, 1f, 1f);

        public static bool showHideSquadsWindow;
        public static Rect squadsWindowRect = new Rect(0f, 1f, 1f, 1f);

        /*
        public static int kingAgeExp = 20;
        public static int leaderAgeExp = 10;
        public static int otherAgeExp = 2;
        public static int intendedExpToLevelup = 100; // default: 100 + (this.data.level - 1) * 20;
        */
        public static string kingExpInput = "20";
        public static string leaderExpInput = "10";
        public static string otherExpInput = "2";
        public static string expToLevel = "100";
        public static string expScale = "20";
        public static string expGainedOnKill = "10";

        public static List<string> listOfSquadsWithLeaders = new List<string>();
        public static Dictionary<string, SquadLeader> leaderDict = new Dictionary<string, SquadLeader>();

        public void mainWindow(int windowID)
        {
            GUILayout.BeginHorizontal();
            GUILayout.Button("KingAgeExp");
            kingExpInput = GUILayout.TextField(kingExpInput);
            int newKingExp;
            if (int.TryParse(kingExpInput, out newKingExp))
            {
                settings.kingAgeExp = newKingExp;
            }
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            GUILayout.Button("LeaderAgeExp");
            leaderExpInput = GUILayout.TextField(leaderExpInput);
            int newLeaderExp;
            if (int.TryParse(leaderExpInput, out newLeaderExp))
            {
                settings.leaderAgeExp = newLeaderExp;
            }
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            GUILayout.Button("OtherAgeExp");
            otherExpInput = GUILayout.TextField(otherExpInput);
            int newOtherExp;
            if (int.TryParse(otherExpInput, out newOtherExp))
            {
                settings.otherAgeExp = newOtherExp;
            }
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            GUILayout.Button("BaseExpToLevel");
            expToLevel = GUILayout.TextField(expToLevel);
            int newExpToLevel;
            if (int.TryParse(expToLevel, out newExpToLevel))
            {
                settings.baseExpToLevelup = newExpToLevel;
            }
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            GUILayout.Button("ExpGainOnKill");
            expGainedOnKill = GUILayout.TextField(expGainedOnKill);
            int newExpGainOnKill;
            if (int.TryParse(expGainedOnKill, out newExpGainOnKill))
            {
                settings.expGainOnKill = newExpGainOnKill;
            }
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            GUILayout.Button("LevelExpScale");
            expScale = GUILayout.TextField(expScale);
            int newExpScale;
            if (int.TryParse(expScale, out newExpScale))
            {

                settings.expToLevelUpScale = newExpScale;
            }
            GUILayout.EndHorizontal();
            if (GUILayout.Button("Reset"))
            {
                expGainedOnKill = "10";
                kingExpInput = "20";
                leaderExpInput = "10";
                otherExpInput = "2";
                expToLevel = "100";
                expScale = "20";
            }
            GUI.DragWindow();
        }

        public static Rect centeredAboveActor(Actor targetActor)
        {
            SpriteRenderer spriteRendererBody = targetActor.spriteRenderer;
            Vector3 pos = new Vector3();
            pos.x = spriteRendererBody.transform.localPosition.x;
            pos.y = spriteRendererBody.transform.localPosition.y;
            pos.z = spriteRendererBody.transform.localPosition.z;
            Vector3 screenPos = Camera.main.WorldToScreenPoint(pos);
            screenPos.y = (Screen.height - screenPos.y);

            return new Rect(new Vector2(screenPos.x - 100, screenPos.y - 150), new Vector2());
        }

        public GUIConstruction guiConstruction = new GUIConstruction();

        public void OnGUI()
        {
            GUILayout.BeginArea(new Rect(Screen.width - 120, 75, 120, 30));
            if (GUILayout.Button("TWreck settings"))
            {
                showHideMainWindow = !showHideMainWindow;
            }
            GUILayout.EndArea();

            if (showHideMainWindow)
            {
                mainWindowRect = GUILayout.Window(79001, mainWindowRect, new GUI.WindowFunction(mainWindow), "Main", new GUILayoutOption[] { GUILayout.MaxWidth(300f), GUILayout.MinWidth(200f) });
            }
            if (leaderDict.Count >= 1)
            {
                leadersWindowRect = GUILayout.Window(79003, leadersWindowRect, new GUI.WindowFunction(SquadLeadersWindow), "Leaders", new GUILayoutOption[] { GUILayout.MaxWidth(300f), GUILayout.MinWidth(200f) });
            }
            if (lastInteractionActor != null) // showActorInteract && 
            {
                actorInteractWindowRect = GUILayout.Window(79002, centeredAboveActor(lastInteractionActor), new GUI.WindowFunction(ActorInteractWindow), "Actor interact", new GUILayoutOption[] { GUILayout.MaxWidth(300f), GUILayout.MinWidth(200f) });
            }
            if (showHideSquadsWindow) // show personal inventory
            {
                squadsWindowRect = GUILayout.Window(79005, squadsWindowRect, new GUI.WindowFunction(SquadsWindow), "Squad", new GUILayoutOption[] { GUILayout.MaxWidth(300f), GUILayout.MinWidth(200f) });
            }

            guiConstruction.constructionWindowUpdate();
        }
        public static bool showInventory = true;
        public Rect actorInventoryWindowRect;

        public SquadFormation currentlySelectedFormation;

        public void SquadLeadersWindow(int windowID)
        {
            if (leaderDict.Count >= 1)
            {
                for (int i = 0; i < leaderDict.Count; i++)
                {
                    SquadFormation formation = leaderDict.Values.ToList()[i].squad;
                    Actor leaderActor = leaderDict.Values.ToList()[i].squadLeaderActor;
                    if (leaderActor != null)
                    {
                        ActorStatus data = leaderActor.data;
                        if (data.alive)
                        {
                            GUILayout.BeginHorizontal();
                            if (GUILayout.Button("Leader: " + leaderActor.getName()))
                            {
                                lastInteractionActor = leaderActor;
                            }
                            if (GUILayout.Button("Squad: " + formation.squadName))
                            {
                                currentlySelectedFormation = formation;

                            }
                            GUILayout.EndHorizontal();
                        }
                        else
                        {
                        }
                    }
                    else
                    {

                    }
                }
            }
            GUI.DragWindow();
        }

        public void SquadsWindow(int windowID)
        {
            SetWindowInUse(windowID);

            if (currentlySelectedFormation != null)
            {
                GUILayout.Button("SquadName: " + currentlySelectedFormation.squadName);
                GUILayout.BeginHorizontal();
                nextSquadName = GUILayout.TextField(nextSquadName);
                if (GUILayout.Button("Set name"))
                {
                    currentlySelectedFormation.squadName = nextSquadName;
                }
                GUILayout.EndHorizontal();
                if (listOfSquadsWithLeaders.Contains(currentlySelectedFormation.squadID))
                {
                    GUILayout.Button("Leader: " + leaderDict[currentlySelectedFormation.squadID].squadLeaderActor.getName());
                }
                else
                {
                    GUILayout.Button("Leader: " + "none");
                }
                if (lastInteractionActor != null && GUILayout.Button("Assign inspected to squad leader"))
                {
                    SquadLeader newLeader = new SquadLeader(lastInteractionActor);
                    newLeader.squad = currentlySelectedFormation;
                    if (listOfSquadsWithLeaders.Contains(currentlySelectedFormation.squadID))
                    {
                        leaderDict[currentlySelectedFormation.squadID] = newLeader;
                    }
                    else
                    {
                        listOfSquadsWithLeaders.Add(currentlySelectedFormation.squadID);
                        leaderDict.Add(currentlySelectedFormation.squadID, newLeader);
                    }



                }
                GUILayout.Button("Unit count: " + currentlySelectedFormation.actorList.Count.ToString());
                if (GUILayout.Button("Formation shape: " + currentlySelectedFormation.formationType))
                {
                    CycleFormation(currentlySelectedFormation);
                }
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("-"))
                {
                    currentlySelectedFormation.radius--;
                    if (currentlySelectedFormation.radius < 0)
                    {
                        currentlySelectedFormation.radius = 0;
                    }
                }
                if (GUILayout.Button("Radius: " + currentlySelectedFormation.radius.ToString()))
                {
                    currentlySelectedFormation.radius = 3;
                }
                if (GUILayout.Button("+"))
                {
                    currentlySelectedFormation.radius++;
                }
                GUILayout.EndHorizontal();
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("-"))
                {
                    currentlySelectedFormation.lineX--;
                    if (currentlySelectedFormation.lineX < 0)
                    {
                        currentlySelectedFormation.lineX = 0;
                    }
                }
                if (GUILayout.Button("LineX: " + currentlySelectedFormation.lineX.ToString()))
                {
                    currentlySelectedFormation.lineX = 5;
                }
                if (GUILayout.Button("+"))
                {
                    currentlySelectedFormation.lineX++;
                }
                GUILayout.EndHorizontal();
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("-"))
                {
                    currentlySelectedFormation.lineY--;
                    if (currentlySelectedFormation.lineY < 0)
                    {
                        currentlySelectedFormation.lineY = 0;
                    }
                }
                if (GUILayout.Button("LineY: " + currentlySelectedFormation.lineY.ToString()))
                {
                    currentlySelectedFormation.lineY = 5;
                }
                if (GUILayout.Button("+"))
                {
                    currentlySelectedFormation.lineY++;
                }
                GUILayout.EndHorizontal();
                Color og = GUI.backgroundColor;
                if (currentlySelectedFormation.followsControlledPos)
                {
                    GUI.backgroundColor = Color.green;
                }
                else
                {
                    GUI.backgroundColor = Color.red;
                }
                if (GUILayout.Button("Toggle formation follows you"))
                {
                    currentlySelectedFormation.followsControlledPos = !currentlySelectedFormation.followsControlledPos;
                }
                if (currentlySelectedFormation.followsOffset)
                {
                    GUI.backgroundColor = Color.green;
                }
                else
                {
                    GUI.backgroundColor = Color.red;
                }
                if (GUILayout.Button("Toggle formation follows offset"))
                {
                    currentlySelectedFormation.followsOffset = !currentlySelectedFormation.followsOffset;
                }
                GUI.backgroundColor = og;
                GUI.backgroundColor = Color.red;
                if (GUILayout.Button("Reset hired list"))
                {
                    foreach (Actor actor in currentlySelectedFormation.actorList)
                    {
                        totalSquadActorList.Remove(actor);
                    }
                    currentlySelectedFormation.actorList.RemoveRange(0, currentlySelectedFormation.actorList.Count);
                }
                GUI.backgroundColor = og;
            }

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("<-"))
            {
                squadDictPos--;
                if (squadDictPos <= 0)
                {
                    squadDictPos = 0;
                }
                if (squadsInUse.ContainsKey(squadDictPos.ToString()))
                    currentlySelectedFormation = squadsInUse[squadDictPos.ToString()];
            }
            if (GUILayout.Button("New squad") && lastTile != null)
            {
                SquadFormation newSquad = new SquadFormation();
                newSquad.movementPos = lastTile.posV3;
                squadsInUse.Add(newSquad.squadID, newSquad);
                currentlySelectedFormation = squadsInUse[newSquad.squadID];
            }
            if (GUILayout.Button("->"))
            {
                if (squadsInUse.ContainsKey((squadDictPos + 1).ToString()))
                {
                    squadDictPos++;
                    currentlySelectedFormation = squadsInUse[squadDictPos.ToString()];
                }
            }
            GUILayout.EndHorizontal();


            // hiring/firing squad stuff
            if (lastInteractionActor != null && lastInteractionActor != controlledActor)
            {
                if (totalSquadActorList.Contains(lastInteractionActor))
                {
                    if (GUILayout.Button("Fire " + lastInteractionActor.getName()))
                    {
                        RemoveActorFromSquad(lastInteractionActor);
                    }
                }
                else
                {
                    if (GUILayout.Button("Hire " + lastInteractionActor.getName()) && currentlySelectedFormation != null)
                    {
                        AddActorToSquad(currentlySelectedFormation, lastInteractionActor);
                    }
                }
            }

            GUI.DragWindow();
        }

        public Dictionary<Actor, PlayerInventory> actorInventories = new Dictionary<Actor, PlayerInventory>(); // to save mod inventories if player swaps actors for a bit

        public void ActorInteractWindow(int windowID)
        {
            SetWindowInUse(windowID);
            ActorStatus currentActorData = lastInteractionActor.data;
            if (controlledActor == null && lastInteractionActor != null)
            {
                if (GUILayout.Button("Take control of " + lastInteractionActor.getName()))
                {
                    controlledActor = lastInteractionActor;
                    
                    if (actorInventories.ContainsKey(controlledActor))// surprised this works with copy/paste/unit dying/recreating
                    {
                        controlledInventory = actorInventories[controlledActor];
                    }
                    else
                    {
                        controlledInventory = new PlayerInventory();
                    }
                    // hide interaction menu at the end
                    lastInteractionActor = null;
                    // and hide the main canvas/power tabs
                    //MapBox.instance.canvas.gameObject.SetActive(false);
                }
            }
            if (controlledActor != null)
            {
                if (controlledActor == lastInteractionActor)
                {
                    if (GUILayout.Button("Stop control"))
                    {
                        if (actorInventories.ContainsKey(controlledActor))
                        {
                            actorInventories[controlledActor] = controlledInventory;
                        }
                        else
                        {
                            actorInventories.Add(controlledActor, controlledInventory);
                        }
                        lastInteractionActor = null;
                        controlledActor = null;
                        controlledInventory = null;
                    }
                }
                if (controlledActor != null)
                {
                    ActorStatus controlledActorData = controlledActor.data;
                    GUILayout.Button(controlledActor.getName());
                }
            }
            if (lastInteractionActor == controlledActor)
            {

            }

            /*
            if (GUILayout.Button("Cycle power (Q)"))
            {
                CyclePower();
            }
            GUILayout.Button("Current power: " + powerInUse);
            */

            // dont allow dragging since position is set automatically
            //GUI.DragWindow();
        }

        public string nextSquadName = "";
        public bool assigningLeader;

        public static int squadDictPos = 0;

        public static void ClearDicts()
        {
            controlledActor = null;
            lastTile = null;
            leaderDict.Clear();
            listOfSquadsWithLeaders.Clear();
            squadsInUse.Clear();
            totalSquadActorList.Clear();
            squadDictPos = 0;
        }

        public static void loadData_Prefix(SavedMap pData)
        {
            ClearDicts();
        }

        public static void GenerateMap_Prefix(string pType = "islands")
        {
            ClearDicts();
        }

        public Survivor survivorController = new Survivor();


        internal void makeAbandoned_Prefix(Building __instance)
        {
            //UnityEngine.Debug.Log("building.makeAbandoned:" + __instance.stats.id);
            __instance.data.cityID = "";
            if (__instance.zones.Count != 0)
            {
                for (int i = 0; i < __instance.zones.Count; i++)
                {
                    TileZone tileZone = __instance.zones[i];
                    tileZone.buildings.Remove(__instance);
                    tileZone.addBuilding(__instance);
                }
            }
            __instance.setTilesDirty();
        }

        public static bool hasStartedCrabMode;
        public static bool damageWorld_Prefix(CrabArm __instance)
        {
            if (hasStartedCrabMode)
            {
                WorldTile tile = MapBox.instance.GetTile((int)__instance.laserPoint.transform.position.x, (int)__instance.laserPoint.transform.position.y);
                if (tile != null)
                {
                    MapAction.damageWorld(tile, 1, AssetManager.terraform.get("crab_laser"));
                }
                return false;
            }
            return true;
        }

        public static bool followCamera_Prefix()
        {
            if (hasStartedCrabMode) return false;
            return true;
        }

        public static void newKillAction_Postfix(Actor pDeadUnit, Actor __instance)
        {
            if (controlledActor != null && controlledActor == __instance)
            {
                //custom drops on kills
                string deadUnitID = pDeadUnit.stats.id;
                if (deadUnitID == "chicken" || deadUnitID == "turtle" || deadUnitID == "rooster")
                {
                    WorldMessage("You found an egg", "egg");
                    controlledInventory.resources["eggs"] += 1;
                }
            }
        }

        public void HarmonyPatchSetup()
        {
            Harmony harmony;
            MethodInfo original;
            MethodInfo patch;

            DejMod.init();

            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(Actor), "newKillAction");
            patch = AccessTools.Method(typeof(RPG_Main), "newKillAction_Postfix");
            harmony.Patch(original, null, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);

            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(CrabArm), "damageWorld");
            patch = AccessTools.Method(typeof(RPG_Main), "damageWorld_Prefix");
            harmony.Patch(original, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);

            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(Giantzilla), "followCamera");
            patch = AccessTools.Method(typeof(RPG_Main), "followCamera_Prefix");
            harmony.Patch(original, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);


            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(ActorBase), "canAttackTarget");
            patch = AccessTools.Method(typeof(RPG_Main), "canAttackTarget_Postfix");
            harmony.Patch(original, null, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);

            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(ActorBase), "stopMovement");
            patch = AccessTools.Method(typeof(RPG_Main), "stopMovement_Prefix");
            harmony.Patch(original, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);

            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(Actor), "getExpToLevelup");
            patch = AccessTools.Method(typeof(RPG_Main), "getExpToLevelup_Postfix");
            harmony.Patch(original, null, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);

            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(Actor), "updateAge");
            patch = AccessTools.Method(typeof(RPG_Main), "updateAge_Prefix");
            harmony.Patch(original, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);

            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(Actor), "increaseKillCount");
            patch = AccessTools.Method(typeof(RPG_Main), "increaseKillCount_Prefix");
            //harmony.Patch(original, new HarmonyMethod(patch)); //disabled in 14.0, method changed
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);

            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(Actor), "addExperience");
            patch = AccessTools.Method(typeof(RPG_Main), "addExperience_Prefix");
            harmony.Patch(original, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);


            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(MoveCamera), "updateZoom");
            patch = AccessTools.Method(typeof(RPG_Main), "updateZoom_Prefix");
            harmony.Patch(original, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);

            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(SaveManager), "loadData");
            patch = AccessTools.Method(typeof(RPG_Main), "loadData_Prefix");
            harmony.Patch(original, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);

            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(MapBox), "GenerateMap");
            patch = AccessTools.Method(typeof(RPG_Main), "GenerateMap_Prefix");
            harmony.Patch(original, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);

            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(MapBox), "canInspectUnitWithCurrentPower");
            patch = AccessTools.Method(typeof(RPG_Main), "canInspectUnitWithCurrentPower_Prefix");
            harmony.Patch(original, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);

            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(MoveCamera), "updateMouseCameraDrag");
            patch = AccessTools.Method(typeof(RPG_Main), "updateMouseCameraDrag_Prefix");
            harmony.Patch(original, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);

            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(WorldTile), "canBuildOn");
            patch = AccessTools.Method(typeof(GUIConstruction), "canBuildOn_Postfix");
            harmony.Patch(original, null, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);

            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(Building), "startDestroyBuilding");
            patch = AccessTools.Method(typeof(GUIConstruction), "startDestroyBuilding_Prefix");
            harmony.Patch(original, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);

            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(Actor), "tryToAttack");
            patch = AccessTools.Method(typeof(Survivor), "tryToAttack_Prefix");
            //harmony.Patch(original, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);

            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(Actor), "startShake");
            patch = AccessTools.Method(typeof(Survivor), "startShake_Prefix");
            harmony.Patch(original, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);

            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(SpriteGroupSystemStatusEffect), "showEffectsFor");
            patch = AccessTools.Method(typeof(Survivor), "showEffectsFor_Prefix");
            //gun shooting stuff was done here, broke but idk when, gun angle is off and sprite goes invis
            //harmony.Patch(original, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);

            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(Tooltip), "showResource");
            patch = AccessTools.Method(typeof(RPG_Main), "showResource_Prefix");
            harmony.Patch(original, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);

            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(ScrollWindow), "activeToFalse");
            patch = AccessTools.Method(typeof(RPG_Main), "activeToFalse_Postfix");
            //harmony.Patch(original, null, new HarmonyMethod(patch));
            //UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);


            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(ScrollWindow), "moveAllToLeftAndRemove");
            patch = AccessTools.Method(typeof(RPG_Main), "moveAllToLeftAndRemove_Prefix");
            harmony.Patch(original, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);

            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(ScrollWindow), "checkGradient");
            patch = AccessTools.Method(typeof(RPG_Main), "checkGradient_Postfix");
            harmony.Patch(original, null, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);

            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(MouseCursor), "renderCursor");
            patch = AccessTools.Method(typeof(RPG_Main), "renderCursor_Prefix");
            harmony.Patch(original, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);

            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(Actor), "updateBehaviour");
            patch = AccessTools.Method(typeof(RPG_Main), "updateBehaviour_Prefix");
            harmony.Patch(original, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);

            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(UnitSelectionEffect), "update");
            patch = AccessTools.Method(typeof(RPG_Main), "updateSelectionEffect_Prefix");
            harmony.Patch(original, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);

            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(BuildingTweenExtension), "applyScale");
            patch = AccessTools.Method(typeof(RPG_Main), "applyScale_Prefix");
            harmony.Patch(original, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);


            // auto retaliate feature, disabled because of enum error i cant find
            /*
            harmony = new Harmony(pluginName);
            original = AccessTools.Method(typeof(Actor), "getHit");
            patch = AccessTools.Method(typeof(TWrecks_Main), "getHit_Postfix");
            harmony.Patch(original, null, new HarmonyMethod(patch));
            UnityEngine.Debug.Log(pluginName + ": Harmony patch finished: " + patch.Name);
            */
        }

        public static bool updateSelectionEffect_Prefix(float pElapsed, UnitSelectionEffect __instance)
        {
            if (controlledActor != null)
            {
                UnitSelectionEffect.last_actor = null;
                __instance.gameObject.SetActive(false);
                return false;
            }
            return true;
        }

        public static bool updateBehaviour_Prefix(float pElapsed, Actor __instance)
        {
            if (controlledActor != null && controlledActor == __instance)
            {
                if (__instance.behaviourActorTargetCheck())
                {

                }
                if (__instance.checkEnemyTargets())
                {
                    //__instance.stopMovement();
                }
                return false;
            }
            return true;
        }

        public static string cursorOverride = "";
        public static bool renderCursor_Prefix(MouseCursor __instance)
        {
            if (controlledActor != null)
            {
                if (cursorOverride != string.Empty)
                {
                    UnityEngine.Cursor.SetCursor(cursors[cursorOverride], Vector2.zero, CursorMode.ForceSoftware);
                    __instance._lastTextureID = cursorOverride;
                    return false;
                }
            }
            return true;
        }

        public static void checkGradient_Postfix(ScrollWindow __instance)
        {
            if (bankOpen && __instance.screen_id == "survivor_inventory")
            {
                __instance.transform.position = new Vector3((Screen.width / 4), __instance.transform.position.y, __instance.transform.position.z);
                var bankWindow = NCMS.Utils.Windows.GetWindow("survivor_bank");
                bankWindow.transform.position = new Vector3((Screen.width - Screen.width / 4), bankWindow.transform.position.y, bankWindow.transform.position.z);
            }
        }

        public static bool updateZoom_Prefix()
        {
            if (controlledActor != null)
            {
                if (Input.GetKey(KeyCode.Q) || Input.GetKey(KeyCode.E))
                {
                    return false;
                }
            }
            return true;
        }

        public static bool tryingToOpenBoth;

        public static bool moveAllToLeftAndRemove_Prefix(bool pWithAnimation = true)
        {
            if (bankOpen && !invOpen && tryingToOpenBoth)
            {
                tryingToOpenBoth = false;
                return false;
            }
            //bankOpen = false;
            //invOpen = false;
            return true;
        }

        // prevent inspection when clicking units when controlling
        public static bool canInspectUnitWithCurrentPower_Prefix()
        {
            if (controlledActor != null)
            {
                return false;
            }
            return true;
        }

        public static Dictionary<Building, Dictionary<string, int>> buildingsAndResourcesLeft = new Dictionary<Building, Dictionary<string, int>>();

        public void UpdateControls()
        {
            if (MapBox.instance != null)
            {
                if (guiConstruction != null)
                {
                    guiConstruction.constructionControl();
                }
                if (Input.GetKeyDown(KeyCode.Escape))
                {
                    if (bankOpen || invOpen)
                    {
                        ScrollWindow.moveAllToLeftAndRemove(false);
                        tryingToOpenBoth = false;
                    }
                }
                Camera camera = MapBox.instance.camera;
                if (camera != null)
                {
                    if (controlledActor != null)
                    {
                        camera.orthographicSize = 15f;
                        if ((Input.GetKeyDown(KeyCode.Tab) || Input.GetKeyDown(KeyCode.I)))
                        {
                            if (invOpen || bankOpen)
                            {
                                ScrollWindow.moveAllToLeftAndRemove(false);
                            }
                            else
                            {
                                if (controlledInventory != null)
                                {
                                    OpenInventoryWindow();
                                }
                            }

                        }
                        if (!bankOpen && Input.GetMouseButtonDown(1))
                        {
                            WorldTile tile = MapBox.instance.getMouseTilePos();
                            if (tile != null)
                            {
                                if (lastTile != null && Toolbox.DistTile(tile, lastTile) > 2.5f)
                                {
                                    // do nothing for boat, out of range
                                }
                                else
                                {
                                    Actor target = ClosestActorToTile(MouseTile, 3f);
                                    if (target != null)
                                    {
                                        if (target.stats.egg)
                                        {
                                            controlledInventory.resources["eggs"] += 1;
                                            target.killHimself(true, AttackType.Other, false, false);
                                        }
                                        if (target.stats.id.Contains("cow"))
                                        {
                                            if (cowCoolDown == 0 || cowCoolDown < Time.realtimeSinceStartup - 3)
                                            {
                                                cowCoolDown = Time.realtimeSinceStartup;
                                                controlledInventory.resources["milk"] += 1;
                                            }
                                        }
                                    }

                                    if (tile.building != null)
                                    {
                                        // custom building interactions..
                                        string buildingID = tile.building.stats.id;
                                        if (buildingID == "bankbooth")
                                        {
                                            OpenBankWindow();
                                        }
                                        else if (buildingID == "oreSpawner")
                                        {
                                            UnityEngine.Debug.Log("do ore spawn stuff");
                                        }
                                        else if (buildingID == "treeSpawner")
                                        {
                                            UnityEngine.Debug.Log("do tree spawn stuff");
                                        }
                                    }
                                    if (tile.Type.liquid == true && isBoat == false) // transform from land into a boat
                                    {
                                        isGeneral = controlledActor.isGroupLeader;
                                        lastControlActor = controlledActor;
                                        Actor boat = new Actor();
                                        if (controlledActor.isGroupLeader || controlledActor.isProfession(UnitProfession.King))
                                            boat = MapBox.instance.createNewUnit("boat_transport", tile, null, 0f, null);
                                        else if (controlledActor.isProfession(UnitProfession.Warrior))
                                            boat = MapBox.instance.createNewUnit("boat_trading",tile,null, 0f, null);
                                        else
                                            boat = MapBox.instance.createNewUnit("boat_fishing",tile, null,0f,null);
                                        boat.CallMethod("setKingdom",controlledActor.kingdom);
                                        boat.CallMethod("setCity", controlledActor.city);

                                        controlledActor = boat;
                                        isBoat = true;
                                    }
                                    // transform from boat into land
                                    if (tile.Type.liquid == false && isBoat == true)
                                    {
                                        if (lastControlActor.isGroupLeader)
                                        {
                                            for (int i = 0; i < controlledActor.city.army.units.getSimpleList().Count; i++)
                                            {
                                                controlledActor.city.army.units.getSimpleList()[i].cancelAllBeh();
                                                controlledActor.city.army.units.getSimpleList()[i].currentPosition = controlledActor.currentPosition;
                                                controlledActor.city.army.units.getSimpleList()[i].currentTile = controlledActor.currentTile;
                                            }
                                        }
                                        controlledActor.killHimself(pDestroy: true, pCountDeath: false);
                                        controlledActor = lastControlActor;
                                        isBoat = false;
                                    }
                                }
                            }
                        }


                        if (Input.GetKey(KeyCode.KeypadMinus) || Input.GetKey(KeyCode.KeypadPlus)) // increase or decrease the zoom whhile controlling
                        {
                            camera.GetComponent<MoveCamera>().cameraZoomSpeed = 5f;
                        }
                        else
                        {
                            camera.GetComponent<MoveCamera>().cameraZoomSpeed = 0f;
                            camera.GetComponent<MoveCamera>().cameraMoveSpeed = 0f;
                        }
                    }
                    else
                    {
                        camera.GetComponent<MoveCamera>().cameraMoveSpeed = 0.01f;
                        camera.GetComponent<MoveCamera>().cameraZoomSpeed = 5f;
                    }
                }

                if (MouseTile != null && Input.GetKeyDown(KeyCode.F)) // hover the mouse over a character and press F to pop up the window of interaction
                    lastInteractionActor = ClosestActorToTile(MouseTile, 3f, true);
                if (controlledActor != null)
                {
                    followActor(controlledActor, 10f); // camera
                    movementStuff(); // movement controls
                    // cursor stuff
                    // label and goto? i can do better lol
                    WorldTile currentTile = MapBox.instance.getMouseTilePos();
                    if (currentTile != null)
                    {
                        cursorOverride = "";
                        if (Toolbox.DistTile(currentTile, lastTile) > 2.5f) goto afterTileInteractions;
                        if (currentTile.building != null)
                        {
                            if (currentTile.building.data.underConstruction)
                            {
                                cursorOverride = "cursorHammer";
                                goto cursorFound;
                            }
                            if (currentTile.building.stats.isRuin == true)
                            {
                                cursorOverride = "cursorSword";
                                goto cursorFound;
                            }
                            BuildingType buildingType = currentTile.building.stats.buildingType;
                            if (buildingType == BuildingType.Tree)
                            {
                                cursorOverride = "cursorAxe";
                                goto cursorFound;
                            }
                            if (buildingType == BuildingType.Mineral)
                            {
                                cursorOverride = "cursorPickaxe";
                                goto cursorFound;
                            }
                            if (buildingType == BuildingType.Fruits || buildingType == BuildingType.Wheat || buildingType == BuildingType.Plant)
                            {
                                cursorOverride = "cursorSickle";
                                goto cursorFound;
                            }
                            if (currentTile.building.stats.id == "bankbooth")
                            {
                                cursorOverride = "cursorBag";
                                goto cursorFound;
                            }
                            if (currentTile.building.stats.id == "oreSpawner")
                            {
                                cursorOverride = "cursorQuestion";
                                goto cursorFound;
                            }
                            if (currentTile.building.stats.id == "treeSpawner")
                            {
                                cursorOverride = "cursorQuestion";
                                goto cursorFound;
                            }
                            if (Input.GetKey(KeyCode.LeftControl)) // sword comes after construction/collection, need to fix interaction before changing this
                            {
                                cursorOverride = "cursorSword";
                                goto cursorFound;
                            }
                        }
                        else
                        {
                            // Code to dig things
                            if (Input.GetKey(KeyCode.LeftControl) && GUIConstruction.placingToggleEnabled == false)
                            {
                                if (currentTile.Type.canGrowBiomeGrass || currentTile.Type.sand)
                                {
                                    cursorOverride = "cursorShovel";
                                }
                                if (currentTile.Type.id == "mountains" || currentTile.Type.id == "hills")
                                {
                                    cursorOverride = "cursorPickaxe";
                                }
                                if (Input.GetMouseButtonDown(0))
                                {
                                    string tileType = currentTile.Type.id;
                                    UnityEngine.Debug.Log("tileType decreased: " + tileType);
                                    if (tileType == "mountains" || tileType == "hills")
                                    {
                                        controlledInventory.resources["stone"] += 1;
                                    }
                                    if (tileType.Contains("soil"))
                                    {
                                        controlledInventory.resources["dirt"] += 1;
                                    }
                                    if (tileType.Contains("sand"))
                                    {
                                        controlledInventory.resources["sand"] += 1;
                                    }
                                    MapAction.decreaseTile(currentTile, AssetManager.terraform.get("destroy"));
                                }
                            }
                        }
                    }
                cursorFound:
                    // click interaction (harvest resources, build structures)
                    WorldTile clickedTile = null;
                    if (Input.GetMouseButtonDown(0) && MapBox.instance.getMouseTilePos() != null && GUIConstruction.placingToggleEnabled == false)
                    {
                        clickedTile = MapBox.instance.getMouseTilePos();
                        if (Toolbox.DistTile(clickedTile, lastTile) > 2.5f) goto afterTileInteractions;
                        // building interactions
                        Building clickedBuilding = clickedTile.building;
                        if (clickedBuilding != null)
                        {
                            // Check building for resources
                            bool haveResources = clickedTile.building.haveResources;
                            int totalTargetResource = 0;
                            BuildingAsset stats = clickedTile.building.stats;
                            BuildingData data = clickedTile.building.data;
                            //CityData citydata = controlledActor.city.data;
                            if (haveResources && stats.isRuin == false)
                            {
                                if (stats.resources_given.Count > 0)
                                {
                                    if (buildingsAndResourcesLeft.ContainsKey(clickedBuilding))
                                    {
                                        if (buildingsAndResourcesLeft[clickedBuilding].Count <= 0)
                                        {
                                            buildingsAndResourcesLeft.Remove(clickedBuilding);
                                            return;
                                        }
                                    }
                                    else
                                    {
                                        Dictionary<string, int> dictOfResources = new Dictionary<string, int>();
                                        foreach (ResourceContainer resource in stats.resources_given)
                                        {
                                            dictOfResources.Add(resource.id, resource.amount);
                                        }
                                        buildingsAndResourcesLeft.Add(clickedBuilding, dictOfResources);
                                    }
                                }

                                //totalResources = stats.resources_given;
                                //UnityEngine.Debug.Log("original amount:" + totalResources);
                                if (buildingsAndResourcesLeft.ContainsKey(clickedBuilding))
                                {
                                    // pick first resource in list
                                    totalTargetResource = buildingsAndResourcesLeft[clickedBuilding].First().Value;
                                }
                                if (totalTargetResource > 0)
                                {
                                    string id = buildingsAndResourcesLeft[clickedBuilding].First().Key;
                                    // extract 1 by 1? might need dict of buildings and resources remaining - done
                                    if (id == "wheat" || id == "4wheat")
                                    {
                                        controlledInventory.resources["wheat"] += 1;
                                    }
                                    else
                                    {
                                        controlledInventory.resources[id] += 1;
                                    }
                                    //controlledActor.timer_action = 1f; // delay after interact?
                                    totalTargetResource--;
                                    if (totalTargetResource == 0)
                                    {
                                        buildingsAndResourcesLeft[clickedBuilding].Remove(id);
                                        if (buildingsAndResourcesLeft[clickedBuilding].Keys.Count <= 0)
                                        {
                                            // no resources remaining in building, remove from dict
                                            buildingsAndResourcesLeft.Remove(clickedBuilding);
                                        }
                                    }
                                    else
                                    {
                                        buildingsAndResourcesLeft[clickedBuilding][id] = totalTargetResource;
                                    }
                                    // pretend actor is attacking
                                    controlledActor.punchTargetAnimation(clickedBuilding.currentPosition, clickedBuilding.currentTile, true, controlledActor.s_attackType == WeaponType.Range, 40f);
                                    Sfx.play("punch", true, controlledActor.currentPosition.x, controlledActor.currentPosition.y);
                                }
                            }

                            // add progress to unfinished building
                            if (data.underConstruction)
                            {
                                clickedBuilding.updateBuild(3);
                                //controlledActor.timer_action = 1f;
                                Sfx.play("hammer1", false, clickedBuilding.transform.localPosition.x, clickedTile.building.transform.localPosition.y);
                            }
                            // clear already-ruined buildings properly
                            if (stats.isRuin)
                            {
                                clickedBuilding.startDestroyBuilding(true);
                                controlledActor.punchTargetAnimation(clickedBuilding.currentPosition, clickedBuilding.currentTile, true, controlledActor.s_attackType == WeaponType.Range, 40f);
                                Sfx.play("punch", true, controlledActor.currentPosition.x, controlledActor.currentPosition.y);
                            }
                            // actually attack building if resources are empty/nonexistant || control held
                            if (totalTargetResource <= 0 || Input.GetKey(KeyCode.LeftControl))
                            {
                                if (clickedBuilding.stats.buildingType == BuildingType.Tree)
                                {
                                    clickedBuilding.chopTree();
                                }
                                else
                                {
                                    if (controlledActor.tryToAttack(clickedBuilding))
                                    {
                                        // extra damage if attack successful, if its not destroyed yet
                                        if (clickedBuilding.stats.isRuin == false && clickedTile.building != null)
                                        {
                                            clickedTile.building.getHit(50f, false, AttackType.Other, controlledActor, false);
                                        }
                                    }
                                }
                            }
                        }
                        // Non-building interactions (click)
                        else
                        {

                        }

                    }

                // combat interaction (melee only for now, need to determine what weapon is in-hand)
                /*
                if (Input.GetKeyDown(KeyCode.Q))
                {
                    Actor target = ClosestActorToTile(lastTile, controlledActor, 3f);
                    if (target != null)
                    {
                        AttackActor(controlledActor, target, 15f);
                    }
                }
                */
                afterTileInteractions:
                // Input.GetKey(KeyCode.E)
                    if (Input.GetMouseButtonDown(1)) // I added it for right click attack and bow shooting easier
                    {
                        Actor target = ClosestActorToTile(MouseTile, 3f);
                        // ability to declare war
                        if (target != null && target != controlledActor && target.race.civilization)
                        {
                            if (target.kingdom != controlledActor.kingdom && !target.kingdom.isEnemy(controlledActor.kingdom))
                                MapBox.instance.kingdoms.diplomacyManager.startWar(controlledActor.kingdom, target.kingdom);
                        }
                        // added a bit to avoid friendly attack
                        if (target != null && target != controlledActor && target.kingdom != controlledActor.kingdom)
                        {
                            try
                            {
                                bool canAttack = controlledActor.tryToAttack(target);
                                if (canAttack)
                                {
                                    //UnityEngine.Debug.Log("Attack success");
                                }
                                else
                                {
                                    //UnityEngine.Debug.Log("Attack fail");
                                }
                            }
                            catch (Exception e)
                            {
                                UnityEngine.Debug.Log("exception caught: " + e.Message);
                            }

                        }
                    }
                    // ability to make peace
                    if (Input.GetKeyDown(KeyCode.R))
                    {
                        if (controlledActor.currentTile.zone.city.kingdom.isEnemy(controlledActor.kingdom))
                        {
                            MapBox.instance.kingdoms.diplomacyManager.startPeace(controlledActor.kingdom, controlledActor.currentTile.zone.city.kingdom);
                        }
                    }
                    // ability to create settlement or encampment
                    if (Input.GetKeyDown(KeyCode.Q))
                    {
                        if (controlledActor.kingdom != null)
                        {
                            if (controlledActor.currentTile.zone.city == null)
                            {
                                var zone = controlledActor.currentTile.zone;
                                City newCity = MapBox.instance.buildNewCity(zone,null, controlledActor.race, false, controlledActor.kingdom);
                                newCity.newCityEvent();
                                City oldcity = controlledActor.city;
                                controlledActor.city.removeCitizen(controlledActor);
                                newCity.addNewUnit(controlledActor);
                                if (controlledActor.isGroupLeader)
                                {
                                    foreach (Actor soldiers in controlledActor.unitGroup.units.getSimpleList())
                                    {
                                        oldcity.removeCitizen(soldiers);
                                        newCity.addNewUnit(soldiers);
                                    }
                                }
                                WorldLog.logNewCity(newCity);
                            }
                        }
                    }
                    // ability to break camp/ or settlement
                    if (Input.GetKeyDown(KeyCode.T))
                    {
                        if (controlledActor.city != null)
                        {
                            controlledActor.city.destroyCity();
                        }
                    }
                    // ability to join settlement/ camp
                    if (Input.GetKeyDown(KeyCode.G))
                    {
                        if (controlledActor.kingdom != null)
                        {
                            if (controlledActor.currentTile.zone.city != null)
                            {
                                if (controlledActor.currentTile.zone.city.kingdom == controlledActor.kingdom && controlledActor.city != null
                                    && controlledActor.currentTile.zone.city != controlledActor.city)
                                {
                                    City currentCity = controlledActor.currentTile.zone.city;
                                    City oldcity = controlledActor.city;
                                    controlledActor.city.removeCitizen(controlledActor);
                                    currentCity.addNewUnit(controlledActor);
                                    if (controlledActor.isGroupLeader)
                                    {
                                        foreach (Actor soldiers in controlledActor.unitGroup.units.getSimpleList())
                                        {
                                            oldcity.removeCitizen(soldiers);
                                            currentCity.addNewUnit(soldiers);
                                        }
                                    }
                                }
                                else if (controlledActor.city == null)
                                {
                                    City currentCity = controlledActor.currentTile.zone.city;
                                    currentCity.addNewUnit(controlledActor);
                                    if (controlledActor.isGroupLeader)
                                    {
                                        foreach (Actor soldiers in controlledActor.unitGroup.units.getSimpleList())
                                        {
                                            currentCity.addNewUnit(soldiers);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    // ability to start revolution
                    if (Input.GetKeyDown(KeyCode.E))
                    {
                        if (!controlledActor.city.isCapitalCity())
                        {
                            Kingdom target = controlledActor.kingdom;
                            controlledActor.city.makeOwnKingdom();
                            MapBox.instance.kingdoms.diplomacyManager.startWar(controlledActor.city.kingdom, target);
                        }
                    }
                }
                if (Input.GetKeyDown(KeyCode.K))
                {
                    showHideSquadsWindow = !showHideSquadsWindow;
                    //controlledActor.addStatusEffect("giveSleep");
                }
                if (Input.GetKey(KeyCode.LeftControl) && Input.GetKeyDown(KeyCode.H))
                {
                    if (controlledActor != null && currentlySelectedFormation != null)
                    {
                        AddActorToSquad(currentlySelectedFormation, (ClosestActorToTile(MouseTile, 3f)));
                        //rpgWindow.OpenControlledWindow();
                    }
                    //TWrecks_RPG
                    //hiredActorList.Add(ClosestActorToTile(MouseTile, controlledActor, 30f));
                }
                if (Input.GetKeyDown(KeyCode.X))
                {
                    if (currentlySelectedFormation != null && MapBox.instance.getMouseTilePos() != null)
                    {
                        if (listOfSquadsWithLeaders.Contains(currentlySelectedFormation.squadID))
                        {
                            currentlySelectedFormation.movementPos = MapBox.instance.getMouseTilePos().posV3;
                            currentlySelectedFormation.offsetPos = currentlySelectedFormation.movementPos - leaderDict[currentlySelectedFormation.squadID].squadLeaderActor.currentTile.posV3;
                        }
                        else
                        {
                            currentlySelectedFormation.movementPos = MapBox.instance.getMouseTilePos().posV3;
                            currentlySelectedFormation.offsetPos = currentlySelectedFormation.movementPos - lastTile.posV3;
                        }
                        //UnityEngine.Debug.Log("offset saved: " + currentlySelectedFormation.offsetPos.ToString());
                    }
                }
                if (Input.GetKey(KeyCode.LeftControl) && Input.GetKeyDown(KeyCode.M))
                {
                    for (int i = 0; i < 5; i++)
                    {
                        SquadFormation newSquad = new SquadFormation();
                        newSquad.movementPos = MapBox.instance.getMouseTilePos().posV3;
                        for (int j = 0; j < 10; j++)
                        {
                            Actor newActor = MapBox.instance.createNewUnit("unit_human", MapBox.instance.getMouseTilePos(), null, 10f, null);
                            AddActorToSquad(newSquad, newActor);
                        }
                        Actor newActorLeader = MapBox.instance.createNewUnit("unit_human", MapBox.instance.getMouseTilePos(), null, 10f, null);
                        SquadLeader leader = new SquadLeader(newActorLeader);
                        leader.squad = newSquad;
                        listOfSquadsWithLeaders.Add(newSquad.squadID);
                        squadsInUse.Add(newSquad.squadID, newSquad);
                        leaderDict.Add(newSquad.squadID, leader);
                    }
                }
            }
        }

        public static void canAttackTarget_Postfix(BaseSimObject pTarget, ActorBase __instance, ref bool __result)
        {
            if (controlledActor == __instance && pTarget != controlledActor && Survivor.timeSinceStart != 0)
            {
                __result = true;
            }
        }

        public static HashSet<Actor> validTargets(bool isForAttack = false, WorldTile tileOverride = null, float attackRange = 20f)
        {
            HashSet<Actor> returnList = new HashSet<Actor>();
            foreach (Actor actor in MapBox.instance.units)
            {
                bool valid = true; // start as valid
                if (RPG_Main.controlledActor != null)
                {
                    if (isForAttack == true)
                    { // max range for all abilities
                        WorldTile targ = RPG_Main.controlledActor.currentTile;
                        if (tileOverride != null)
                        {
                            targ = tileOverride;
                        }
                        if (Toolbox.DistTile(actor.currentTile, targ) > attackRange)
                        {
                            valid = false; // become invalid if out of range of attacks
                        }
                    }
                    if (actor == RPG_Main.controlledActor)
                    {
                        valid = false; // become invalid if controlled
                    }
                }
                // using hashset because this will run for every actor, every time i check targets.. could lag a lot, this should help
                // list.contains is o(n), hashset.contains is o(1), dict.containskey is just as fast i think
                if (RPG_Main.totalSquadActorList.Count > 0 && RPG_Main.totalSquadActorList.Contains(actor))
                {
                    //UnityEngine.Debug.Log("detected squad actor, removing from targets"); // to confirm hashset works fine
                    valid = false; // become invalid if in any squads
                }

                if (valid)
                {
                    returnList.Add(actor);
                }
            }

            return returnList;
        }


        public static int formationRadius = 3;
        public void UpdateSquadBehaviour()
        {
            // for group behaviour, individual behaviours are applied through traits and updateSpecialTraitEffects_Postfix
            if (squadsInUse != null && squadsInUse.Count >= 1)
            {
                UpdateSquadList();
                //MoveSquad(hiredActorList, lastTile.posV3, formationInUse, formationRadius); // single squad/old movement
                foreach (SquadFormation activeSquad in squadsInUse.Values)
                {
                    if (listOfSquadsWithLeaders.Contains(activeSquad.squadID) == false)
                    {
                        MoveSquad(activeSquad);
                    }
                    else
                    {
                        MoveSquad(leaderDict[activeSquad.squadID]);
                    }
                    // need to update the list somewhere and clear dead/nulls
                }
                if (Input.GetKey(KeyCode.E))
                {
                    //Actor target = ClosestActorToTile(MouseTile, 3f);
                    foreach (Actor squadMate in totalSquadActorList)
                    {
                        try
                        {
                            Actor target = ClosestActorToTile(squadMate.currentTile, 1 + squadMate.curStats.range);
                            if (target != null)
                            {
                                squadMate.tryToAttack(target);
                            }
                        }
                        catch (Exception e)
                        {
                            UnityEngine.Debug.Log("exception caught:" + e.Message);
                        }
                    }


                }
            }
        }

        public int xLimit = 6;
        public int yLimit = 6;
        public static Dictionary<string, SquadFormation> squadsInUse = new Dictionary<string, SquadFormation>();
        public void MoveSquad(SquadFormation targetFormation)
        {
            Vector3 targetPos = lastTile.posV3;
            if (targetFormation.followsControlledPos == false)
            {
                targetPos = targetFormation.movementPos;
            }
            if (targetFormation.offsetPos != null && targetFormation.followsOffset && targetFormation.offsetPos != Vector3.one)
            {
                targetPos = lastTile.posV3 + targetFormation.offsetPos;
            }
            switch (targetFormation.formationType)
            {
                case "circle":
                    moveFormationCircle(targetFormation.actorList, targetPos, targetFormation.radius);
                    break;
                case "wedge1":
                    moveFormationWedge1(targetFormation.actorList, targetPos);
                    break;
                case "wedge2":
                    moveFormationWedge2(targetFormation.actorList, targetPos);
                    break;
                case "hline":
                    moveFormationLineNonCentered(targetFormation.actorList, targetPos, targetFormation.lineX, 1);
                    break;
                case "vline":
                    moveFormationLineNonCentered(targetFormation.actorList, targetPos, 1, targetFormation.lineY);
                    break;
                case "rect":
                    moveFormationLineNonCentered(targetFormation.actorList, targetPos, targetFormation.lineX, targetFormation.lineY);
                    break;
                case "dot":
                    moveFormationDot(targetFormation.actorList, targetPos);
                    break;
                default:
                    break;
            }
        }

        public void MoveSquad(SquadLeader leaderAndHisFormation)
        {
            if (leaderAndHisFormation.squad != null)
            {
                if (leaderAndHisFormation.squadLeaderActor == null && leaderAndHisFormation.squad.actorList.Count >= 2)
                {
                    UnityEngine.Debug.Log("Squad leader likely dead/null, replacing (removes 1 actor from the list)");
                    leaderAndHisFormation.squadLeaderActor = leaderAndHisFormation.squad.actorList.GetRandom();
                    leaderAndHisFormation.squad.actorList.Remove(leaderAndHisFormation.squadLeaderActor);
                }
                SquadFormation targetFormation = leaderAndHisFormation.squad;
                Vector3 targetPos = leaderAndHisFormation.squadLeaderActor.currentTile.posV3;
                if (targetFormation.followsControlledPos == false)
                {
                    targetPos = targetFormation.movementPos;
                }
                if (targetFormation.offsetPos != null && targetFormation.followsOffset && targetFormation.offsetPos != Vector3.one)
                {
                    targetPos = leaderAndHisFormation.squadLeaderActor.currentTile.posV3 + targetFormation.offsetPos;
                }
                switch (targetFormation.formationType)
                {
                    case "circle":
                        moveFormationCircle(targetFormation.actorList, targetPos, targetFormation.radius);
                        break;
                    case "wedge1":
                        moveFormationWedge1(targetFormation.actorList, targetPos);
                        break;
                    case "wedge2":
                        moveFormationWedge2(targetFormation.actorList, targetPos);
                        break;
                    case "hline":
                        moveFormationLineNonCentered(targetFormation.actorList, targetPos, targetFormation.lineX, 1);
                        break;
                    case "vline":
                        moveFormationLineNonCentered(targetFormation.actorList, targetPos, 1, targetFormation.lineY);
                        break;
                    case "rect":
                        moveFormationLineNonCentered(targetFormation.actorList, targetPos, targetFormation.lineX, targetFormation.lineY);
                        break;
                    case "dot":
                        moveFormationDot(targetFormation.actorList, targetPos);
                        break;
                    default:
                        break;
                }
            }

        }

        public List<string> formationType = new List<string>();
        public string formationInUse = "circle";
        public void CycleFormation(SquadFormation targetSquad)
        {
            switch (targetSquad.formationType)
            {
                case "circle":
                    targetSquad.formationType = "wedge1"; // wedge
                    break;
                case "wedge1":
                    targetSquad.formationType = "wedge2";
                    break;
                case "wedge2":
                    targetSquad.formationType = "hline";
                    break;
                case "hline":
                    targetSquad.formationType = "vline";
                    break;
                case "vline":
                    targetSquad.formationType = "rect";
                    break;
                case "rect":
                    targetSquad.formationType = "dot";
                    break;
                case "dot":
                    targetSquad.formationType = "circle";
                    break;
                default:
                    break;
            }
        }

        public static List<ActorTrait> positiveTraitsForLevels => AssetManager.traits.list.OrderBy(x => x.type == TraitType.Positive).ToList();

        public void UpdateSquadList()
        {
            if (squadsInUse != null && squadsInUse.Count >= 1)
            {
                for (int i = 0; i < squadsInUse.Count; i++)
                {
                    List<Actor> workingList = squadsInUse.Values.ToList()[i].actorList;
                    if (workingList != null && workingList.Count >= 1)
                    {
                        for (int j = 0; j < workingList.Count; j++)
                        {
                            if (workingList[j] == null)
                            {
                                workingList.Remove(workingList[j]);
                            }
                            else
                            {
                                ActorStatus data = workingList[j].data;
                                if (data.alive == false)
                                {
                                    workingList.Remove(workingList[j]);
                                }
                            }
                        }
                    }
                }
            }

            // check if anyone is dead or null and make sure theyre not in the list

        }

        public Actor lastInteractionActor;

        public void AttackActor(Actor attacker, Actor target, float damage)
        {
            attacker.punchTargetAnimation(target.currentPosition, target.currentTile, true, false, 40f);
            Sfx.play("punch", true, attacker.currentPosition.x, attacker.currentPosition.y);
            target.getHit(damage, true, AttackType.Other, null, true);
        }

        public static HashSet<Actor> totalSquadActorList = new HashSet<Actor>();

        public void AddActorToSquad(SquadFormation targetSquad, Actor targetActor)
        {
            if (targetSquad.actorList.Contains(targetActor) == false)
                targetSquad.actorList.Add(targetActor);
            if (totalSquadActorList.Contains(targetActor) == false)
                totalSquadActorList.Add(targetActor);
        }
        public void RemoveActorFromSquad(Actor targetActor)
        {
            if (squadsInUse != null && squadsInUse.Count >= 1)
            {
                for (int i = 0; i < squadsInUse.Count; i++)
                {
                    List<Actor> workingList = squadsInUse.Values.ToList()[i].actorList;
                    if (workingList != null && workingList.Count >= 1)
                    {
                        for (int j = 0; j < workingList.Count; j++)
                        {
                            if (workingList[j] == targetActor)
                            {
                                workingList.Remove(workingList[j]);
                                return;
                            }
                        }
                    }
                }
            }
            if (totalSquadActorList.Contains(targetActor))
            {
                totalSquadActorList.Remove(targetActor);
            }
        }

        public static Actor ClosestActorToTile(WorldTile pTarget, float range, bool forInteraction = false)
        {
            Actor returnActor = null;
            List<Actor> targets = validTargets().ToList();
            if (forInteraction)
            { // quick fix for validTargets/cachedTargetList preventing interacting with controlled character
                targets = MapBox.instance.units.getSimpleList();
            }
            foreach (Actor actorToCheck in targets)
            {
                float actorDistanceFromTile = Toolbox.Dist(actorToCheck.currentPosition.x, actorToCheck.currentPosition.y, (float)pTarget.pos.x, (float)pTarget.pos.y);
                if (actorDistanceFromTile < range)
                {
                    range = actorDistanceFromTile;
                    returnActor = actorToCheck;
                }
            }
            return returnActor;
        }
      
        public static void moveFormationDot(List<Actor> formation, Vector3 position)
        {
            if (formation != null)
            {
                float num = 6.28318548f / (float)formation.Count;
                for (int i = 0; i < formation.Count; i++)
                {
                    float f = (float)i * num;
                    Vector3 vector = position; // the radius * count/10f makes the radius grow slightly the more people are used0
                    WorldTile tileFromVector = MapBox.instance.GetTile((int)vector.x, (int)vector.y);
                    if (tileFromVector == null)
                    {
                        UnityEngine.Debug.Log("Movement tile not inside world, breaking");
                        return;
                    }
                    BasicMoveAndWait(formation[i], tileFromVector);
                    if (useFlashOnMove)
                        flashEffects.flashPixel(tileFromVector, 10, ColorType.White);
                    if (formation[i].GetComponent<Boat>() != null) // boat movement
                    {
                        formation[i].nextStepPosition = vector;
                    }

                }
            }
        }

        public static bool useFlashOnMove = true;
        public static void moveFormationCircle(List<Actor> formation, Vector3 position, int radius)
        {
            if (formation != null)
            {
                float num = 6.28318548f / (float)formation.Count;
                for (int i = 0; i < formation.Count; i++)
                {
                    float f = (float)i * num;
                    Vector3 vector = position + new Vector3(Mathf.Cos(f), Mathf.Sin(f), 0f) * ((float)radius + ((float)formation.Count / 10f)); // the radius * count/10f makes the radius grow slightly the more people are used
                    WorldTile tileFromVector = MapBox.instance.GetTile((int)vector.x, (int)vector.y);
                    if (tileFromVector == null)
                    {
                        UnityEngine.Debug.Log("Movement tile not inside world, breaking");
                        return;
                    }
                    BasicMoveAndWait(formation[i], tileFromVector);
                    if (useFlashOnMove)
                        flashEffects.flashPixel(tileFromVector, 10, ColorType.White);
                    if (formation[i].GetComponent<Boat>() != null) // boat movement
                    {
                        formation[i].nextStepPosition = vector;
                    }

                }
            }
        }

        public static void moveFormationWedge1(List<Actor> formation, Vector3 position)
        {
            Vector3 posV = position;
            int x = -(formation.Count / 2);
            int y = -(formation.Count / 2);
            foreach (Actor actor in formation)
            {
                WorldTile tileFromVector = MapBox.instance.GetTile((int)position.x + x, (int)position.y + y);
                BasicMoveAndWait(actor, tileFromVector);

                if (y != x)
                {
                    y++;
                }
                else
                {
                    x++;
                }
            }
        }
        public static void moveFormationWedge2(List<Actor> formation, Vector3 position)
        {
            Vector3 posV = position;
            int num = formation.Count / 2;
            int num2 = formation.Count / 2;
            foreach (Actor actor in formation)
            {
                WorldTile tileFromVector = MapBox.instance.GetTile((int)position.x - num, (int)position.y + num2);
                BasicMoveAndWait(actor, tileFromVector);

                if (num2 != num)
                {
                    num2--;
                }
                else
                {
                    num--;
                }
            }
        }
        public static bool lineFormationCentered = true;
        public void lineFormation(List<Actor> formation, Vector3 position, int xLimit, int yLimit) // lines, squares, rectangles
        {
            if (lineFormationCentered)
            {
                moveFormationLineNonCentered(formation, position, xLimit, yLimit);
            }
            else
            {

            }
        }
        public static void moveFormationLineNonCentered(List<Actor> formation, Vector3 position, int xLimit, int yLimit) // lines, squares, rectangles
        {
            int positionX = 0;
            int positionY = 0;
            if (yLimit == 1)
            {
                positionX = 1;
            }
            if (xLimit == 1)
            {
                positionY = 1;
            }

            for (int i = 0; i < formation.Count; i++)
            {
                if (positionX == xLimit)
                {
                    positionY++;
                    positionX = 0;
                }
                if (positionY == yLimit)
                {
                    positionY = 0;
                    positionX = 0;
                }
                Vector3 vector = new Vector3(position.x + positionX, position.y + positionY);
                WorldTile targetTile = MapBox.instance.GetTile((int)vector.x, (int)vector.y);
                if (targetTile == null)
                {
                    UnityEngine.Debug.Log("Movement tile not inside world, breaking");
                    return;
                }
                BasicMoveAndWait(formation[i], targetTile);
                if (useFlashOnMove)
                    flashEffects.flashPixel(targetTile, 10, ColorType.White);
                if (formation[i].GetComponent<Boat>() != null) // boat movement
                {
                    formation[i].nextStepPosition = vector;
                }
                positionX++;
            }
        }
        public static void moveFormationLineCentered(List<Actor> formation, Vector3 position, int xLimit, int yLimit) // lines, squares, rectangles
        {
            // needs work
            int positionX = 0;
            int positionY = 0;

            int offsetX = 0;
            int offsetY = 0;
            if (xLimit != 1)
            {
                offsetX = (-(xLimit));
            }
            if (yLimit != 1)
            {
                offsetY = (-(yLimit));
            }
            for (int i = 0; i < formation.Count; i++)
            {
                if (positionX == (xLimit / 2))
                {
                    positionY++;
                    positionX = 0;
                }
                if (positionY == (yLimit / 2))
                {
                    positionY = 0;
                    positionX = 0;
                }
                Vector3 vector = new Vector3(position.x + positionX, position.y + positionY);
                WorldTile targetTile = MapBox.instance.GetTile((int)vector.x, (int)vector.y);
                if (targetTile == null)
                {
                    UnityEngine.Debug.Log("Movement tile not inside world, breaking");
                    return;
                }
                BasicMoveAndWait(formation[i], targetTile);
                if (useFlashOnMove)
                    flashEffects.flashPixel(targetTile, 10, ColorType.White);
                if (formation[i].GetComponent<Boat>() != null) // boat movement
                {
                    formation[i].nextStepPosition = vector;
                }
                positionX++;
            }
        }


        public void followActor(Actor target, float speed = 5f)
        {
            Vector3 posV = target.currentPosition;
            Camera.main.transform.position = Vector3.Lerp(Camera.main.transform.position, posV, speed * Time.deltaTime);
        }

        private void movementStuff()
        {
            // RPG movement
            lastTile = MapBox.instance.GetTileSimple((int)controlledActor.currentPosition.x, (int)controlledActor.currentPosition.y);
            if (Input.GetKey(KeyCode.W))
            {
                directionMoving = "up";
                if (Input.GetKey(KeyCode.A))
                {
                    directionMoving = "upLeft";
                }
                else if (Input.GetKey(KeyCode.D))
                {
                    directionMoving = "upRight";
                }
            }
            else if (Input.GetKey(KeyCode.S))
            {
                directionMoving = "down";
                if (Input.GetKey(KeyCode.A))
                {
                    directionMoving = "downLeft";
                }
                else if (Input.GetKey(KeyCode.D))
                {
                    directionMoving = "downRight";
                }
            }
            else if (Input.GetKey(KeyCode.A))
            {
                directionMoving = "left";
                if (Input.GetKey(KeyCode.W))
                {
                    directionMoving = "upLeft";
                }
                else if (Input.GetKey(KeyCode.S))
                {
                    directionMoving = "downLeft";
                }
            }
            else if (Input.GetKey(KeyCode.D))
            {
                directionMoving = "right";
                if (Input.GetKey(KeyCode.W))
                {
                    directionMoving = "upRight";
                }
                else if (Input.GetKey(KeyCode.S))
                {
                    directionMoving = "downRight";
                }
            }
            else
            {
                directionMoving = null;
            }
            if (controlledActor.haveStatus("sleep"))
            {
                directionMoving = null;
            }
            // when user isnt moving (or interacting?), make controlled be still
            // could add some kind of command queue
            if (directionMoving == null)
            {
                controlledActor.stopMovement();
                controlledActor.cancelAllBeh();
            }
            if (directionMoving != null)
            {
                WorldTile movementTile;
                switch (directionMoving)
                {
                    case "up":
                        movementTile = MapBox.instance.GetTile(lastTile.pos.x, lastTile.pos.y + 1);
                        doMovement(movementTile);
                        break;
                    case "down":
                        movementTile = MapBox.instance.GetTile(lastTile.pos.x, lastTile.pos.y - 1);
                        doMovement(movementTile);
                        break;
                    case "left":
                        movementTile = MapBox.instance.GetTile(lastTile.pos.x - 1, lastTile.pos.y);
                        doMovement(movementTile);
                        break;
                    case "right":
                        movementTile = MapBox.instance.GetTile(lastTile.pos.x + 1, lastTile.pos.y);
                        doMovement(movementTile);
                        break;
                    case "upLeft":
                        movementTile = MapBox.instance.GetTile(lastTile.pos.x - 1, lastTile.pos.y + 1);
                        doMovement(movementTile);
                        break;
                    case "upRight":
                        movementTile = MapBox.instance.GetTile(lastTile.pos.x + 1, lastTile.pos.y + 1);
                        doMovement(movementTile);
                        break;
                    case "downLeft":
                        movementTile = MapBox.instance.GetTile(lastTile.pos.x - 1, lastTile.pos.y - 1);
                        doMovement(movementTile);
                        break;
                    case "downRight":
                        movementTile = MapBox.instance.GetTile(lastTile.pos.x + 1, lastTile.pos.y - 1);
                        doMovement(movementTile);
                        break;
                    default:
                        break;
                }
            }

        }

        public void doMovement(WorldTile targetTile)
        {
            bool isThereBuilding = (targetTile.building != null);
            if (isThereBuilding)
            {
                string buildingId = targetTile.building.stats.id;
                if (buildingId.Contains("wall"))
                {
                    return;
                }
                if (buildingId == "homePortal")
                {
                    LoadHomeWorld();
                }
                if (buildingId == "randomPortal")
                {
                    LoadRandomWorld();
                }
            }
            // this I added to avoid strict movement a bit, avoid actor stuck in water as well
            if (isBoat == false && controlledActor.currentTile.Type.liquid && targetTile.Type.liquid)
                isBoat = true;
            // strict movement
            if (isBoat == false && targetTile.Type.liquid || isBoat == false && targetTile.Type.edge_mountains)
            {
                return;
            }
            lastTile = targetTile; // is this part of the desync?
            BasicMoveAndWait(controlledActor, targetTile);
        }

        public static PixelFlashEffects flashEffects => MapBox.instance.flashEffects;

        public static bool addExperience_Prefix(int pValue, Actor __instance)
        {
            ActorStats stats = __instance.stats;
            ActorStatus data = __instance.data;
            if (stats.canLevelUp)
            {
                int expToLevelup = __instance.getExpToLevelup();
                data.experience += pValue;
                if (data.experience >= expToLevelup)
                {
                    data.experience = 0;
                    data.level++;
                    if (__instance == controlledActor)
                    {
                        if (data.level % 5 == 0)
                        {
                            ActorTrait newTrait = null;
                            int attempts = 0;
                            while ((newTrait == null || controlledActor.haveTrait(newTrait.id)) && attempts < 3)
                            {
                                newTrait = positiveTraitsForLevels.GetRandom();
                                attempts++;
                            }
                            //controlledActor.addTrait(newTrait.id);
                            //UnityEngine.Debug.Log("Intentionally added " + newTrait.id + " to " + controlledActor.name);
                        }
                    }
                    BaseStats curStats = __instance.curStats;
                    __instance.restoreHealth(curStats.health);
                }
            }
            return false;
        }

        // auto retaliate, known to cause errors but balances out players relentless killing innocents
        // maybe filter to only retaliate/do something else if people hit "innocent" actor
        public static void getHit_Postfix(float pDamage, bool pFlash, AttackType pType, BaseSimObject pAttacker, bool pSkipIfShake, Actor __instance)
        {
            ActorStatus victimData = null;

            ActorStatus attackerData = null;

            if (__instance != null)
            {
                victimData = __instance.data;
            }
            if (pAttacker != null)
            {
                //attackerData = pAttacker.data; // was data, probably null
            }
            if (attackerData != null && victimData != null && victimData.alive && attackerData.alive)
            {
                try
                {
                    if (Toolbox.randomBool() && Toolbox.randomBool() && (bool)__instance.tryToAttack(pAttacker))
                    {
                        // UnityEngine.Debug.Log("Retaliation/recoil success")
                    }
                }
                catch (Exception e)
                {
                    UnityEngine.Debug.Log("exception caught: " + e.Message);
                }

            }
        }

        public static void getExpToLevelup_Postfix(Actor __instance, ref int __result)
        {
            ActorStatus data = __instance.data;

            __result = settings.baseExpToLevelup + (data.level - 1) * settings.expToLevelUpScale;
            /* heal controlled actor on level up?
            if (__instance == controlledActor)
            {
                BaseStats curStats = Reflection.GetField(controlledActor.GetType(), controlledActor, "curStats") as BaseStats;
                controlledActor.restoreHealth(curStats.health / 10); // 10%
            }
            */
        }

        public static bool updateMouseCameraDrag_Prefix()
        {
            if (controlledActor != null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        public static bool increaseKillCount_Prefix(Actor __instance) // became newKillAction, dont need this patch though
        {
            ActorStatus data = __instance.data;

            data.kills++;
            if (data.kills > 10)
            {
                __instance.addTrait("veteran");
            }
            __instance.addExperience(settings.expGainOnKill);

            if (controlledActor != null)
            {
                BaseStats curStats = controlledActor.curStats;
                if (__instance == controlledActor)
                {
                    // heal on kill, kinda op
                    controlledActor.restoreHealth(curStats.health / 10); // 10%
                }
            }
            return false;
        }
        public void BankSetup()
        {
            UnityEngine.Debug.Log("Bank start");
            //copied and only slightly changed from igniz's traitbonanza
            string path = Path.Combine(Application.streamingAssetsPath, "Mods");
            string text = Path.Combine(path, "bank" + ".json");
            bool flag = Application.platform == RuntimePlatform.WindowsPlayer;
            if (flag)
            {
                text = text.Replace("\\", "/");
            }

            bool fileExist = File.Exists(text);
            if (fileExist)
            {
                string value = File.ReadAllText(text);
                itemBank = JsonConvert.DeserializeObject<ItemBank>(value);
                UnityEngine.Debug.Log("loaded saved bank");
            }
            else
            {//file doesnt exist, setup defaults
                itemBank = new ItemBank();
                string text2 = JsonConvert.SerializeObject(itemBank, Formatting.Indented);
                UnityEngine.Debug.Log("created and saved default bank");
                File.WriteAllText(text, text2);
            }
            UnityEngine.Debug.Log("Bank end");
        }
        //standalone methods for calling later if needed
        public static void saveBank()
        {
            string path = Path.Combine(Application.streamingAssetsPath, "Mods");
            string text = Path.Combine(path, "bank" + ".json");
            string text2 = JsonConvert.SerializeObject(itemBank, Formatting.Indented);
            UnityEngine.Debug.Log("saved itemBank");
            File.WriteAllText(text, text2);
        }
        public void loadBank()
        {
            string path = Path.Combine(Application.streamingAssetsPath, "Mods");
            string text = Path.Combine(path, "bank" + ".json");
            string value = File.ReadAllText(text);
            itemBank = JsonConvert.DeserializeObject<ItemBank>(value);
            UnityEngine.Debug.Log("loaded itemBank");
        }

        public static ItemBank itemBank;

        public void StoreResourceInBank(string resource, int amount)
        {
            if (amount > 0 && controlledInventory.resources[resource] > amount)
            {
                controlledInventory.resources[resource] -= amount;
                itemBank.resources[resource] += amount;
            }
            saveBank(); // update bank file
        }

        public static float cowCoolDown = 0f; // global cooldown for all milking, could change later

        // resource tooltip override
        public static bool showResource_Prefix(Tooltip __instance)
        {
            if (bankOpen || invOpen)
            {
                string resourceId = UppercaseFirst(Tooltip.info_resource.id);
                if (resourceId != null)
                {
                    __instance.name.text = resourceId;
                }
                return false;
            }
            return true;
        }

        static string UppercaseFirst(string s)
        {
            if (string.IsNullOrEmpty(s))
            {
                return string.Empty;
            }
            return char.ToUpper(s[0]) + s.Substring(1);
        }
        //copied and edited from ncms directly
        public static void ShowWindow(string windowId, ScrollWindow pWindowFrom = null, string pDistPosition = "right", string pStartPosition = "right", bool pSkipAnimation = false)
        {
            bool flag = Windows.AllWindows.ContainsKey(windowId) && !ScrollWindow.currentWindows.Contains(Windows.GetWindow(windowId));
            if (flag)
            {
                Windows.AllWindows[windowId].show(pWindowFrom, pDistPosition, pStartPosition, pSkipAnimation);
            }
        }

        public static Dictionary<string, Dictionary<string, int>> craftables = new Dictionary<string, Dictionary<string, int>>();

        public static Dictionary<string, Sprite> craftableIcons = new Dictionary<string, Sprite>();

        public static bool hasAddedItemsFromAssetManager;
        public static bool hasAddedCustomItems;
        public static List<string> customItemList = new List<string>();

        public void AddCraftables()
        {
            if (hasAddedItemsFromAssetManager == false)
            {
                foreach (ItemAsset item in AssetManager.items.list)
                {
                    if (item.id[0] != '_' && item.id != "base" && item.id != "rocks" && item.id != "hands" && item.id != "jaws" && item.id != "claws" && item.id != "snowball" && item.id != "venomous_bite" && item.id != "shotgun")
                    {
                        if (item.materials != null && item.materials.Count > 0)
                        {
                            foreach (string material in item.materials)
                            {
                                string id = material + "_" + item.id; // probably split from this id after clicking button
                                craftables.Add(id, new Dictionary<string, int>() { { material, 3 } });
                                ItemData newData = new ItemData();
                                newData.material = material;
                                newData.id = item.id;
                                newData.by = "";
                                craftableIcons.Add(id, item.getSprite(newData));
                            }
                        }
                    }
                }
                hasAddedItemsFromAssetManager = true;
                craftables.Add("cake", new Dictionary<string, int>() { { "eggs", 2 }, { "milk", 1 }, { "wheat", 3 } });
                craftableIcons.Add("cake", Resources.Load("ui/Icons/cake", typeof(Sprite)) as Sprite);
                customItemList.Add("cake");

                hasAddedCustomItems = true;
                //craftables.Add("woodHelmet", new Dictionary<string, int>() { { "wood", 3 } });

            }
        }
        //craftables.Add("woodHelmet", new Dictionary<string, int>() { { "wood", 3 } });
        //craftables[itemId].Add(craftableId, amount);

        public static bool hasAddedCraftableWindow;
        public static void OpenCraftableWindow()
        {
            //Config.paused = true;
            #region craftablewindow
            UnityEngine.Debug.Log("opening craftables window");
            if (hasAddedCraftableWindow == true)
            {
                ShowWindow("survivor_craftable", null, "right", "right", true); // show window if it exists
                                                                                // refresh displayed resources, not sure if needed
                var craftableWindow = NCMS.Utils.Windows.GetWindow("survivor_craftable");
                Transform Background = craftableWindow.transform.Find("Background");
                var Content = Background.Find("Scroll View").Find("Viewport").Find("Content");
                for (int i = 0; i < Content.transform.childCount; i++)
                {
                    GameObject.Destroy(Content.transform.GetChild(i).gameObject);
                }

                //ButtonResource resourceButton = NCMS.Utils.GameObjects.FindEvenInactive("ResourceElement").GetComponent<ButtonResource>();

                var rect = Content.GetComponent<RectTransform>();
                rect.pivot = new Vector2(0, 1);
                rect.sizeDelta = new Vector2(0, Mathf.Abs(GetPosByIndex(craftables.Keys.Count).y) + 100);

                var backgroundRect = Background.GetComponent<RectTransform>();
                //rect.pivot = new Vector2(0, 1);
                backgroundRect.sizeDelta = new Vector2(216, 405); // new Vector2(216, 265) original (long button)

                var resourcesList = itemBank.resources;
                int index = 0;
                foreach (string p in craftables.Keys)
                {
                    string id = p;
                    loadCraftablesButton(id, index, Content.transform, "craftable");
                    index++;
                }
                //bankOpen = true;
            }
            else
            { // create window from scratch
                var craftableWindow = NCMS.Utils.Windows.CreateNewWindow("survivor_craftable", "Craftable");

                #region var description

                //string hlColor = "#65BD00FF";

                //var description = "hi";
                #endregion
                //
                craftableWindow.transform.Find("Background").Find("Scroll View").gameObject.SetActive(true);

                //ActorTrait upgradableTrait = AssetManager.traits.get(upgradeList.GetRandom());
                //Sprite traitSprite = (Sprite)Resources.Load("ui/Icons/" + upgradableTrait.path_icon, typeof(Sprite));

                Transform Background = craftableWindow.transform.Find("Background");

                UnityEngine.UI.Image backGroundImage = Background.GetComponent<UnityEngine.UI.Image>();
                Background.transform.localScale = new Vector3(0.75f, 0.75f);
                Sprite newsprite = (Sprite)Resources.Load("ui/buttonBig", typeof(Sprite)); // load new window background (simple button)
                backGroundImage.sprite = newsprite;

                var closeObject = Background.Find("CloseBackgound").gameObject; // missing R in name lmao
                closeObject.transform.localPosition = new Vector3(84.702f, 50.0593f);

                var gradientImageObject = Background.Find("Scrollgradient").gameObject;
                UnityEngine.UI.Image gradientImage = gradientImageObject.GetComponent<UnityEngine.UI.Image>();
                gradientImage.enabled = false; // disable shadow for usual window

                var scrollRectObject = Background.Find("Scroll View").gameObject;
                scrollRectObject.transform.localPosition = new Vector3(5, -104, 0);
                scrollRectObject.transform.localScale = new Vector3(1.25f, 1.25f);
                ScrollRect scrollRect = scrollRectObject.GetComponent<ScrollRect>();
                scrollRect.vertical = true; // disable vertical drag of normal window content

                var viewPortObject = Background.Find("Scroll View").Find("Viewport").gameObject;
                RectTransform scrollRectTransform = viewPortObject.GetComponent<RectTransform>();
                scrollRectTransform.sizeDelta = new Vector3(0, -55);

                var name = craftableWindow.transform.Find("Background").Find("Name").gameObject;
                var nameText = name.GetComponent<Text>();
                nameText.gameObject.SetActive(false);

                var Content = Background.Find("Scroll View").Find("Viewport").Find("Content");
                for (int i = 0; i < Content.transform.childCount; i++)
                {
                    GameObject.Destroy(Content.transform.GetChild(i).gameObject);
                }

                //ButtonResource resourceButton = NCMS.Utils.GameObjects.FindEvenInactive("ResourceElement").GetComponent<ButtonResource>();

                var rect = Content.GetComponent<RectTransform>();
                rect.pivot = new Vector2(0, 1);
                rect.sizeDelta = new Vector2(0, Mathf.Abs(GetPosByIndex(craftables.Keys.Count).y) + 100);

                var backgroundRect = Background.GetComponent<RectTransform>();
                //rect.pivot = new Vector2(0, 1);
                backgroundRect.sizeDelta = new Vector2(216, 405); // new Vector2(216, 265) original (long button)

                //var resourcesList = itemBank.resources;
                int index = 0;
                foreach (string p in craftables.Keys)
                {
                    string id = p;
                    loadCraftablesButton(id, index, Content.transform, "craftable");
                    index++;
                }
                #endregion
                hasAddedCraftableWindow = true;
                //bankOpen = true;
                ShowWindow("survivor_craftable", null, "right", "right", true);
            }
            //OpenInventoryWindow(); // try always opening inv after
        }

        private static void loadCraftablesButton(string pID, int pIndex, Transform parent, string windowID)
        {
            Sprite sprite = craftableIcons[pID];
            string[] splitArray = pID.ToLower().Split(char.Parse("_"));
            string tooltipText = "";
            if (splitArray.Count() > 1)
            {
                tooltipText = FirstCharToUpper(splitArray[1]);
            }
            else
            {
                tooltipText = FirstCharToUpper(pID);
            }
            PowerButton elementButton = NCMS.Utils.PowerButtons.CreateButton("craftable_" + pID + "_" + uniqueIndex, sprite, tooltipText, "", Vector2.zero, ButtonType.Click, parent, delegate
            {
                if (controlledActor != null)
                {
                    if (customItemList.Contains(pID)) // sort this particular check a little easier
                    {
                        //UnityEngine.Debug.Log("custom/interactable, id: " + pID);
                        bool hasResourcesToCraft = true;
                        foreach (string resource in craftables[pID].Keys) // loop through ingredients 
                        {
                            if (controlledInventory.resources[resource] >= craftables[pID][resource]) // check amounts
                            {
                                //controlledInventory.resources[pID] -= craftables[pID][resource];
                                //controlledInventory.resources[resource] += craftables[pID][resource];
                            }
                            else
                            {
                                hasResourcesToCraft = false;
                                //UnityEngine.Debug.Log("not enough resources: " + resource);
                            }
                        }
                        if (hasResourcesToCraft)
                        {
                            foreach (string resource in craftables[pID].Keys) // loop through ingredients 
                            {
                                controlledInventory.resources[resource] -= craftables[pID][resource];
                            }
                            controlledInventory.resources[pID] += 1; // +1 of the item being crafted
                        }
                    }
                    else
                    {
                        ItemAsset itemAsset = AssetManager.items.get(splitArray[1]);
                        ItemData newData = new ItemData();
                        newData.id = splitArray[1];
                        newData.material = splitArray[0];
                        controlledActor.equipment.getSlot(itemAsset.equipmentType).emptySlot();
                        controlledActor.equipment.getSlot(itemAsset.equipmentType).setItem(newData);
                        controlledActor.statsDirty = true;
                        UnityEngine.Debug.Log("Gave item?");
                    }
                }
                UnityEngine.Debug.Log(tooltipText);
            });
            uniqueIndex++;
            elementButton.transform.localPosition = GetPosByIndex(pIndex); // set button in right spot

            //elementButton.click // divider for before/after
            /*
            ButtonResource resourceButton = GameObject.Instantiate<ButtonResource>(resourceButtonPref, parent);
            resourceButton.load(resourceAsset, itemBank.resources[pID]);

            resourceButton.transform.localPosition = GetPosByIndex(pIndex); // set button in right spot


            var button = resourceButton.gameObject.GetComponent<UnityEngine.UI.Button>();
            resourceButton.textAmount.text = pTotal.ToString();
            button.onClick.AddListener(() => callback(resourceButton));
            */

        }

        public static bool hasAddedBankWindow;
        public static void OpenBankWindow()
        {
            //Config.paused = true;
            #region bankWindow
            UnityEngine.Debug.Log("opening bank window");
            if (hasAddedBankWindow == true)
            {
                ShowWindow("survivor_bank", null, "right", "right", true); // show window if it exists
                                                                           // refresh displayed resources, not sure if needed
                var bankWindow = NCMS.Utils.Windows.GetWindow("survivor_bank");
                Transform Background = bankWindow.transform.Find("Background");
                var Content = Background.Find("Scroll View").Find("Viewport").Find("Content");
                for (int i = 0; i < Content.transform.childCount; i++)
                {
                    GameObject.Destroy(Content.transform.GetChild(i).gameObject);
                }

                //ButtonResource resourceButton = NCMS.Utils.GameObjects.FindEvenInactive("ResourceElement").GetComponent<ButtonResource>();

                var rect = Content.GetComponent<RectTransform>();
                rect.pivot = new Vector2(0, 1);
                rect.sizeDelta = new Vector2(0, Mathf.Abs(GetPosByIndex(itemBank.resources.Count).y) + 100);

                var backgroundRect = Background.GetComponent<RectTransform>();
                //rect.pivot = new Vector2(0, 1);
                backgroundRect.sizeDelta = new Vector2(216, 405); // new Vector2(216, 265) original (long button)

                var resourcesList = itemBank.resources;
                int index = 0;
                foreach (KeyValuePair<string, int> p in resourcesList)
                {
                    string id = p.Key;
                    int amount = p.Value;
                    if (amount > 0)
                    {
                        ResourceAsset resourceAsset = AssetManager.resources.get(id);
                        loadResourceButton(id, index, amount, Content.transform, "bank", resourceAsset);
                        index++;
                    }
                }
                //bankOpen = true;
            }
            else
            { // create window from scratch
                var bankWindow = NCMS.Utils.Windows.CreateNewWindow("survivor_bank", "Bank");

                #region var description

                //string hlColor = "#65BD00FF";

                //var description = "hi";
                #endregion
                //
                bankWindow.transform.Find("Background").Find("Scroll View").gameObject.SetActive(true);

                //ActorTrait upgradableTrait = AssetManager.traits.get(upgradeList.GetRandom());
                //Sprite traitSprite = (Sprite)Resources.Load("ui/Icons/" + upgradableTrait.path_icon, typeof(Sprite));

                Transform Background = bankWindow.transform.Find("Background");

                UnityEngine.UI.Image backGroundImage = Background.GetComponent<UnityEngine.UI.Image>();
                Background.transform.localScale = new Vector3(0.75f, 0.75f);
                Sprite newsprite = (Sprite)Resources.Load("ui/buttonBig", typeof(Sprite)); // load new window background (simple button)
                backGroundImage.sprite = newsprite;

                var closeObject = Background.Find("CloseBackgound").gameObject; // missing R in name lmao
                closeObject.transform.localPosition = new Vector3(84.702f, 50.0593f);

                var gradientImageObject = Background.Find("Scrollgradient").gameObject;
                UnityEngine.UI.Image gradientImage = gradientImageObject.GetComponent<UnityEngine.UI.Image>();
                gradientImage.enabled = false; // disable shadow for usual window

                var scrollRectObject = Background.Find("Scroll View").gameObject;
                scrollRectObject.transform.localPosition = new Vector3(5, -104, 0);
                scrollRectObject.transform.localScale = new Vector3(1.25f, 1.25f);
                ScrollRect scrollRect = scrollRectObject.GetComponent<ScrollRect>();
                scrollRect.vertical = true; // disable vertical drag of normal window content

                var viewPortObject = Background.Find("Scroll View").Find("Viewport").gameObject;
                RectTransform scrollRectTransform = viewPortObject.GetComponent<RectTransform>();
                scrollRectTransform.sizeDelta = new Vector3(0, -55);

                var name = bankWindow.transform.Find("Background").Find("Name").gameObject;
                var nameText = name.GetComponent<Text>();
                nameText.gameObject.SetActive(false);

                var Content = Background.Find("Scroll View").Find("Viewport").Find("Content");
                for (int i = 0; i < Content.transform.childCount; i++)
                {
                    GameObject.Destroy(Content.transform.GetChild(i).gameObject);
                }

                //ButtonResource resourceButton = NCMS.Utils.GameObjects.FindEvenInactive("ResourceElement").GetComponent<ButtonResource>();

                var rect = Content.GetComponent<RectTransform>();
                rect.pivot = new Vector2(0, 1);
                rect.sizeDelta = new Vector2(0, Mathf.Abs(GetPosByIndex(itemBank.resources.Count).y) + 100);

                var backgroundRect = Background.GetComponent<RectTransform>();
                //rect.pivot = new Vector2(0, 1);
                backgroundRect.sizeDelta = new Vector2(216, 405); // new Vector2(216, 265) original (long button)

                var resourcesList = itemBank.resources;
                int index = 0;
                foreach (KeyValuePair<string, int> p in resourcesList)
                {
                    string id = p.Key;
                    int amount = p.Value;
                    if (amount > 0)
                    {
                        ResourceAsset resourceAsset = AssetManager.resources.get(id);
                        loadResourceButton(id, index, amount, Content.transform, "bank", resourceAsset);
                        index++;
                    }
                }
                #endregion
                hasAddedBankWindow = true;
                //bankOpen = true;
                ShowWindow("survivor_bank", null, "right", "right", true);
            }
            OpenInventoryWindow(); // try always opening inv after
        }

        public static bool hasAddedWindowInventory;

        public static void OpenInventoryWindow()
        {
            if (controlledActor == null || controlledInventory == null) return;
            //Config.paused = true;
            #region inventoryWindow
            UnityEngine.Debug.Log("opening inventory window, is bank open: " + bankOpen.ToString());
            if (bankOpen && tryingToOpenBoth == false)
            {
                tryingToOpenBoth = true;
            }
            if (hasAddedWindowInventory == true)
            {
                ShowWindow("survivor_inventory", null, "left", "left", true); // show window if it exists
                                                                              // then refresh the content.. might be unnecessary, try cleaning later
                var inventoryWindow = NCMS.Utils.Windows.GetWindow("survivor_inventory");
                Transform Background = inventoryWindow.transform.Find("Background");
                var Content = Background.Find("Scroll View").Find("Viewport").Find("Content");
                for (int i = 0; i < Content.transform.childCount; i++)
                {
                    GameObject.Destroy(Content.transform.GetChild(i).gameObject);
                }

                //ButtonResource resourceButton = NCMS.Utils.GameObjects.FindEvenInactive("ResourceElement").GetComponent<ButtonResource>();

                var rect = Content.GetComponent<RectTransform>();
                rect.pivot = new Vector2(0, 1);
                rect.sizeDelta = new Vector2(0, Mathf.Abs(GetPosByIndex(itemBank.resources.Count).y) + 100);

                var backgroundRect = Background.GetComponent<RectTransform>();
                //rect.pivot = new Vector2(0, 1);
                backgroundRect.sizeDelta = new Vector2(216, 405); // new Vector2(216, 265) original (long button)

                var resourcesList = controlledInventory.resources;
                int index = 0;
                foreach (KeyValuePair<string, int> p in resourcesList)
                {
                    string id = p.Key;
                    int amount = p.Value;
                    if (amount > 0)
                    {
                        ResourceAsset resourceAsset = AssetManager.resources.get(id);
                        loadResourceButton(id, index, amount, Content.transform, "inventory", resourceAsset);
                        index++;
                    }
                }
                // new Vector3((Screen.width / 4), inventoryWindow.transform.position.y, inventoryWindow.transform.position.z);
            }
            else
            { // create window from scratch
                var inventoryWindow = NCMS.Utils.Windows.CreateNewWindow("survivor_inventory", "Inventory");
                #region var description

                //string hlColor = "#65BD00FF";

                //var description = "hi";
                #endregion
                //
                inventoryWindow.transform.Find("Background").Find("Scroll View").gameObject.SetActive(true);

                //ActorTrait upgradableTrait = AssetManager.traits.get(upgradeList.GetRandom());
                //Sprite traitSprite = (Sprite)Resources.Load("ui/Icons/" + upgradableTrait.path_icon, typeof(Sprite));

                Transform Background = inventoryWindow.transform.Find("Background");

                UnityEngine.UI.Image backGroundImage = Background.GetComponent<UnityEngine.UI.Image>();
                Background.transform.localScale = new Vector3(0.75f, 0.75f);
                Sprite newsprite = (Sprite)Resources.Load("ui/buttonBig", typeof(Sprite)); // load new window background (simple button)
                backGroundImage.sprite = newsprite;

                var closeObject = Background.Find("CloseBackgound").gameObject; // missing R in name lmao
                closeObject.transform.localPosition = new Vector3(84.702f, 50.0593f);

                var gradientImageObject = Background.Find("Scrollgradient").gameObject;
                UnityEngine.UI.Image gradientImage = gradientImageObject.GetComponent<UnityEngine.UI.Image>();
                gradientImage.enabled = false; // disable shadow for usual window

                var scrollRectObject = Background.Find("Scroll View").gameObject;
                scrollRectObject.transform.localPosition = new Vector3(5, -104, 0);
                scrollRectObject.transform.localScale = new Vector3(1.25f, 1.25f);
                ScrollRect scrollRect = scrollRectObject.GetComponent<ScrollRect>();
                scrollRect.vertical = true; // disable vertical drag of normal window content

                var viewPortObject = Background.Find("Scroll View").Find("Viewport").gameObject;
                RectTransform scrollRectTransform = viewPortObject.GetComponent<RectTransform>();
                scrollRectTransform.sizeDelta = new Vector3(0, -55);

                var name = inventoryWindow.transform.Find("Background").Find("Name").gameObject;
                var nameText = name.GetComponent<Text>();
                nameText.gameObject.SetActive(false);

                var Content = Background.Find("Scroll View").Find("Viewport").Find("Content");
                for (int i = 0; i < Content.transform.childCount; i++)
                {
                    GameObject.Destroy(Content.transform.GetChild(i).gameObject);
                }



                //ButtonResource resourceButton = NCMS.Utils.GameObjects.FindEvenInactive("ResourceElement").GetComponent<ButtonResource>();

                var rect = Content.GetComponent<RectTransform>();
                rect.pivot = new Vector2(0, 1);
                rect.sizeDelta = new Vector2(0, Mathf.Abs(GetPosByIndex(itemBank.resources.Count).y) + 100);

                var backgroundRect = Background.GetComponent<RectTransform>();
                //rect.pivot = new Vector2(0, 1);
                backgroundRect.sizeDelta = new Vector2(216, 405); // new Vector2(216, 265) original (long button)

                var resourcesList = controlledInventory.resources;
                int index = 0;
                foreach (KeyValuePair<string, int> p in resourcesList)
                {
                    string id = p.Key;
                    int amount = p.Value;
                    if (amount > 0)
                    {
                        ResourceAsset resourceAsset = AssetManager.resources.get(id);
                        loadResourceButton(id, index, amount, Content.transform, "inventory", resourceAsset);
                        index++;
                    }

                }
                //inventoryWindow.transform.position = new Vector3((Screen.width / 4), inventoryWindow.transform.position.y, inventoryWindow.transform.position.z);
                #endregion
                hasAddedWindowInventory = true;
                ShowWindow("survivor_inventory", null, "left", "left", true); // show window if it exists

                //invOpen = true;
            }
        }

        public static bool invOpen => ScrollWindow.currentWindows.Contains(NCMS.Utils.Windows.GetWindow("survivor_inventory"));
        public static bool bankOpen => ScrollWindow.currentWindows.Contains(NCMS.Utils.Windows.GetWindow("survivor_bank"));

        private static void bankResourceButtonCallBack(ResourceAsset resourceAsset)
        {
            UnityEngine.Debug.Log("bank resource clicked: " + resourceAsset.id);
            int bankAmount = itemBank.resources[resourceAsset.id];
            if (controlledInventory != null && invOpen)
            {
                int invAmount = controlledInventory.resources[resourceAsset.id];
                int transferAmount = 1;
                if (Input.GetKey(KeyCode.LeftShift))
                {
                    transferAmount = 5;
                }
                if (Input.GetKey(KeyCode.LeftControl))
                {
                    transferAmount = 50;
                    if (Input.GetKey(KeyCode.LeftShift))
                    {
                        transferAmount = bankAmount;
                    }
                }
                if (transferAmount > bankAmount)
                {
                    // prevent shift/control click not being able to transfer last bit
                    transferAmount = bankAmount;
                }

                if (bankAmount >= transferAmount)
                {
                    bankAmount -= transferAmount;
                    invAmount += transferAmount;
                    itemBank.resources[resourceAsset.id] = bankAmount;
                    controlledInventory.resources[resourceAsset.id] = invAmount;
                    // refresh windows with updated, could do it cleaner
                    OpenBankWindow();
                    if (invOpen)
                    {
                        OpenInventoryWindow();
                    }
                    saveBank();
                }
            }

            /*
            if(RPG_Main.controlledActor != null) {
                if(RPG_Main.controlledActor.haveTrait(trait.id)) {
                    int currentLevel = equippedUpgrades[trait.id];
                    equippedUpgrades[trait.id] = currentLevel + levelsPerUpgrade;
                }
                else {
                    RPG_Main.controlledActor.addTrait(trait.id);
                    equippedUpgrades.Add(trait.id, 1);
                }
            }
            */
            UnityEngine.Debug.Log("resource button finished");
        }

        private static void inventoryResourceButtonCallBack(ResourceAsset resourceAsset)
        {
            UnityEngine.Debug.Log("inventory resource clicked: " + resourceAsset.id);
            int bankAmount = itemBank.resources[resourceAsset.id];
            int invAmount = controlledInventory.resources[resourceAsset.id];


            if (bankOpen)
            {
                int transferAmount = 1;
                if (Input.GetKey(KeyCode.LeftShift))
                {
                    transferAmount = 5;
                }
                if (Input.GetKey(KeyCode.LeftControl))
                {
                    transferAmount = 50;
                    if (Input.GetKey(KeyCode.LeftShift))
                    {
                        transferAmount = invAmount;
                    }
                }
                if (transferAmount > invAmount)
                {
                    // prevent shift/control click not being able to transfer last bit
                    transferAmount = invAmount;
                }
                if (invAmount >= transferAmount)
                {
                    bankAmount += transferAmount;
                    invAmount -= transferAmount;
                    itemBank.resources[resourceAsset.id] = bankAmount;
                    controlledInventory.resources[resourceAsset.id] = invAmount;
                    // refresh windows with updated, could do it cleaner
                    OpenInventoryWindow();
                    OpenBankWindow();
                }
                saveBank();
            }

            else
            { // bank is closed, likely meaning to interact with items
                if (resourceAsset.id == "cake")
                {
                    // eat da cake, lol
                }
            }
            /*
            if(RPG_Main.controlledActor != null) {
                if(RPG_Main.controlledActor.haveTrait(trait.id)) {
                    int currentLevel = equippedUpgrades[trait.id];
                    equippedUpgrades[trait.id] = currentLevel + levelsPerUpgrade;
                }
                else {
                    RPG_Main.controlledActor.addTrait(trait.id);
                    equippedUpgrades.Add(trait.id, 1);
                }
            }
            */
            UnityEngine.Debug.Log("resource button finished");
        }
        public static int uniqueIndex = 0;
        private static void loadResourceButton(string pID, int pIndex, int pTotal, Transform parent, string windowID, ResourceAsset resourceAsset)
        {

            Sprite sprite = resourceAsset.getSprite();

            string tooltipText = FirstCharToUpper(pID) + ": " + pTotal;
            PowerButton elementButton = NCMS.Utils.PowerButtons.CreateButton("resource_" + pID + "_" + uniqueIndex, sprite, tooltipText, "", Vector2.zero, ButtonType.Click, parent, delegate
            {
                if (windowID == "bank")
                {
                    bankResourceButtonCallBack(resourceAsset);
                }
                if (windowID == "inventory")
                {
                    inventoryResourceButtonCallBack(resourceAsset);
                }
            });
            uniqueIndex++;
            elementButton.transform.localPosition = GetPosByIndex(pIndex); // set button in right spot

            //elementButton.click // divider for before/after
            /*
            ButtonResource resourceButton = GameObject.Instantiate<ButtonResource>(resourceButtonPref, parent);
            resourceButton.load(resourceAsset, itemBank.resources[pID]);

            resourceButton.transform.localPosition = GetPosByIndex(pIndex); // set button in right spot


            var button = resourceButton.gameObject.GetComponent<UnityEngine.UI.Button>();
            resourceButton.textAmount.text = pTotal.ToString();
            button.onClick.AddListener(() => callback(resourceButton));
            */

        }

        private static Vector2 GetPosByIndex(int index)
        {
            float x = (index % countInRow) * XStep + startXPos;
            float y = (Mathf.RoundToInt(index / countInRow) * YStep) + startYPos;

            return new Vector2(x, y);
        }


        private static float startXPos = 60f; // do something based on upgrade list/used ones
        private static int countInRow => 5; //itemBank.resources.Count;
        private static float startYPos = -22.5f;
        private static float YStep = -32.5f; // was 28.5f
        private static float XStep = 32.5f; // 65 for 3, 34 for 5

        public static string FirstCharToUpper(string input)
        {
            if (String.IsNullOrEmpty(input))
                throw new ArgumentException("ARGH!");
            return input.First().ToString().ToUpper() + String.Join("", input.Skip(1));
        }

        public static ModSettings settings;

        //initial setup and loading
        public void SettingSetup()
        {
            UnityEngine.Debug.Log("Settings start");
            //copied and only slightly changed from igniz's traitbonanza
            string path = Path.Combine(Application.streamingAssetsPath, "Mods");
            string text = Path.Combine(path, pluginGuid + ".json");
            bool flag = Application.platform == RuntimePlatform.WindowsPlayer;
            if (flag)
            {
                text = text.Replace("\\", "/");
            }

            bool fileExist = File.Exists(text);
            if (fileExist)
            {
                string value = File.ReadAllText(text);
                settings = JsonConvert.DeserializeObject<ModSettings>(value);
                UnityEngine.Debug.Log("loaded saved settings");
            }
            else
            {//file doesnt exist, setup defaults
                settings = new ModSettings();
                string text2 = JsonConvert.SerializeObject(settings, Formatting.Indented);
                UnityEngine.Debug.Log("created and saved default");
                File.WriteAllText(text, text2);
            }
            UnityEngine.Debug.Log("Settings end");
            // why do i do all of this with strings? //for menu input/display??
            expGainedOnKill = settings.expGainOnKill.ToString();
            kingExpInput = settings.kingAgeExp.ToString();
            leaderExpInput = settings.leaderAgeExp.ToString();
            otherExpInput = settings.otherAgeExp.ToString();
            expToLevel = settings.baseExpToLevelup.ToString();
            expScale = settings.expToLevelUpScale.ToString();
        }
        //standalone methods for calling later if needed
        public void saveSettings()
        {
            string path = Path.Combine(Application.streamingAssetsPath, "Mods");
            string text = Path.Combine(path, pluginGuid + ".json");
            string text2 = JsonConvert.SerializeObject(settings, Formatting.Indented);
            UnityEngine.Debug.Log("saved settings");
            File.WriteAllText(text, text2);
        }
        public void loadSettings()
        {
            string path = Path.Combine(Application.streamingAssetsPath, "Mods");
            string text = Path.Combine(path, pluginGuid + ".json");
            string value = File.ReadAllText(text);
            settings = JsonConvert.DeserializeObject<ModSettings>(value);
            UnityEngine.Debug.Log("loaded settings");
        }

        //public static int expGainOnKill = 10;
        //public static int kingAgeExp = 20;
        //public static int leaderAgeExp = 10;
        //public static int otherAgeExp = 2;
        //public static int baseExpToLevelup = 100; 
        // default: 100 + (this.data.level - 1) * 20;
        //public static int expToLevelUpScale = 20;

        public static bool updateAge_Prefix(Actor __instance)
        {
            ActorStatus data = __instance.data;
            int currentAge = data.age;
            Race race = __instance.race;
            bool updateAge = data.updateAge(race);
            if (!updateAge && !__instance.haveTrait("immortal"))
            {
                __instance.killHimself(false, AttackType.Age, true, true);
                return false;
            }
            int currentAge2 = data.age;
            //UnityEngine.Debug.Log("\nUnityEngine.Debug: old age: " + currentAge + "\n" + "UnityEngine.Debug: new age: " + currentAge2);
            if (__instance.city != null)
            {
                Kingdom kingdom = __instance.city.kingdom;
                if (kingdom != null)
                {
                    if (kingdom.king == __instance)
                    {
                        __instance.addExperience(settings.kingAgeExp);
                    }
                }
                if (__instance.city.leader == __instance)
                {
                    __instance.addExperience(settings.leaderAgeExp);
                }
                if (
                    (kingdom == null || (kingdom != null && kingdom.king != __instance))
                    &&
                    (__instance.city == null || (__instance.city != null && __instance.city.leader != __instance))
                    )
                {
                    __instance.addExperience(settings.otherAgeExp);
                }
            }
            if (data.age > 40 && Toolbox.randomChance(0.3f))
            {
                __instance.addTrait("wise");
            }
            return false;
        }

        public static bool stopMovement_Prefix(ActorBase __instance) // stop controlled actor canceling movement from AI behaviour
        {
            if ((controlledActor != null && __instance == controlledActor) || totalSquadActorList.Contains(__instance))
            {
                if (directionMoving != null)
                {
                    return false;
                }
            }
            return true;
        }

        public static void BasicMoveAndWait(Actor targetActor, WorldTile targetTile)
        {
            // simple way of making an actor move the way i want
            if (targetActor == null || controlledActor == null) return;
            if (targetActor == controlledActor)
            {
                targetActor.moveTo(targetTile);
            }
            else
            {
                targetActor.moveTo(targetTile); // i want ai to use goto, but they dont stand still after moving
            }
            if (useFlashOnMove)
                flashEffects.flashPixel(targetTile, 10, ColorType.White);
            AiSystemActor actorAI = targetActor.ai;
            actorAI.setTask("wait10", false, true);
        }

        // for moving monsters/non-squad
        public static void aiMoveAndWait(Actor targetActor, WorldTile targetTile)
        {
            if (controlledActor != targetActor)
            {
                // simple way of making an actor move the way i want

                List<WorldTile> usedTiles = Survivor.usedTiles;
                WorldTile actualTileTarget = targetTile;

                if (usedTiles.Contains(targetTile))
                {
                    while (usedTiles.Contains(actualTileTarget))
                    { // if current target is used
                        actualTileTarget = actualTileTarget.neighboursAll.GetRandom(); // keep finding random neighbor to try
                    }
                }
                targetActor.goTo(actualTileTarget, true, false);// moveTo(actualTileTarget); //
                Survivor.usedTiles.Add(actualTileTarget);
                if (useFlashOnMove)
                {
                    //flashEffects.flashPixel(actualTileTarget, 10, ColorType.White);
                }
                AiSystemActor actorAI = targetActor.ai;
                actorAI.setTask("wait10", false, true);
            }

        }

        public static void SetWindowInUse(int windowID)
        {
            Event current = Event.current;
            bool inUse = current.type == EventType.MouseDown || current.type == EventType.MouseUp || current.type == EventType.MouseDrag || current.type == EventType.MouseMove;
            if (inUse)
            {
                windowInUse = windowID;
            }
        }

        // click-through prevention for menus
        public static void isActionHappening_Postfix(ref bool __result)
        {
            if (windowInUse != -1)
            {
                __result = true; // "menu in use" is the action happening
            }
        }

        // cancel all control input if a window is in use
        public static bool updateControls_Prefix()
        {
            if (windowInUse != -1)
            {
                return false;
            }
            return true;
        }

        // cancel empty click usage when windows in use, unused right now
        public static bool checkEmptyClick_Prefix()
        {
            if (windowInUse != -1)
            {
                return false;
            }
            return true;
        }

        public WorldTile MouseTile => MapBox.instance.getMouseTilePos();

        public static string directionMoving = null;

        public static Actor controlledActor = null;
        public static Boat controlledBoat = null;
        public static WorldTile lastTile = null;

        public static int windowInUse = 0;

        public static PlayerInventory controlledInventory; // currently controlled actor's custom inventory

        public static int totalCountOfResources(Dictionary<string, int> resources)
        {
            int total = 0;
            foreach (KeyValuePair<string, int> resource in resources)
            {
                total += resource.Value;
            }
            return total;
        }
    }



    public class PlayerInventory
    {
        public int totalCountOfAllResources => RPG_Main.totalCountOfResources(resources);
        public Dictionary<string, int> resources = new Dictionary<string, int>(){
            {"wood", 0},
            {"stone", 0},
            {"ore", 0},
            {"silver", 0},
            {"gold", 0},
            {"mythril", 0},
            {"metals", 0},
            {"bones", 0},
            {"leather", 0},
            {"gems", 0},
            {"adamantine", 0},
            {"dragon_scales", 0},
            {"bananas", 0},
            {"coconut", 0},
            {"lemons", 0},
            {"desert_berries", 0},
            {"crystal_salt", 0},
            {"evil_beets", 0},
            {"mushrooms", 0},
            {"peppers", 0},
            {"herbs", 0},
            {"bread", 0},
            {"fish", 0},
            {"candy", 0},
            {"meat", 0},
            {"sushi", 0},
            {"jam", 0},
            {"cider", 0},
            {"ale", 0},
            {"burger", 0},
            {"pie", 0},
            {"tea", 0},
            {"honey", 0},
            {"berries", 0},
            {"wheat", 0},
            {"eggs", 0},
            {"milk", 0},
            {"dirt", 0},
            {"sand", 0},
            {"cake", 0},
            {"CrabCoin", 0}
        };
    }

    [JsonObject(MemberSerialization.OptIn)]
    public class ModSettings
    {
        // excluded from serialization
        // does not have JsonPropertyAttribute
        public Guid Id { get; set; }

        [JsonProperty]
        public string Name = "test";

        [JsonProperty]
        public int Size = 10;

        [JsonProperty]
        public int expGainOnKill = 10;

        [JsonProperty]
        public int kingAgeExp = 20;

        [JsonProperty]
        public int leaderAgeExp = 10;

        [JsonProperty]
        public int otherAgeExp = 2;

        [JsonProperty]
        public int baseExpToLevelup = 100;
        // default: 100 + (this.data.level - 1) * 20;

        [JsonProperty]
        public int expToLevelUpScale = 20;

        [JsonProperty]
        public bool hasCreatedHome = false;
    }

    public class UnitClipboard_Main
    {
        public Actor PasteUnit(WorldTile targetTile, UnitData unitData)
        {
            if (targetTile != null && unitData != null)
            {
                Actor pastedUnit = MapBox.instance.createNewUnit(unitData.statsID, targetTile, null, 0f, null);
                ActorStatus data = Reflection.GetField(pastedUnit.GetType(), pastedUnit, "data") as ActorStatus;
                data.level = unitData.level;
                data.experience = unitData.exp;
                data.firstName = unitData.dataFirstName;
                data.statsID = unitData.statsID;
                data.age = unitData.age;
                data.intelligence = unitData.intelligence;
                data.children = unitData.children;
                data.actorID = unitData.actorID;
                data.kills = unitData.kills;
                data.health = unitData.health;
                data.hunger = unitData.hunger;
                data.culture = unitData.culture;
                data.profession = unitData.profession;
                data.skin = unitData.skin;
                data.gender = unitData.gender;
                data.warfare = unitData.warfare;
                data.stewardship = unitData.stewardship;
                data.diplomacy = unitData.diplomacy;
                pastedUnit.city = unitData.city;
                pastedUnit.kingdom = unitData.kingdom;
                pastedUnit.equipment.weapon.setItem(unitData.weaponData);
                pastedUnit.equipment.armor.setItem(unitData.armorData);
                pastedUnit.equipment.helmet.setItem(unitData.helmetData);
                pastedUnit.equipment.boots.setItem(unitData.bootsData);
                pastedUnit.equipment.amulet.setItem(unitData.amuletData);
                pastedUnit.equipment.ring.setItem(unitData.ringData);

                if (data.traits != null && data.traits.Count >= 1)
                {
                    pastedUnit.data.traits.Clear(); // might not work
                }
                //if (unitData.equipment != null)
                //{
                //    pastedUnit.equipment = unitData.equipment;
                //}

                ActorTrait pasted = new ActorTrait();
                pasted.id = selectedUnitToPaste.dataFirstName.Replace("pasted ", ""); // might need to change to be unique
                foreach (string trait in unitData.traits)
                {
                    pastedUnit.addTrait(trait);
                }
                pastedUnit.setProfession(unitData.profession);
                pastedUnit.restoreHealth(10 ^ 9); //lazy
                return pastedUnit;
                //UnityEngine.Debug.Log("Pasted " + unitData.dataFirstName);
            }
            return null;
        }
        public static bool showHideMainWindow;
        public static Rect mainWindowRect = new Rect(0f, 1f, 1f, 1f);

        public void OnGUI()
        {
            GUILayout.BeginArea(new Rect(Screen.width - 120, 25, 120, 30));
            //if(GUILayout.Button("UnitClipboard")) { showHideMainWindow = !showHideMainWindow; }
            GUILayout.EndArea();
            if (showHideMainWindow)
            {
                mainWindowRect = GUILayout.Window(500401, mainWindowRect, new GUI.WindowFunction(UnitClipboardWindow), "Unit Clipboard", new GUILayoutOption[] { GUILayout.MaxWidth(300f), GUILayout.MinWidth(200f) });
            }
        }

        public static Actor ClosestActorToTile(WorldTile pTarget, float range)
        {
            Actor returnActor = null;
            foreach (Actor actorToCheck in MapBox.instance.units)
            {
                float actorDistanceFromTile = Toolbox.Dist(actorToCheck.currentPosition.x, actorToCheck.currentPosition.y, (float)pTarget.pos.x, (float)pTarget.pos.y);
                if (actorDistanceFromTile < range)
                {
                    range = actorDistanceFromTile;
                    returnActor = actorToCheck;
                }
            }
            return returnActor;
        }


        public Dictionary<string, UnitData> unitClipboardDict = new Dictionary<string, UnitData>(); // id, data

        public void UnitClipboardWindow(int windowID)
        {
            if (unitClipboardDict.Count >= 1)
            {
                for (int i = 0; i < unitClipboardDict.Count(); i++)
                {
                    GUILayout.BeginHorizontal();
                    if (GUILayout.Button(unitClipboardDict[i.ToString()].dataFirstName))
                    {
                        selectedUnitToPaste = unitClipboardDict[i.ToString()];
                    }
                    GUILayout.EndHorizontal();
                }
            }
            GUI.DragWindow();
        }

        public void CopyUnit(Actor targetActor)
        {
            if (targetActor != null)
            {
                ActorStatus data = Reflection.GetField(targetActor.GetType(), targetActor, "data") as ActorStatus;
                BaseStats curStats = Reflection.GetField(targetActor.GetType(), targetActor, "curStats") as BaseStats;
                UnitData newSavedUnit = new UnitData();
                foreach (string trait in data.traits)
                {
                    newSavedUnit.traits.Add(trait);
                }
                newSavedUnit.dataFirstName = data.firstName;
                newSavedUnit.statsID = data.statsID;
                newSavedUnit.level = data.level;
                newSavedUnit.exp = data.experience;
                newSavedUnit.age = data.age;
                newSavedUnit.intelligence = data.intelligence;
                newSavedUnit.children = data.children;
                newSavedUnit.actorID = data.actorID;
                newSavedUnit.kills = data.kills;
                newSavedUnit.health = data.health;
                newSavedUnit.hunger = data.hunger;
                newSavedUnit.culture = data.culture;
                newSavedUnit.profession = data.profession;
                newSavedUnit.skin = data.skin;
                newSavedUnit.gender = data.gender;
                newSavedUnit.kingdom = targetActor.kingdom;
                newSavedUnit.city = targetActor.city;
                newSavedUnit.warfare = data.warfare;
                newSavedUnit.stewardship = data.stewardship;
                newSavedUnit.diplomacy = data.diplomacy;
                newSavedUnit.weaponData = targetActor.equipment.weapon.data;
                newSavedUnit.armorData = targetActor.equipment.armor.data;
                newSavedUnit.helmetData = targetActor.equipment.helmet.data;
                newSavedUnit.bootsData = targetActor.equipment.boots.data;
                newSavedUnit.amuletData = targetActor.equipment.amulet.data;
                newSavedUnit.ringData = targetActor.equipment.ring.data;

                unitClipboardDict.Add(unitClipboardDictNum.ToString(), newSavedUnit);
                unitClipboardDictNum++;
                selectedUnitToPaste = newSavedUnit;
                UnityEngine.Debug.Log("Copied " + newSavedUnit.dataFirstName);
            }
        }

        int unitClipboardDictNum = 0;

        public UnitData selectedUnitToPaste;

        public class UnitData
        {
            public string dataFirstName = "";
            public int level;
            public int exp;
            public int age;
            public int intelligence;
            public int children;
            public int kills;
            public int health;
            public int hunger;
            public int skin;
            public int warfare;
            public int stewardship;
            public int diplomacy;
            public string culture;
            public string actorID;
            public string statsID = "";
            public City city;
            public Kingdom kingdom;
            public ActorGender gender;
            public UnitProfession profession;
            public List<string> traits = new List<string>();
            public ItemData weaponData;
            public ItemData armorData;
            public ItemData helmetData;
            public ItemData bootsData;
            public ItemData amuletData;
            public ItemData ringData;
        }
    }




    [JsonObject(MemberSerialization.OptIn)]
    public class ItemBank
    {
        [JsonProperty]
        public string message = "pls dont cheat :)";

        [JsonProperty]
        public Dictionary<string, int> resources = new Dictionary<string, int>(){
            {"wood", 0},
            {"stone", 0},
            {"commonMetal", 0},
            {"silver", 0},
            {"gold", 0},
            {"mythril", 0},
            {"metals", 0},
            {"bones", 0},
            {"leather", 0},
            {"gems", 0},
            {"adamantine", 0},
            {"dragon_scales", 0},
            {"bananas", 0},
            {"coconut", 0},
            {"lemons", 0},
            {"desert_berries", 0},
            {"crystal_salt", 0},
            {"evil_beets", 0},
            {"mushrooms", 0},
            {"peppers", 0},
            {"herbs", 0},
            {"bread", 0},
            {"fish", 0},
            {"candy", 0},
            {"meat", 0},
            {"sushi", 0},
            {"jam", 0},
            {"cider", 0},
            {"ale", 0},
            {"burger", 0},
            {"pie", 0},
            {"tea", 0},
            {"honey", 0},
            {"berries", 0},
            {"wheat", 0},
            {"eggs", 0},
            {"milk", 0},
            {"dirt", 0},
            {"sand", 0},
            {"cake", 0},
            {"CrabCoin", 0}
        };
    }
}
