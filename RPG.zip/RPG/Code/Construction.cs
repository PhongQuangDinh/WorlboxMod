﻿using System.Diagnostics;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using NCMS;
using NCMS.Utils;
using HarmonyLib;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UIElements;
using static UnityEngine.GraphicsBuffer;
using ai;
using RPG;
using UnityEngine.EventSystems;
namespace RPG
{
    public class GUIConstruction
    {

        public void UndoLastInList()
        {
            if (lastConstructedBuildings.Count > 0)
            {
                Building buildingToKill = lastConstructedBuildings.Last();
                buildingToKill.destroyBuilding();
            }

        }

        public static List<Building> lastConstructedBuildings = new List<Building>();

        public string buildingAssetName()
        {
            if (selectedBuildingAsset == null)
            {
                if (placingRoad)
                {
                    return "road";
                }
                if (placingField)
                {
                    return "field";
                }
                return "none";
            }
            return selectedBuildingAsset.id;
        }
        public static void ResetForSurvivor()
        {
            placingField = false;
            placingRoad = false;
            placingToggleEnabled = false;
            showHideConstruction = false;
        }
        public void constructionControl()
        {
            if (RPG.RPG_Main.windowInUse == 1007) return;
            if (Input.GetMouseButtonDown(0))
            {
                if (placingToggleEnabled && !placedOnce)
                {
                    CreateBuilding();
                    if (placingField || placingRoad)
                    {
                        return;
                    }
                    if (Input.GetKey(KeyCode.LeftControl))
                    {
                        // prevent building stopping if holding control
                    }
                    else
                    {
                        placedOnce = true;
                    }
                }
            }
            if (Input.GetMouseButtonUp(0))
            {
                if (placedOnce)
                {
                    if (Input.GetKey(KeyCode.LeftControl))
                    {
                        // prevent building stopping if holding control
                    }
                    else
                    {
                        placingToggleEnabled = false;
                        selectedBuildingAsset = null;
                        placedOnce = false;
                    }
                }
            }

            if (Input.GetKeyDown(KeyCode.Z))
            {
                UndoLastInList();
            }
        }
        public bool placedOnce;
        public void SetBuilding(string buildingName)
        {
            // Just in case
            if (AssetManager.buildings.get(buildingName) != null)
            {
                selectedBuildingAsset = AssetManager.buildings.get(buildingName);
                UnityEngine.Debug.Log("Force changed selected construction");
            }
        }
        public void createRoad(WorldTile pTile)
        {
            MapAction.createRoadTile(pTile);
        }

        public static bool startDestroyBuilding_Prefix(bool pRemove = false)
        {
            if (placingRoad || placingField)
            {
                if (Input.GetMouseButton(0))
                {
                    return false;
                }
            }
            return true;
        }

        //prevent walls from despawning maybe
        public static void canBuildOn_Postfix(BuildingAsset pNewTemplate, ref bool __result)
        {
            if (pNewTemplate.id.Contains("wall1"))
            {
                __result = true;
            }
            if (pNewTemplate.id.Contains("road") || pNewTemplate.id.Contains("field"))
            {
                __result = false;
            }
        }

        public static bool destroyBuilding_Prefix(bool pRemove, Building __instance)
        {
            if (__instance.stats.id.Contains("wall1"))
            {
                WorldTile tile = __instance.currentTile;
                BuildingAsset constructionTemplate = __instance.stats;
                int num = tile.x - constructionTemplate.fundament.left;
                int num2 = tile.y - constructionTemplate.fundament.bottom;
                int num3 = constructionTemplate.fundament.right + constructionTemplate.fundament.left + 1;
                int num4 = constructionTemplate.fundament.top + constructionTemplate.fundament.bottom + 1;

                for (int j = 0; j < num3; j++)
                {
                    for (int k = 0; k < num4; k++)
                    {
                        WorldTile tile2 = MapBox.instance.GetTile(num + j, num2 + k);
                        if (tile2 != null)
                        {
                            MapAction.terraformTop(tile2, null);
                        }
                    }
                }
                return true;
            }
            return true;
        }

        public static Dictionary<string, Dictionary<string, int>> extraResourceCosts = new Dictionary<string, Dictionary<string, int>>();

        public void CreateBuilding()
        {
            if (placingRoad)
            {
                bool hasDirt = false;
                // dirt cost for roads
                if ((RPG_Main.controlledInventory.resources["dirt"] > 0) == false) { WorldTip.instance.show("Missing dirt", false, "mouse", 5); }
                else { hasDirt = true; }
                if (hasDirt)
                {
                    RPG_Main.controlledInventory.resources["dirt"]--;
                    createRoad(MapBox.instance.getMouseTilePos());
                }
            }
            else if (placingField)
            {
                bool hasDirt = false;
                // dirt cost for roads
                if ((RPG_Main.controlledInventory.resources["dirt"] > 0) == false) { WorldTip.instance.show("Missing dirt", false, "mouse", 5); }
                else { hasDirt = true; }
                if (hasDirt)
                {
                    RPG_Main.controlledInventory.resources["dirt"]--;
                    MapAction.terraformTop(MapBox.instance.getMouseTilePos(), TopTileLibrary.field, AssetManager.terraform.get("flash"));
                }
            }
            else
            {
                if (MapBox.instance.getMouseTilePos() != null)
                {
                    WorldTile tile = MapBox.instance.getMouseTilePos();



                    if (selectedBuildingAsset != null)
                    {

                        if (selectedBuildingAssetName.Contains("woodfloor")) // tile replacing building
                        {
                            MapAction.terraformTop(MapBox.instance.getMouseTilePos(), AssetManager.topTiles.get(selectedBuildingAssetName), AssetManager.terraform.get("flash"));
                        }
                        else
                        {
                            BuildingAsset buildingAsset = selectedBuildingAsset;
                            bool canBuild = false;

                            if (RPG_Main.controlledInventory != null)
                            {
                                if (buildingAsset.cost != null)
                                {
                                    // need a way to use other resources
                                    bool hasEnoughWood = false;
                                    bool hasEnoughStone = false;
                                    bool hasEnoughMetal = false;
                                    bool hasEnoughGold = false;

                                    if (buildingAsset.cost.wood > RPG_Main.controlledInventory.resources["wood"]) { WorldTip.instance.show("Missing wood: " + (buildingAsset.cost.wood - RPG_Main.controlledInventory.resources["wood"]), false, "mouse", 5); }
                                    else { hasEnoughWood = true; }
                                    if (buildingAsset.cost.stone > RPG_Main.controlledInventory.resources["stone"]) { WorldTip.instance.show("Missing stone: " + (buildingAsset.cost.stone - RPG_Main.controlledInventory.resources["stone"]), false, "mouse", 5); }
                                    else { hasEnoughStone = true; }
                                    if (buildingAsset.cost.common_metals > RPG_Main.controlledInventory.resources["ore"]) { WorldTip.instance.show("Missing ore: " + (buildingAsset.cost.common_metals - RPG_Main.controlledInventory.resources["ore"]), false, "mouse", 5); }
                                    else { hasEnoughMetal = true; }
                                    if (buildingAsset.cost.gold > RPG_Main.controlledInventory.resources["gold"]) { WorldTip.instance.show("Missing gold: " + (buildingAsset.cost.gold - RPG_Main.controlledInventory.resources["gold"]), false, "mouse", 5); }
                                    else { hasEnoughGold = true; }

                                    if (hasEnoughGold && hasEnoughMetal && hasEnoughStone && hasEnoughWood)
                                    {
                                        RPG_Main.controlledInventory.resources["wood"] -= buildingAsset.cost.wood;
                                        RPG_Main.controlledInventory.resources["stone"] -= buildingAsset.cost.stone;
                                        RPG_Main.controlledInventory.resources["ore"] -= buildingAsset.cost.common_metals;
                                        RPG_Main.controlledInventory.resources["gold"] -= buildingAsset.cost.gold;
                                        canBuild = true;
                                    }
                                }
                                else
                                {
                                    // no building cost found, automatically can build
                                    canBuild = true;
                                }
                                // sloppy, check extra resources after all the old checks
                                if (extraResourceCosts.ContainsKey(buildingAsset.id))
                                {
                                    foreach (KeyValuePair<string, int> resource in extraResourceCosts[buildingAsset.id])
                                    {
                                        if (RPG_Main.controlledInventory.resources[resource.Key] < resource.Value)
                                        {
                                            WorldTip.instance.show("Missing " + resource.Key + ": " + (resource.Value - RPG_Main.controlledInventory.resources[resource.Key]), false, "mouse", 5);
                                            canBuild = false;
                                        }
                                    }
                                }
                                if (canBuild)
                                {
                                    if (buildingAsset.id.Contains("wall1"))
                                    {
                                        BuildingAsset constructionTemplate = selectedBuildingAsset;
                                        int num = tile.x - constructionTemplate.fundament.left;
                                        int num2 = tile.y - constructionTemplate.fundament.bottom;
                                        int num3 = constructionTemplate.fundament.right + constructionTemplate.fundament.left + 1;
                                        int num4 = constructionTemplate.fundament.top + constructionTemplate.fundament.bottom + 1;
                                        PixelFlashEffects flashEffects = MapBox.instance.flashEffects; //Reflection.GetField(MapBox.instance.GetType(), MapBox.instance, "flashEffects") as PixelFlashEffects;

                                        for (int j = 0; j < num3; j++)
                                        {
                                            for (int k = 0; k < num4; k++)
                                            {
                                                WorldTile tile2 = MapBox.instance.GetTile(num + j, num2 + k);
                                                if (tile2 != null)
                                                { // disabling mountains on tiles for now?
                                                    MapAction.terraformMain(tile2, AssetManager.tiles.get("mountains"), AssetManager.terraform.get("flash"));
                                                }
                                            }
                                        }
                                    }
                                    if (buildingAsset.id.Contains("road"))
                                    {

                                    }
                                    Building building = MapBox.instance.addBuilding(selectedBuildingAssetName, MapBox.instance.getMouseTilePos(), null, false, true, BuildPlacingType.New); //CallMethod("addBuilding", new object[] { selectedBuildingAssetName, MapBox.instance.getMouseTilePos(), null, false, true, BuildPlacingType.New }) as Building;
                                    building.setKingdom(MapBox.instance.kingdoms.getKingdomByID(buildingAsset.kingdom));
                                    //building.updateBuild(100);
                                    // why is building instant??
                                    WorldTile currentTile = building.currentTile; //Reflection.GetField(building.GetType(), building, "currentTile") as WorldTile;

                                    if (currentTile.zone.city != null)
                                    {
                                        building.setCity(currentTile.zone.city, false); //CallMethod("setCity", new object[] { currentTile.zone.city, false });
                                    }
                                    if (building.city != null)
                                    {
                                        building.city.addBuilding(building);
                                        building.city.status.housesMax += selectedBuildingAsset.housing * (selectedBuildingAsset.upgradeLevel + 1);
                                        if (building.city.status.population > building.city.status.housesMax)
                                        {
                                            building.city.status.housingOccupied = building.city.status.housesMax;
                                        }
                                        else
                                        {
                                            building.city.status.housingOccupied = building.city.status.population;
                                        }
                                        building.city.status.housingFree = building.city.status.housingTotal - building.city.status.housingOccupied;
                                    }

                                    lastConstructedBuildings.Add(building);
                                }
                            }
                        }



                    }


                }
                else
                {
                    // display error for out of map tile?
                }
            }
        }

        public void ControlsUpdate()
        {
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                if (placingToggleEnabled || placingField || placingRoad)
                {
                    placingField = false;
                    placingRoad = false;
                    placingToggleEnabled = false;
                    selectedBuildingAsset = null;
                }
            }
        }

        public void constructionPreviewUpdate()
        {
            if (placingRoad || placingField)
            {
                if (MapBox.instance.getMouseTilePos() != null)
                {
                    PixelFlashEffects flashEffects = MapBox.instance.flashEffects; //Reflection.GetField(MapBox.instance.GetType(), MapBox.instance, "flashEffects") as PixelFlashEffects;
                    flashEffects.flashPixel(MapBox.instance.getMouseTilePos(), 10, ColorType.White);
                }
            }
            else // placing buildings
            {

                if (selectedBuildingAsset != null && MapBox.instance.getMouseTilePos() != null)
                {
                    // Building construction
                    BuildingAsset constructionTemplate = selectedBuildingAsset;
                    int num = MapBox.instance.getMouseTilePos().x - constructionTemplate.fundament.left;
                    int num2 = MapBox.instance.getMouseTilePos().y - constructionTemplate.fundament.bottom;
                    int num3 = constructionTemplate.fundament.right + constructionTemplate.fundament.left + 1;
                    int num4 = constructionTemplate.fundament.top + constructionTemplate.fundament.bottom + 1;
                    PixelFlashEffects flashEffects = MapBox.instance.flashEffects; //Reflection.GetField(MapBox.instance.GetType(), MapBox.instance, "flashEffects") as PixelFlashEffects;

                    for (int j = 0; j < num3; j++)
                    {
                        for (int k = 0; k < num4; k++)
                        {
                            WorldTile tile = MapBox.instance.GetTile(num + j, num2 + k);
                            if (tile != null)
                            {
                                flashEffects.flashPixel(tile, 10, ColorType.White);
                            }
                        }
                    }
                    // constructionControl();
                }
            }

        }
        //copied and edited from ncms directly
        public static void ShowWindow(string windowId, ScrollWindow pWindowFrom = null, string pDistPosition = "right", string pStartPosition = "right", bool pSkipAnimation = false)
        {
            bool flag = Windows.AllWindows.ContainsKey(windowId) && !ScrollWindow.currentWindows.Contains(Windows.GetWindow(windowId));
            if (flag)
            {
                Windows.AllWindows[windowId].show(pWindowFrom, pDistPosition, pStartPosition, pSkipAnimation);
            }
        }
        public static bool hasAddedConstructionWindow;

        public static int cachedInventoryResourceCount;

        public static void OpenConstructionWindow()
        {
            //Config.paused = true;
            #region constructionWindow
            //UnityEngine.Debug.Log("opening Construction window");
            if (hasAddedConstructionWindow == true)
            {
                if (cachedInventoryResourceCount != RPG_Main.controlledInventory.totalCountOfAllResources)
                {
                    // resource count has changed, rebuild menu so costs update
                    ShowWindow("survivor_construction", null, "right", "right", true); // show window if it exists
                    var constructionWindow = NCMS.Utils.Windows.GetWindow("survivor_construction");
                    Transform Background = constructionWindow.transform.Find("Background");
                    var Content = Background.Find("Scroll View").Find("Viewport").Find("Content");
                    for (int i = 0; i < Content.transform.childCount; i++)
                    {
                        GameObject.Destroy(Content.transform.GetChild(i).gameObject);
                    }
                    var rect = Content.GetComponent<RectTransform>();
                    rect.pivot = new Vector2(0, 1);
                    int count = AssetManager.buildings.list.Count;
                    rect.sizeDelta = new Vector2(0, Mathf.Abs(GetPosByIndex(count).y) + 100);
                    var backgroundRect = Background.GetComponent<RectTransform>();
                    //rect.pivot = new Vector2(0, 1);
                    backgroundRect.sizeDelta = new Vector2(216, 405); // new Vector2(216, 265) original (long button)

                    var resourcesList = AssetManager.buildings.list;
                    int index = 0;
                    for (int i = 0; i < resourcesList.Count; i++)
                    {
                        string id = resourcesList[i].id;
                        if (id.Contains("!"))
                        {

                        }
                        else
                        {
                            loadResourceButton(resourcesList[i].id, index, Content.transform, "construction", resourcesList[i]);
                            index++;
                        }
                    }
                    cachedInventoryResourceCount = RPG_Main.controlledInventory.totalCountOfAllResources;
                }
                else
                {
                    //resource count has not changed, only show window without rebuilding
                    ShowWindow("survivor_construction", null, "right", "right", true); // show window if it exists
                }

                //bankOpen = true;
            }
            else
            { // create window from scratch
                var constructionWindow = NCMS.Utils.Windows.CreateNewWindow("survivor_construction", "Construction");

                #region var description

                //string hlColor = "#65BD00FF";

                //var description = "hi";
                #endregion
                //
                constructionWindow.transform.Find("Background").Find("Scroll View").gameObject.SetActive(true);

                //ActorTrait upgradableTrait = AssetManager.traits.get(upgradeList.GetRandom());
                //Sprite traitSprite = (Sprite)Resources.Load("ui/Icons/" + upgradableTrait.path_icon, typeof(Sprite));

                Transform Background = constructionWindow.transform.Find("Background");

                UnityEngine.UI.Image backGroundImage = Background.GetComponent<UnityEngine.UI.Image>();
                Background.transform.localScale = new Vector3(0.75f, 0.75f);
                Sprite newsprite = (Sprite)Resources.Load("ui/buttonBig", typeof(Sprite)); // load new window background (simple button)
                backGroundImage.sprite = newsprite;

                var closeObject = Background.Find("CloseBackgound").gameObject; // missing R in name lmao
                closeObject.transform.localPosition = new Vector3(84.702f, 50.0593f);

                var gradientImageObject = Background.Find("Scrollgradient").gameObject;
                UnityEngine.UI.Image gradientImage = gradientImageObject.GetComponent<UnityEngine.UI.Image>();
                gradientImage.enabled = false; // disable shadow for usual window

                var scrollRectObject = Background.Find("Scroll View").gameObject;
                scrollRectObject.transform.localPosition = new Vector3(5, -104, 0);
                scrollRectObject.transform.localScale = new Vector3(1.25f, 1.25f);
                ScrollRect scrollRect = scrollRectObject.GetComponent<ScrollRect>();
                scrollRect.vertical = true; // disable vertical drag of normal window content

                var viewPortObject = Background.Find("Scroll View").Find("Viewport").gameObject;
                RectTransform scrollRectTransform = viewPortObject.GetComponent<RectTransform>();
                scrollRectTransform.sizeDelta = new Vector3(0, -55);

                var name = constructionWindow.transform.Find("Background").Find("Name").gameObject;
                var nameText = name.GetComponent<Text>();
                nameText.gameObject.SetActive(false);

                var Content = Background.Find("Scroll View").Find("Viewport").Find("Content");
                for (int i = 0; i < Content.transform.childCount; i++)
                {
                    GameObject.Destroy(Content.transform.GetChild(i).gameObject);
                }

                //ButtonResource resourceButton = NCMS.Utils.GameObjects.FindEvenInactive("ResourceElement").GetComponent<ButtonResource>();

                var rect = Content.GetComponent<RectTransform>();
                rect.pivot = new Vector2(0, 1);
                // count of objects to display
                int count = AssetManager.buildings.list.Count;
                rect.sizeDelta = new Vector2(0, Mathf.Abs(GetPosByIndex(count).y) + 100);

                var backgroundRect = Background.GetComponent<RectTransform>();
                //rect.pivot = new Vector2(0, 1);
                backgroundRect.sizeDelta = new Vector2(216, 405); // new Vector2(216, 265) original (long button)

                var resourcesList = AssetManager.buildings.list;
                int index = 0;
                for (int i = 0; i < resourcesList.Count; i++)
                {
                    string id = resourcesList[i].id;
                    if (id.Contains("!"))
                    {

                    }
                    else
                    {
                        loadResourceButton(resourcesList[i].id, index, Content.transform, "construction", resourcesList[i]);
                        index++;
                    }
                }
                #endregion
                hasAddedConstructionWindow = true;
                //bankOpen = true;
                ShowWindow("survivor_construction", null, "right", "right", true);
                cachedInventoryResourceCount = RPG_Main.controlledInventory.totalCountOfAllResources;
            }
        }

        public static string totalResourceCostString(BuildingAsset buildingAsset)
        {
            string returnString = "";
            if (buildingAsset.cost != null)
            {

                if (buildingAsset.cost.common_metals > 0)
                {
                    if (RPG_Main.controlledInventory.resources["metals"] < buildingAsset.cost.common_metals)
                    {
                        returnString += Toolbox.coloredText("Metal: " + buildingAsset.cost.common_metals + " ", "#FF0000", false);
                    }
                    else
                    {
                        returnString += Toolbox.coloredText("Metal: " + buildingAsset.cost.common_metals + " ", "#008000", false);
                    }
                }
                if (buildingAsset.cost.gold > 0)
                {
                    if (RPG_Main.controlledInventory.resources["gold"] < buildingAsset.cost.gold)
                    {
                        returnString += Toolbox.coloredText("Gold: " + buildingAsset.cost.gold + " ", "#FF0000", false);
                    }
                    else
                    {
                        returnString += Toolbox.coloredText("Gold: " + buildingAsset.cost.gold + " ", "#008000", false);
                    }
                }
                if (buildingAsset.cost.stone > 0)
                {
                    if (RPG_Main.controlledInventory.resources["stone"] < buildingAsset.cost.stone)
                    {
                        returnString += Toolbox.coloredText("Stone: " + buildingAsset.cost.stone + " ", "#FF0000", false);
                    }
                    else
                    {
                        returnString += Toolbox.coloredText("Stone: " + buildingAsset.cost.stone + " ", "#008000", false);
                    }
                }
                if (buildingAsset.cost.wood > 0)
                {
                    if (RPG_Main.controlledInventory.resources["wood"] < buildingAsset.cost.wood)
                    {
                        returnString += Toolbox.coloredText("Wood: " + buildingAsset.cost.wood + " ", "#FF0000", false);
                    }
                    else
                    {
                        returnString += Toolbox.coloredText("Wood: " + buildingAsset.cost.wood + " ", "#008000", false);
                    }
                }
            }
            if (extraResourceCosts.ContainsKey(buildingAsset.id))
            {
                foreach (KeyValuePair<string, int> resource in extraResourceCosts[buildingAsset.id])
                {
                    if (RPG_Main.controlledInventory.resources[resource.Key] < resource.Value)
                    {
                        returnString += Toolbox.coloredText(FirstCharToUpper(resource.Key) + ": " + resource.Value + " ", "#FF0000", false);
                    }
                    else
                    {
                        returnString += Toolbox.coloredText(FirstCharToUpper(resource.Key) + ": " + resource.Value + " ", "#008000", false);
                    }
                }
            }
            return returnString;
        }

        public static int uniqueIndex = 0;
        private static void loadResourceButton(string pID, int pIndex, Transform parent, string windowID, BuildingAsset resourceAsset)
        {
            Sprite sprite = null;
            if (resourceAsset.sprites != null && resourceAsset.sprites.animationData != null && resourceAsset.sprites.animationData.Count > 0)
            {
                if (resourceAsset.sprites.animationData[0].main != null && resourceAsset.sprites.animationData[0].main.Length > 0)
                {
                    sprite = resourceAsset.sprites.animationData[0].main[0];
                }
            }
            else
            {
                //sprite = resourceAsset.sprites.sprite;
            }
            //sprite = resourceAsset.sprites.animationData.GetRandom().main[0]; // this part isnt working yet

            string tooltipText = FirstCharToUpper(pID) + "(" + uniqueIndex + ") \n Cost: " + totalResourceCostString(resourceAsset); // if i dont rebuild this, no menu refresh, no lag...
            PowerButton elementButton = NCMS.Utils.PowerButtons.CreateButton("building_" + pID + "_" + uniqueIndex, sprite, tooltipText, "", Vector2.zero, ButtonType.Click, parent, delegate
            {
                selectedBuildingAsset = resourceAsset;
                placingToggleEnabled = true;
                ScrollWindow.moveAllToLeftAndRemove(false);
                if (pID.Contains("road"))
                {
                    selectedBuildingAsset = null;
                    placingRoad = true;
                    placingField = false;
                }
                else if (pID.Contains("field"))
                {
                    selectedBuildingAsset = null;
                    placingRoad = false;
                    placingField = true;
                }
                else
                {
                    placingRoad = false;
                    placingField = false;
                }
            });
            uniqueIndex++;
            elementButton.transform.localPosition = GetPosByIndex(pIndex); // set button in right spot

            //elementButton.click // divider for before/after
            /*
            ButtonResource resourceButton = GameObject.Instantiate<ButtonResource>(resourceButtonPref, parent);
            resourceButton.load(resourceAsset, itemBank.resources[pID]);

            resourceButton.transform.localPosition = GetPosByIndex(pIndex); // set button in right spot
            

            var button = resourceButton.gameObject.GetComponent<UnityEngine.UI.Button>();
            resourceButton.textAmount.text = pTotal.ToString();
            button.onClick.AddListener(() => callback(resourceButton));
            */

        }

        private static Vector2 GetPosByIndex(int index)
        {
            float x = (index % countInRow) * XStep + startXPos;
            float y = (Mathf.RoundToInt(index / countInRow) * YStep) + startYPos;

            return new Vector2(x, y);
        }
        private static float startXPos = 60f; // do something based on upgrade list/used ones
        private static int countInRow => 5; //itemBank.resources.Count;
        private static float startYPos = -22.5f;
        private static float YStep = -32.5f; // was 28.5f
        private static float XStep = 32.5f; // 65 for 3, 34 for 5

        public static string FirstCharToUpper(string input)
        {
            if (String.IsNullOrEmpty(input))
                throw new ArgumentException("ARGH!");
            return input.First().ToString().ToUpper() + String.Join("", input.Skip(1));
        }


        public Vector2 scrollPosition;

        public void constructionWindow(int windowID)
        {
            if (Config.gameLoaded && !SmoothLoader.isLoading())
            {
                RPG_Main.SetWindowInUse(windowID);
                Color defaultColor = GUI.backgroundColor;
                GUILayout.BeginHorizontal();
                GUILayout.Button("Selected:");
                GUILayout.Button(selectedBuildingAssetName);
                GUILayout.EndHorizontal();
                GUILayout.BeginHorizontal();
                if (filterEnabled)
                {
                    GUI.backgroundColor = Color.green;
                }
                if (GUILayout.Button("FilterToggle"))
                {
                    filterEnabled = !filterEnabled;
                }
                GUI.backgroundColor = defaultColor;
                filterString = GUILayout.TextField(filterString);
                GUILayout.EndHorizontal();
                if (placingToggleEnabled)
                {
                    GUI.backgroundColor = Color.green;
                }
                if (GUILayout.Button("Toggle placing"))
                {
                    placingToggleEnabled = !placingToggleEnabled;
                }
                scrollPosition = GUILayout.BeginScrollView(
          scrollPosition, GUILayout.Width(225), GUILayout.Height(275));
                GUI.backgroundColor = defaultColor;
                GUILayout.BeginHorizontal();
                int Position = 2;
                GUILayout.BeginVertical();

                Position++;
                foreach (BuildingAsset buildingType in AssetManager.buildings.list)
                {
                    if (!buildingType.id.Contains("!") && (!filterEnabled || (filterEnabled && buildingType.id.Contains(filterString))))
                    {
                        if (GUILayout.Button(buildingType.id))
                        {
                            selectedBuildingAsset = buildingType;
                            placingRoad = false;
                            placingField = false;

                        }
                        if (Position % 10 == 0)
                        {
                            GUILayout.EndVertical();
                            GUILayout.BeginVertical();
                        }
                        Position++;
                    }
                }
                Position = 2;
                GUILayout.EndVertical();
                GUILayout.EndHorizontal();
            }
            GUILayout.EndScrollView();
            GUI.DragWindow();
        }

        public void constructionWindowUpdate()
        {
            if (showHideConstruction)
            {
                ConstructionWindowRect = GUILayout.Window(79005, ConstructionWindowRect, new GUI.WindowFunction(constructionWindow), "Construction", new GUILayoutOption[]
                {
                GUILayout.MaxWidth(300f),
                GUILayout.MinWidth(200f)
                });
            }
            if (placingToggleEnabled)
            {
                constructionPreviewUpdate();
            }
        }

        public static bool showHideConstruction;
        public Rect ConstructionWindowRect;
        public static BuildingAsset selectedBuildingAsset = null;
        public static bool placingToggleEnabled;
        public bool filterEnabled;
        public string filterString = "human";
        public static bool placingRoad;
        public static bool placingField;
        public string selectedBuildingAssetName
        {
            get => buildingAssetName();
        }
    }

}
